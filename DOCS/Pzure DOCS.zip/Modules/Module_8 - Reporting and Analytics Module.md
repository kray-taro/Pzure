# Module 8: Reporting and Analytics Module

This module is the **business intelligence, compliance, audit, and decision-support engine** of the system.

Modules 1–7 generate operational data:

```text
Module 1: licences, branches, staff, contracts
Module 2: sales, payments, invoices, eTIMS, shifts
Module 3: prescriptions, dispensing, controlled medicines
Module 4: inventory, purchasing, batches, expiry, transfers
Module 5: clinic visits, diagnoses, services, referrals
Module 6: lab orders, samples, results, send-outs
Module 7: claims, denials, receivables, reconciliation
Module 8: turns all that data into reports, dashboards, alerts, audit trails, and management decisions
```

For a Kenyan pharmacy, clinic, chemist, or small health-retail chain, reporting is not just “nice to have.” It is needed for:

```text
cash control → tax/eTIMS compliance → stock control → expiry control → pharmacy safety → claims recovery → clinical quality → data protection → owner visibility
```

Kenya’s Digital Health Act places data collection, collation, analysis, reporting, storage, usage, sharing, retrieval, archival, data quality assurance, and audit within the national digital-health system architecture. The same Act also points to shared resources such as the national health data dictionary, client registry, facility registry, health worker registry, product catalogue, interoperability layer, health management information services, and finance/insurance services. ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/2023/15))

---

# 1. Purpose of the module

The Reporting and Analytics Module should:

| Purpose                           | Practical meaning                                                                 |
| --------------------------------- | --------------------------------------------------------------------------------- |
| Give owners visibility            | Sales, margin, stock, cash, claims, staff, branches                               |
| Support managers                  | Daily operations, queues, shift variances, stockouts, pending work                |
| Support accountants               | eTIMS status, invoices, payments, credit notes, taxes, receivables                |
| Support pharmacists               | prescription audit, controlled medicines, batch recall, near-expiry               |
| Support clinic managers           | diagnosis/service reports, clinician workload, visit volumes                      |
| Support procurement               | fast/slow movers, reorder, stockouts, dead stock, supplier performance            |
| Support billing officers          | claim denials, ageing, resubmissions, reconciliation                              |
| Support compliance                | licence expiry, data access logs, staff activity, audit trails                    |
| Support data protection           | who accessed patient data, what was exported, what was shared                     |
| Support future national reporting | health data dictionary, interoperability, aggregate reporting readiness           |
| Detect leakage and fraud          | discounts, voids, refunds, stock adjustments, cashier variances, duplicate claims |

---

# 2. Kenya-specific design basis

## A. eTIMS and tax reporting

Kenya’s Electronic Tax Invoice Regulations apply to persons carrying on business unless exempted, require each sale to be recorded in the system, require an invoice for each sale, require invoice details to be transmitted to the Commissioner, and require stock-in/stock-out records for applicable users. The same regulations require e-invoicing systems to be secure, tamper-proof, able to integrate with KRA systems, maintain data integrity, authenticate authorized users, log all activities, and assign a unique identifier to each invoice. ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/ln/2024/64/eng@2024-03-28))

Software implication:

| eTIMS requirement                             | Reporting requirement                                   |
| --------------------------------------------- | ------------------------------------------------------- |
| Every sale recorded                           | Daily sales report must reconcile with invoice register |
| Invoice generated per sale                    | eTIMS invoice status report                             |
| Invoice details transmitted                   | Submitted/accepted/rejected/queued report               |
| Stock-in/stock-out records                    | Inventory movement and stock ledger reports             |
| System logs activities                        | User activity and eTIMS audit logs                      |
| Credit/debit notes reference original invoice | Credit note and reversal reports                        |

---

## B. Health data reporting and data governance

Kenya’s health information management regulations state that the Kenya Health Data Governance Framework governs the collection, access, sharing, and use of health data; they also refer to maintaining a National Health Data Bank, health-data-controller inventories, security measures including encryption and access controls, and publishing select aggregate health data. ([health.go.ke](https://health.go.ke/sites/default/files/2024-11/FINAL%20Digital%20Health%20%28Health%20Information%20Management%29%20Regulations%2019.11.24.pdf))

Software implication:

| Health data governance need       | Reporting requirement                                                    |
| --------------------------------- | ------------------------------------------------------------------------ |
| Collection and use of health data | Data dictionary and standard report definitions                          |
| Access controls                   | Data access log report                                                   |
| Sharing of health data            | Export/share log report                                                  |
| Aggregate reporting               | Diagnosis, service, immunisation, lab, chronic-care reports              |
| Security controls                 | Failed login, unusual access, export, breach, role-change reports        |
| Data quality                      | Missing diagnosis, unsigned notes, duplicate patients, incomplete visits |

---

## C. Data protection

Kenya’s Data Protection Act defines health data as data about a person’s physical or mental health, including data collected during registration for or provision of health services, and classifies health status as sensitive personal data. The Data Protection General Regulations classify processing sensitive personal data, children’s data, large-scale personal data, or cross-referenced datasets as high-risk processing that requires a data protection impact assessment before processing. ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/2019/24/eng%402022-12-31)) ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/ln/2021/263/eng%402022-12-31))

Software implication:

| Data protection need  | Reporting requirement                        |
| --------------------- | -------------------------------------------- |
| Sensitive health data | Strict role-based reports                    |
| Access accountability | Patient data access log                      |
| Export accountability | Data export/share report                     |
| High-risk processing  | DPIA support report                          |
| Data minimization     | Report-level masking and aggregation         |
| Patient rights        | Access/rectification/erasure request log     |
| Breach readiness      | Security incident and unusual access reports |

---

## D. Claims and insurance reporting

SHA regulations require contracted providers and facilities to use and verify beneficiary data, provide services within benefit limits, maintain beneficiary records in accessible format, and maintain adequate systems for collecting, processing, storing, retrieving, and distributing beneficiary records. The regulations also require incomplete or erroneous claims to be returned with reasons, rejected claims to be notified with reasons, and claims processing to be guided by prescribed tariffs. ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/ln/2024/49/eng%402024-03-08))

Software implication:

| Claims need          | Reporting requirement                            |
| -------------------- | ------------------------------------------------ |
| Benefit verification | Eligibility and pre-auth reports                 |
| Service limits       | Limit-exceeded and pre-auth reports              |
| Incomplete claims    | Missing-document and claim-readiness reports     |
| Rejected claims      | Claims rejection report                          |
| Tariffs              | Tariff mismatch and underpayment reports         |
| Accessible records   | Claim bundle and attachment completeness reports |

---

## E. Pharmacy traceability and recalls

PPB’s authentication and traceability standards describe traceability as important for patient safety, supply-chain integrity, and protection against falsified or substandard health products. ([web.pharmacyboardkenya.org](https://web.pharmacyboardkenya.org/download/standards-for-authentication-and-traceability-of-health-products-and-technologies/))

Software implication:

| Pharmacy safety need      | Reporting requirement                       |
| ------------------------- | ------------------------------------------- |
| Batch traceability        | Batch recall report                         |
| Product integrity         | Supplier, batch, expiry, quarantine reports |
| Patient safety            | Affected-patient-by-batch report            |
| Dispensing accountability | Prescription and dispense audit             |
| Controlled medicines      | Controlled medicine register/report         |

---

# 3. Core users

| User                      | Main reporting needs                                                   |
| ------------------------- | ---------------------------------------------------------------------- |
| Owner/director            | Sales, margin, cash, stock value, claims, branches, staff, risks       |
| Branch manager            | Daily operations, stock, shifts, discounts, variances                  |
| Accountant                | eTIMS, invoices, payments, credit notes, receivables, reconciliation   |
| Pharmacist/superintendent | prescriptions, controlled medicines, recalls, expiry, dispensing audit |
| Procurement officer       | fast movers, slow movers, stockouts, reorder, supplier price changes   |
| Clinic manager            | visits, diagnoses, services, clinician workload, referrals             |
| Lab in-charge             | lab volumes, pending results, rejected samples, external send-outs     |
| Billing/claims officer    | claim readiness, denials, pre-auth, ageing, reconciliation             |
| Compliance officer        | licences, staff activity, overrides, audit trails                      |
| Data protection officer   | data access, exports, breach alerts, consent, DPIA support             |
| Auditor                   | immutable logs, exceptions, adjustments, reversals, user actions       |
| Franchise/head office     | branch comparisons, standard KPIs, compliance scorecards               |

---

# 4. Reporting architecture

The module should have three layers.

```text
Operational reports
    Real-time reports from transactional modules

Management analytics
    Dashboards, trends, KPIs, comparisons, exceptions

Compliance and audit reports
    Immutable logs, access records, regulatory exports, claim/eTIMS evidence
```

## Recommended technical architecture

| Layer                  | Purpose                                                          |
| ---------------------- | ---------------------------------------------------------------- |
| Transactional database | Live POS, EMR, pharmacy, lab, claims, inventory                  |
| Reporting replica      | Reduces load on live system                                      |
| Analytics warehouse    | Historical trends, KPIs, branch comparisons                      |
| Metrics engine         | Standard definitions for sales, margin, stock cover, denial rate |
| Report builder         | Controlled custom reports                                        |
| Scheduled reports      | Daily email/PDF/Excel exports                                    |
| Alert engine           | Exceptions: stockout, expiry, eTIMS rejection, claim denial      |
| Audit log store        | Immutable user/system activity                                   |
| Export control         | Permissioned CSV/PDF/Excel downloads                             |
| Data masking layer     | Hide patient-sensitive fields for non-clinical users             |

For small clinics and chemists, the MVP can start with operational reports directly from the application database. Larger branches/chains should move to a reporting replica or analytics warehouse.

---

# 5. Data sources

| Source module          | Data used in reporting                                     |
| ---------------------- | ---------------------------------------------------------- |
| Organisation/licensing | branches, licences, professionals, contracts               |
| POS/billing            | sales, invoices, payments, discounts, refunds, shifts      |
| Pharmacy dispensing    | prescriptions, dispenses, substitutions, controlled items  |
| Inventory              | stock balances, batches, purchases, transfers, adjustments |
| Clinic EMR             | visits, diagnoses, services, referrals, certificates       |
| Lab-lite               | orders, samples, results, send-outs                        |
| Claims/insurance       | pre-auth, claims, denials, reconciliation                  |
| User/security          | logins, activity, access, permissions                      |
| Notifications          | SMS/WhatsApp/email sent, failures, consent status          |
| Integrations           | eTIMS, M-Pesa, SHA/private insurer, external lab           |

---

# 6. Minimum report catalogue

## 6.1 Daily sales report

**Primary user:** Owner/manager
**Purpose:** Know how much was sold, by whom, through which branch, and by which payment method.

| Section     | Details                                                        |
| ----------- | -------------------------------------------------------------- |
| Data source | POS, billing, pharmacy, clinic, lab                            |
| Frequency   | Real-time, daily close                                         |
| Filters     | Date, branch, cashier, category, payment method, customer type |
| Grouping    | Branch, cashier, product/service category, payment method      |
| Export      | PDF, Excel, CSV                                                |

### Key columns

| Column                                           |
| ------------------------------------------------ |
| Date/time                                        |
| Branch                                           |
| Sale number                                      |
| Invoice number                                   |
| eTIMS status                                     |
| Customer/patient                                 |
| Category: retail/drug/consultation/lab/procedure |
| Subtotal                                         |
| Discount                                         |
| Tax                                              |
| Gross total                                      |
| Payment method                                   |
| Amount paid                                      |
| Balance                                          |
| Cashier                                          |
| Status: completed/refunded/credit-noted          |

### Metrics

| Metric                    | Formula                                     |
| ------------------------- | ------------------------------------------- |
| Gross sales               | Sum of completed sale totals before returns |
| Net sales                 | Gross sales - refunds - credit notes        |
| Discount rate             | Discount total / gross sales                |
| Average transaction value | Net sales / number of transactions          |
| Cash sales                | Sum payments where method = cash            |
| M-Pesa sales              | Sum payments where method = M-Pesa          |
| Insurance sales           | Sum payer portion posted to claims          |
| Credit sales              | Sum posted to customer/payer receivable     |

### Alerts

| Alert               | Trigger                                   |
| ------------------- | ----------------------------------------- |
| Sales unusually low | Below branch daily baseline               |
| High discount day   | Discount rate above threshold             |
| High refund day     | Refunds above threshold                   |
| Many voids          | Count above threshold                     |
| eTIMS pending       | Sales completed but invoices not accepted |

---

## 6.2 Cashier shift report

**Primary user:** Owner/manager
**Purpose:** Cash and payment control.

| Section     | Details                                       |
| ----------- | --------------------------------------------- |
| Data source | POS, payments, shifts                         |
| Frequency   | Every shift close                             |
| Filters     | Date, branch, cashier, terminal, shift status |
| Grouping    | Cashier, branch, terminal                     |
| Export      | PDF/Excel                                     |

### Key columns

| Column                 |
| ---------------------- |
| Shift number           |
| Branch                 |
| Terminal               |
| Cashier                |
| Open time              |
| Close time             |
| Opening float          |
| Cash sales             |
| Cash refunds           |
| Cash drops             |
| Expected cash          |
| Counted cash           |
| Variance               |
| M-Pesa expected        |
| M-Pesa confirmed       |
| Card expected          |
| Credit sales           |
| Insurer/SHA receivable |
| Discounts              |
| Voids                  |
| Refunds                |
| Manager approval       |
| Closing notes          |

### Metrics

| Metric              | Formula                            |
| ------------------- | ---------------------------------- |
| Cash variance       | Counted cash - expected cash       |
| Shift sales         | Sum sales within shift             |
| Refund ratio        | Refund value / shift sales         |
| Void ratio          | Void count / transactions          |
| Unreconciled M-Pesa | Expected M-Pesa - confirmed M-Pesa |

### Alerts

| Alert            | Trigger                            |
| ---------------- | ---------------------------------- |
| Cash shortage    | Variance below negative threshold  |
| Cash excess      | Variance above positive threshold  |
| Many refunds     | Refund count/value above threshold |
| Shift not closed | Open shift past configured hours   |
| M-Pesa mismatch  | POS M-Pesa > confirmed M-Pesa      |

---

## 6.3 eTIMS invoice status report

**Primary user:** Accountant
**Purpose:** Track invoice submission, acceptance, rejection, queued invoices, credit notes, and tax compliance.

| Section     | Details                                        |
| ----------- | ---------------------------------------------- |
| Data source | POS, invoice engine, eTIMS integration         |
| Frequency   | Real-time/daily                                |
| Filters     | Date, branch, status, invoice type, error code |
| Export      | Excel, PDF, CSV                                |

### Key columns

| Column                                     |
| ------------------------------------------ |
| Invoice number                             |
| eTIMS unique identifier                    |
| Sale number                                |
| Branch                                     |
| KRA PIN                                    |
| Invoice date/time                          |
| Submission date/time                       |
| Buyer PIN                                  |
| Gross amount                               |
| Tax amount                                 |
| Status: queued/submitted/accepted/rejected |
| Error code/message                         |
| Retry count                                |
| Credit note reference                      |
| Cashier                                    |
| Last sync time                             |

### Required status buckets

```text
Accepted
Submitted
Queued offline
Retrying
Rejected
Credit-noted
Cancelled before submission
Manual review
```

### Alerts

| Alert                | Trigger                                    |
| -------------------- | ------------------------------------------ |
| Rejected invoice     | eTIMS rejection received                   |
| Queued too long      | Invoice pending beyond threshold           |
| Missing buyer PIN    | Corporate/claimable invoice missing PIN    |
| Credit note mismatch | Credit note without valid original invoice |
| Offline period       | eTIMS queue accumulated                    |

---

## 6.4 Gross margin report

**Primary user:** Owner
**Purpose:** Know actual profitability, not just sales.

| Section     | Details                                            |
| ----------- | -------------------------------------------------- |
| Data source | POS, inventory, purchase cost, price lists         |
| Frequency   | Daily/weekly/monthly                               |
| Filters     | Product, category, branch, supplier, cashier, date |
| Grouping    | Product, category, branch, supplier, batch         |
| Export      | Excel/PDF                                          |

### Key columns

| Column          |
| --------------- |
| Product/service |
| Category        |
| Quantity sold   |
| Sales value     |
| Cost value      |
| Gross profit    |
| Gross margin %  |
| Discount value  |
| Supplier        |
| Batch           |
| Branch          |
| Price list      |
| Cashier         |

### Metrics

| Metric           | Formula                            |
| ---------------- | ---------------------------------- |
| Gross profit     | Net sales - cost of goods sold     |
| Gross margin %   | Gross profit / net sales           |
| Markup %         | Gross profit / cost                |
| Discount impact  | Discount value / gross sales       |
| Low-margin sales | Lines where margin below threshold |

### Important design note

Services such as consultation and lab procedures may not have a simple stock cost. The system should allow:

| Item type             | Cost method                              |
| --------------------- | ---------------------------------------- |
| Medicine/retail stock | Batch cost or weighted average cost      |
| Lab test              | Reagent/consumable cost or standard cost |
| Procedure             | Consumables + standard service cost      |
| Consultation          | Optional clinician/time overhead         |
| Package               | Allocated cost per component             |

---

## 6.5 Fast/slow movers report

**Primary user:** Procurement
**Purpose:** Know what to buy, transfer, promote, or stop buying.

| Section     | Details                                       |
| ----------- | --------------------------------------------- |
| Data source | Inventory, sales, dispensing, stock movements |
| Frequency   | Daily/weekly/monthly                          |
| Filters     | Branch, category, supplier, date range        |
| Grouping    | Product, branch, category, supplier           |
| Export      | Excel                                         |

### Key columns

| Column                         |
| ------------------------------ |
| Product                        |
| Category                       |
| Branch                         |
| Quantity sold/dispensed        |
| Sales value                    |
| Gross margin                   |
| Current stock                  |
| Average daily/monthly movement |
| Days of stock cover            |
| Last sale date                 |
| Supplier                       |
| Reorder point                  |
| Suggested action               |

### Classifications

| Classification    | Rule example                                   |
| ----------------- | ---------------------------------------------- |
| Fast mover        | Top 20% by quantity or value                   |
| Slow mover        | Movement below threshold                       |
| Dead stock        | No movement for 90/180 days                    |
| Overstocked       | Stock cover above configured months            |
| Critical mover    | High clinical importance and frequent stockout |
| High-margin mover | Strong profit contributor                      |

### Suggested actions

| Situation               | Action                               |
| ----------------------- | ------------------------------------ |
| Fast mover, low stock   | Reorder                              |
| Slow mover, high stock  | Stop reorder                         |
| Dead stock              | Transfer/return/write-down           |
| Fast mover, high margin | Protect availability                 |
| Fast mover, low margin  | Renegotiate supplier or adjust price |

---

## 6.6 Stockout report

**Primary user:** Procurement
**Purpose:** Avoid lost sales, poor patient care, and emergency purchases.

| Section     | Details                                      |
| ----------- | -------------------------------------------- |
| Data source | Inventory, POS, dispensing, reorder settings |
| Frequency   | Real-time/daily                              |
| Filters     | Branch, category, critical item, supplier    |
| Export      | Excel/PDF                                    |

### Key columns

| Column                               |
| ------------------------------------ |
| Product                              |
| Generic name                         |
| Branch                               |
| Current stock                        |
| Reserved stock                       |
| Available stock                      |
| Reorder point                        |
| Minimum stock                        |
| Average daily usage                  |
| Days out of stock                    |
| Last sold/dispensed                  |
| Preferred supplier                   |
| Supplier lead time                   |
| Open PO quantity                     |
| Transfer available from other branch |
| Suggested action                     |

### Alerts

| Alert                              | Trigger                               |
| ---------------------------------- | ------------------------------------- |
| Out of stock                       | Available stock = 0                   |
| Below reorder point                | Available + on-order <= reorder point |
| Critical item out                  | Critical flag + stockout              |
| Open PO delayed                    | Expected delivery passed              |
| Branch A out, Branch B overstocked | Suggest transfer                      |

---

## 6.7 Near-expiry report

**Primary user:** Pharmacist/manager
**Purpose:** Reduce losses and prevent expired stock dispensing.

| Section     | Details                                                |
| ----------- | ------------------------------------------------------ |
| Data source | Inventory batches, dispensing, sales                   |
| Frequency   | Daily                                                  |
| Filters     | Expiry window, branch, supplier, category, stock value |
| Grouping    | Branch, product, batch, supplier                       |
| Export      | PDF/Excel                                              |

### Key columns

| Column                  |
| ----------------------- |
| Product                 |
| Generic/brand           |
| Batch                   |
| Expiry date             |
| Days to expiry          |
| Branch                  |
| Quantity on hand        |
| Quantity sold per month |
| Estimated days to clear |
| Cost value at risk      |
| Supplier                |
| Return eligibility      |
| Storage condition       |
| Suggested action        |

### Expiry windows

```text
180 days
90 days
60 days
30 days
Expired
```

### Suggested actions

| Situation                     | Action                                |
| ----------------------------- | ------------------------------------- |
| Fast-moving and 90 days left  | Continue FEFO sale                    |
| Slow-moving and 180 days left | Transfer to faster branch             |
| Supplier return possible      | Return to supplier                    |
| 30 days left                  | Pharmacist/manager review             |
| Expired                       | Block, quarantine, write-off workflow |

---

## 6.8 Batch recall report

**Primary user:** Pharmacist/manager
**Purpose:** Find affected stock and patients quickly.

| Section     | Details                                                     |
| ----------- | ----------------------------------------------------------- |
| Data source | Inventory batches, GRNs, dispensing, sales, patient records |
| Frequency   | On demand                                                   |
| Filters     | Product, batch, supplier, date range, branch                |
| Export      | PDF/Excel/recall pack                                       |

### Key columns

| Column                    |
| ------------------------- |
| Product                   |
| Batch                     |
| Expiry                    |
| Supplier                  |
| GRN number                |
| Branch                    |
| Quantity received         |
| Quantity available        |
| Quantity dispensed/sold   |
| Quantity transferred      |
| Quantity quarantined      |
| Patient/customer supplied |
| Patient phone             |
| Dispense date             |
| Invoice/sale number       |
| Pharmacist/dispenser      |
| Recall action status      |

### Recall actions

```text
Block batch
Move stock to quarantine
Identify affected branches
Identify affected patients/customers
Notify patients where appropriate
Record supplier/regulator return
Record disposal/write-off
Close recall
```

### Alert

| Alert                                | Trigger                  |
| ------------------------------------ | ------------------------ |
| Recalled batch still sellable        | Immediate critical alert |
| Patient supplied recalled batch      | Contact task             |
| Branch has unconfirmed recall action | Escalate to manager      |

---

## 6.9 Controlled medicine report

**Primary user:** Pharmacist
**Purpose:** Monitor high-risk medicines and reconcile controlled stock.

| Section     | Details                                             |
| ----------- | --------------------------------------------------- |
| Data source | Pharmacy dispensing, controlled register, inventory |
| Frequency   | Daily/weekly/monthly/on demand                      |
| Filters     | Medicine, branch, batch, date, patient, prescriber  |
| Export      | PDF/Excel                                           |

### Key columns

| Column                |
| --------------------- |
| Register entry number |
| Date/time             |
| Branch                |
| Medicine              |
| Strength/form         |
| Batch                 |
| Opening balance       |
| Quantity received     |
| Quantity dispensed    |
| Quantity adjusted     |
| Closing balance       |
| Patient               |
| Prescriber            |
| Prescription number   |
| Pharmacist            |
| Witness/approver      |
| Adjustment reason     |
| Variance status       |

### Controls

| Control                | Requirement                                          |
| ---------------------- | ---------------------------------------------------- |
| No silent edits        | Corrections create new entry                         |
| Balance reconciliation | System balance versus physical balance               |
| Adjustment approval    | Superintendent/authorized approval                   |
| Suspicious pattern     | Frequent adjustments, early refills, high quantities |
| Export audit           | Every export logged                                  |

---

## 6.10 Prescription audit report

**Primary user:** Pharmacist
**Purpose:** Audit prescription-only medicine dispensing, substitutions, partial dispensing, warnings, and approvals.

| Section     | Details                                                                  |
| ----------- | ------------------------------------------------------------------------ |
| Data source | Pharmacy dispensing, EMR, POS, inventory                                 |
| Frequency   | Daily/weekly/monthly                                                     |
| Filters     | Prescriber, pharmacist, medicine, patient, branch, warning, substitution |
| Export      | PDF/Excel                                                                |

### Key columns

| Column                  |
| ----------------------- |
| Prescription number     |
| Patient                 |
| Prescriber              |
| Facility/source         |
| Medicine prescribed     |
| Medicine dispensed      |
| Quantity prescribed     |
| Quantity dispensed      |
| Batch/expiry            |
| Substitution flag       |
| Substitution reason     |
| Partial dispense flag   |
| Partial reason          |
| Clinical warnings       |
| Warning override reason |
| Pharmacist approval     |
| Sale/invoice number     |
| Dispense date/time      |

### Audit flags

| Flag                                        | Meaning                    |
| ------------------------------------------- | -------------------------- |
| Missing prescriber detail                   | Prescription quality issue |
| Substitution without reason                 | Compliance risk            |
| Partial dispense without reason             | Compliance risk            |
| Warning overridden                          | Safety review              |
| Prescription-only sold without prescription | Critical violation         |
| Cashier-only approval                       | Critical violation         |
| Batch missing                               | Traceability issue         |

---

## 6.11 Diagnosis/service report

**Primary user:** Clinic manager
**Purpose:** Understand patient conditions, services provided, clinician workload, and reporting needs.

| Section     | Details                                                    |
| ----------- | ---------------------------------------------------------- |
| Data source | EMR, billing, lab, pharmacy                                |
| Frequency   | Daily/weekly/monthly                                       |
| Filters     | Date, branch, clinician, diagnosis, ICD-10, service, payer |
| Export      | PDF/Excel/CSV                                              |

### Key columns

| Column                      |
| --------------------------- |
| Visit date                  |
| Patient age/sex             |
| Branch                      |
| Clinician                   |
| Diagnosis text              |
| ICD-10 code                 |
| Primary/secondary diagnosis |
| Service type                |
| Consultation type           |
| Lab orders                  |
| Procedures                  |
| Prescriptions               |
| Referral status             |
| Payer                       |
| Claim status                |

### Useful summaries

| Summary                | Use                               |
| ---------------------- | --------------------------------- |
| Top diagnoses          | Clinic demand planning            |
| Services by diagnosis  | Clinical workflow insight         |
| Clinician workload     | Staffing                          |
| Diagnosis by age/sex   | Public health/internal planning   |
| Lab usage by diagnosis | Test utilization                  |
| Referral rate          | Quality and capability monitoring |
| Claims-ready visits    | Billing quality                   |

---

## 6.12 Claims rejection report

**Primary user:** Billing officer
**Purpose:** Recover rejected claims and reduce repeat denials.

| Section     | Details                                                     |
| ----------- | ----------------------------------------------------------- |
| Data source | Claims module, EMR, lab, pharmacy, billing                  |
| Frequency   | Daily/weekly                                                |
| Filters     | Payer, branch, denial reason, clinician, service type, date |
| Export      | Excel/PDF                                                   |

### Key columns

| Column                 |
| ---------------------- |
| Claim number           |
| Patient                |
| Payer                  |
| Scheme                 |
| Visit date             |
| Claim amount           |
| Denied amount          |
| Denial reason          |
| Denial category        |
| Claim line affected    |
| Responsible department |
| Correction required    |
| Resubmission deadline  |
| Resubmission status    |
| Amount recovered       |
| Write-off amount       |

### Denial categories

```text
Eligibility
Pre-authorisation
Benefit exhausted
Service not covered
Missing diagnosis
Missing attachment
Unsigned clinical note
Missing lab result
Prescription/dispense mismatch
Wrong tariff
Duplicate claim
Late submission
Medical necessity
Facility scope
Provider scope
Technical/portal error
```

---

## 6.13 Staff activity log

**Primary user:** Owner/compliance
**Purpose:** Know what staff did in the system.

| Section     | Details                                                   |
| ----------- | --------------------------------------------------------- |
| Data source | All modules                                               |
| Frequency   | Real-time/on demand                                       |
| Filters     | User, role, branch, date, module, action type, risk level |
| Export      | Restricted PDF/CSV                                        |

### Key columns

| Column          |
| --------------- |
| Date/time       |
| User            |
| Role            |
| Branch          |
| Module          |
| Action          |
| Record affected |
| Old value       |
| New value       |
| Reason          |
| Approval        |
| Device/IP       |
| Risk level      |

### High-risk activity categories

| Category  | Examples                                                                |
| --------- | ----------------------------------------------------------------------- |
| Financial | void sale, refund, discount, credit note, cash drawer open              |
| Inventory | stock adjustment, write-off, transfer, quarantine release               |
| Pharmacy  | prescription approval, controlled medicine adjustment, warning override |
| Clinical  | note correction, diagnosis change, certificate issue                    |
| Claims    | claim edit, denial closure, write-off                                   |
| Security  | role change, failed login, password reset                               |
| Data      | export, print, patient record access                                    |

---

## 6.14 Data access log

**Primary user:** Data protection/compliance
**Purpose:** Monitor access, sharing, printing, and exporting of patient and sensitive business data.

| Section     | Details                                                          |
| ----------- | ---------------------------------------------------------------- |
| Data source | Security, EMR, pharmacy, lab, claims, documents                  |
| Frequency   | Real-time/on demand                                              |
| Filters     | Patient, user, branch, module, access type, date, sensitive flag |
| Export      | Highly restricted                                                |

### Key columns

| Column                               |
| ------------------------------------ |
| Date/time                            |
| User                                 |
| Role                                 |
| Branch                               |
| Patient                              |
| Record type                          |
| Action: view/edit/print/export/share |
| Purpose/reason                       |
| Consent status                       |
| Recipient/channel                    |
| Device/IP                            |
| Sensitive flag                       |
| Break-glass flag                     |
| Outcome                              |
| Risk level                           |

### Data protection flags

| Flag                    | Meaning                                                  |
| ----------------------- | -------------------------------------------------------- |
| After-hours access      | User opened record outside normal hours                  |
| Non-care-team access    | User not linked to patient visit                         |
| Bulk export             | Many records exported                                    |
| Sensitive record access | HIV/TB, mental health, reproductive health, minors, etc. |
| Break-glass access      | Emergency override used                                  |
| Repeated failed logins  | Security risk                                            |
| Unusual branch access   | User accessed records from another branch                |

---

# 7. Additional recommended reports

The minimum reports are good, but a complete Kenyan solution should also include the following.

## Business and finance

| Report                           | User                      |
| -------------------------------- | ------------------------- |
| Payment reconciliation           | Accountant                |
| M-Pesa reconciliation            | Accountant/manager        |
| Credit customer ageing           | Accountant                |
| Insurer/SHA receivables ageing   | Accountant/claims officer |
| Refund and credit note report    | Owner/accountant          |
| Discount approval report         | Owner                     |
| Branch performance report        | Owner                     |
| Revenue by category              | Owner                     |
| VAT/tax summary                  | Accountant                |
| Supplier invoice/payables report | Accountant                |

## Pharmacy and stock

| Report                       | User                  |
| ---------------------------- | --------------------- |
| Stock valuation              | Owner/accountant      |
| Dead stock report            | Procurement           |
| Stock adjustment report      | Owner/compliance      |
| Quarantine report            | Pharmacist/manager    |
| Supplier performance report  | Procurement           |
| Supplier price movement      | Procurement/owner     |
| Inter-branch transfer report | Manager               |
| Cold-chain incident report   | Pharmacist/manager    |
| ADR/PQMP report              | Pharmacist/compliance |

## Clinic and lab

| Report                       | User                 |
| ---------------------------- | -------------------- |
| Daily visits                 | Clinic manager       |
| Queue waiting time           | Clinic manager       |
| Clinician workload           | Clinic manager       |
| Unsigned notes               | Medical director     |
| Pending lab results          | Lab in-charge        |
| Critical lab results         | Clinician/lab        |
| External lab send-out report | Lab in-charge        |
| Referral report              | Clinic manager       |
| Chronic-care due report      | Clinic manager       |
| Immunisation report          | Nurse/clinic manager |

## Compliance

| Report                        | User                    |
| ----------------------------- | ----------------------- |
| Licence expiry report         | Compliance officer      |
| Professional licence status   | Compliance officer      |
| Override report               | Owner/compliance        |
| Data export report            | DPO/compliance          |
| Consent report                | DPO/compliance          |
| Breach/incident report        | DPO/compliance          |
| Role/permission change report | System admin/compliance |
| Backup and sync health report | IT/admin                |

---

# 8. Dashboards

## A. Owner dashboard

Cards:

```text
Today’s sales
Net sales this month
Gross margin
Cash expected
M-Pesa confirmed
eTIMS rejected/queued
Stock value
Near-expiry value
Dead stock value
Claims outstanding
Claims rejected
Top-selling items
Lowest-margin items
Branch ranking
Staff exceptions
```

Charts:

| Chart                   | Use                          |
| ----------------------- | ---------------------------- |
| Sales trend             | Daily/weekly/monthly revenue |
| Margin trend            | Profitability                |
| Payment mix             | Cash/M-Pesa/card/insurance   |
| Branch comparison       | Chain performance            |
| Claims ageing           | Cashflow risk                |
| Stock value by category | Working capital              |
| Denial reasons          | Revenue recovery             |

---

## B. Branch manager dashboard

Cards:

```text
Sales today
Open shifts
Cash variance
Pending eTIMS invoices
Low stock
Near-expiry stock
Pending stock transfers
Pending orders
Pending lab results
Pending pharmacy queue
Claims not ready
```

---

## C. Pharmacist dashboard

Cards:

```text
Prescriptions pending review
Prescription-only dispenses today
Controlled medicine entries
Controlled stock variance
Clinical warnings overridden
Partial dispenses
Substitutions
Near-expiry medicines
Recalled/quarantined batches
ADR/PQMP reports
```

---

## D. Clinic manager dashboard

Cards:

```text
Patients seen today
Patients waiting
Average waiting time
Clinician workload
Top diagnoses
Lab orders pending
Results pending review
Referrals today
Chronic patients due
Unsigned notes
Claims-ready visits
```

---

## E. Accountant dashboard

Cards:

```text
eTIMS accepted
eTIMS rejected
eTIMS queued
Credit notes
Daily revenue
Cash variance
M-Pesa unreconciled
Supplier invoices pending
Payer receivables
Patient receivables
Write-offs
```

---

## F. Data protection/compliance dashboard

Cards:

```text
Sensitive record access
Bulk exports
After-hours access
Break-glass access
Failed logins
Role changes
Patient data shared
Consent exceptions
Data subject requests
Security incidents
Audit exports
```

---

# 9. Report permissions and masking

Not every user should see every report or every field.

## Role-based report access

| Report               |   Owner | Manager | Accountant | Pharmacist | Clinician |  Claims |     DPO | Auditor |
| -------------------- | ------: | ------: | ---------: | ---------: | --------: | ------: | ------: | ------: |
| Daily sales          |     Yes |     Yes |        Yes |    Limited |        No | Limited |      No |     Yes |
| Cashier shift        |     Yes |     Yes |        Yes |         No |        No |      No |      No |     Yes |
| eTIMS status         |     Yes | Limited |        Yes |         No |        No |      No |      No |     Yes |
| Gross margin         |     Yes | Limited |        Yes |    Limited |        No |      No |      No |     Yes |
| Fast/slow movers     |     Yes |     Yes |    Limited |        Yes |        No |      No |      No |     Yes |
| Stockout             |     Yes |     Yes |    Limited |        Yes |        No |      No |      No |     Yes |
| Near-expiry          |     Yes |     Yes |    Limited |        Yes |        No |      No |      No |     Yes |
| Batch recall         |     Yes |     Yes |         No |        Yes |   Limited |      No | Limited |     Yes |
| Controlled medicines | Limited | Limited |         No |        Yes |        No |      No |      No |     Yes |
| Prescription audit   | Limited | Limited |         No |        Yes |   Limited |      No |      No |     Yes |
| Diagnosis/service    |     Yes |     Yes |         No |         No |       Yes | Limited | Limited |     Yes |
| Claims rejection     |     Yes |     Yes |        Yes |         No |   Limited |     Yes |      No |     Yes |
| Staff activity       |     Yes | Limited |    Limited |         No |        No |      No |      No |     Yes |
| Data access log      | Limited |      No |         No |         No |        No |      No |     Yes |     Yes |

## Data masking examples

| User           | Masking rule                                                                  |
| -------------- | ----------------------------------------------------------------------------- |
| Owner          | Can see financials; patient identifiers masked unless necessary               |
| Accountant     | Financial data visible; clinical details minimized                            |
| Pharmacist     | Prescription and patient-safety data visible; unrelated clinical notes hidden |
| Clinician      | Clinical reports visible; gross margin hidden                                 |
| Procurement    | Stock and supplier data visible; patient data hidden                          |
| Claims officer | Claim-relevant clinical evidence visible; unrelated clinical history hidden   |
| DPO            | Access logs visible; sensitive clinical content limited unless investigating  |
| Auditor        | Broad read-only access with export logging                                    |

---

# 10. Filters and dimensions

Every serious report should support standard filters.

## Common filters

| Filter                |
| --------------------- |
| Date range            |
| Branch                |
| Department            |
| User/staff            |
| Role                  |
| Customer/patient type |
| Payer                 |
| Product category      |
| Service category      |
| Supplier              |
| Batch                 |
| Diagnosis             |
| Clinician             |
| Payment method        |
| Invoice status        |
| Claim status          |
| Stock status          |
| Data sensitivity      |
| Export status         |

## Analytics dimensions

| Dimension  | Examples                                      |
| ---------- | --------------------------------------------- |
| Time       | Hour, day, week, month, quarter               |
| Location   | Branch, county, sub-county                    |
| Product    | Brand, generic, category, supplier            |
| Patient    | Age band, sex, payer type                     |
| Staff      | Cashier, pharmacist, clinician                |
| Payer      | SHA, insurer, employer, cash                  |
| Service    | Consultation, lab, procedure, drug            |
| Stock      | Batch, expiry, storage condition              |
| Finance    | Payment method, tax status, price list        |
| Compliance | Licence status, audit event, data access type |

---

# 11. Metrics dictionary

The system should define metrics centrally so users do not argue over numbers.

| Metric                             | Definition                                                   |
| ---------------------------------- | ------------------------------------------------------------ |
| Gross sales                        | Total completed sales before refunds/credit notes            |
| Net sales                          | Gross sales minus refunds and credit notes                   |
| Cash collected                     | Confirmed cash payments                                      |
| M-Pesa collected                   | Confirmed M-Pesa payments                                    |
| Card collected                     | Confirmed card payments                                      |
| Insurance receivable               | Payer portion not yet paid                                   |
| Patient receivable                 | Patient balance outstanding                                  |
| Gross profit                       | Net sales minus cost of goods/services                       |
| Gross margin %                     | Gross profit divided by net sales                            |
| Stock value                        | Quantity on hand multiplied by valuation cost                |
| Stock cover days                   | Available stock divided by average daily usage               |
| Stockout days                      | Days with available stock equal to zero                      |
| Near-expiry value                  | Cost value of stock expiring within threshold                |
| Dead stock value                   | Cost value of stock with no movement beyond threshold        |
| Claim denial rate                  | Denied claims divided by submitted claims                    |
| Claim recovery rate                | Resubmitted/recovered denied amount divided by denied amount |
| Average days to payment            | Payment date minus claim submission date                     |
| Prescription warning override rate | Warning overrides divided by prescriptions with warnings     |
| Controlled medicine variance       | Physical balance minus system balance                        |
| Data access risk score             | Weighted score based on access type, sensitivity, time, role |

---

# 12. Alerts and exception reporting

Reporting should not only wait for users to open reports. It should push exceptions.

## Critical alerts

| Alert                               | Recipient                 |
| ----------------------------------- | ------------------------- |
| eTIMS invoices rejected             | Accountant/manager        |
| Cashier cash shortage               | Manager/owner             |
| Controlled medicine variance        | Pharmacist/superintendent |
| Recalled batch still sellable       | Pharmacist/manager        |
| Expired stock sold attempt          | Pharmacist/manager        |
| Critical lab result not reviewed    | Clinician/clinic manager  |
| Claim deadline approaching          | Claims officer            |
| Claim rejected                      | Claims officer/billing    |
| Bulk patient data export            | DPO/compliance            |
| After-hours sensitive record access | DPO/compliance            |
| Failed backup/sync                  | Admin/owner               |

## Warning alerts

| Alert                            | Recipient          |
| -------------------------------- | ------------------ |
| Low stock                        | Procurement        |
| Near-expiry stock                | Pharmacist/manager |
| High discounts                   | Manager/owner      |
| High refunds                     | Manager/owner      |
| Slow/dead stock                  | Procurement        |
| Unsigned clinical notes          | Clinic manager     |
| Lab results pending verification | Lab in-charge      |
| Claims missing attachments       | Claims officer     |
| Licence expiring                 | Compliance officer |
| Staff licence expiring           | Compliance officer |

---

# 13. Report scheduling

Reports should be schedulable.

| Schedule      | Reports                                                                                      |
| ------------- | -------------------------------------------------------------------------------------------- |
| End of day    | Daily sales, shift, eTIMS, payments, stock exceptions                                        |
| Daily morning | Low stock, near-expiry, claims pending, lab pending                                          |
| Weekly        | Gross margin, fast/slow movers, denials, diagnosis/service                                   |
| Monthly       | Branch performance, stock valuation, claims ageing, controlled medicine, data access summary |
| Quarterly     | Supplier performance, chronic-care, compliance scorecard                                     |
| On demand     | Batch recall, audit logs, data access investigation                                          |

## Scheduled report fields

| Field            |
| ---------------- |
| Report name      |
| Schedule         |
| Recipients       |
| Format           |
| Filters          |
| Branch scope     |
| Permission check |
| Delivery channel |
| Last run         |
| Next run         |
| Failure reason   |

---

# 14. Data quality controls

Bad reports usually come from bad data. The module should include data quality reports.

## Data quality checks

| Check                     | Example                                   |
| ------------------------- | ----------------------------------------- |
| Missing branch            | Sale without branch                       |
| Missing cashier           | Sale without cashier                      |
| Missing batch             | Medicine sold without batch               |
| Missing diagnosis         | Claim visit without diagnosis             |
| Missing ICD-10            | Claim diagnosis not coded                 |
| Missing prescriber        | Prescription without prescriber           |
| Missing patient           | Prescription medicine without patient     |
| Missing lab result        | Claimed lab test without result           |
| Missing payment reference | M-Pesa payment without code               |
| Negative stock            | Stock balance below zero                  |
| Duplicate patient         | Same name/phone/DOB                       |
| Duplicate product         | Same barcode/brand/strength               |
| Unsigned note             | Visit not signed                          |
| Unverified result         | Result printed/shared before verification |
| Claim without attachment  | Claim-ready failure                       |
| eTIMS mismatch            | Sale total differs from invoice total     |

## Data quality dashboard

Cards:

```text
Missing diagnosis
Missing ICD-10
Missing batch
Negative stock
Duplicate patients
Unverified results
Unsigned notes
Unmatched payments
Rejected eTIMS invoices
Claims missing attachments
```

---

# 15. Data model

## Main reporting tables

### `report_definitions`

| Field                     |
| ------------------------- |
| id                        |
| report_code               |
| report_name               |
| report_category           |
| description               |
| default_filters_json      |
| required_permissions_json |
| sensitive_data_flag       |
| export_allowed            |
| schedule_allowed          |
| status                    |
| created_at                |

### `report_runs`

| Field                |
| -------------------- |
| id                   |
| report_definition_id |
| run_by               |
| branch_scope_json    |
| filters_json         |
| run_started_at       |
| run_completed_at     |
| status               |
| row_count            |
| output_format        |
| output_document_id   |
| error_message        |

### `scheduled_reports`

| Field                |
| -------------------- |
| id                   |
| report_definition_id |
| schedule_name        |
| frequency            |
| recipients_json      |
| filters_json         |
| output_format        |
| delivery_channel     |
| last_run_at          |
| next_run_at          |
| status               |

### `report_exports`

| Field                   |
| ----------------------- |
| id                      |
| report_run_id           |
| exported_by             |
| export_format           |
| exported_at             |
| recipient               |
| reason                  |
| file_hash               |
| sensitive_data_included |
| approval_required       |
| approved_by             |

### `dashboard_widgets`

| Field                |
| -------------------- |
| id                   |
| dashboard_code       |
| widget_code          |
| widget_name          |
| metric_code          |
| visualization_type   |
| default_filters_json |
| refresh_interval     |
| permission_required  |
| status               |

### `metric_definitions`

| Field              |
| ------------------ |
| id                 |
| metric_code        |
| metric_name        |
| formula            |
| source_tables_json |
| dimensions_json    |
| refresh_frequency  |
| owner_role         |
| status             |

### `analytics_snapshots`

| Field          |
| -------------- |
| id             |
| snapshot_date  |
| branch_id      |
| metric_code    |
| dimension_json |
| metric_value   |
| created_at     |

### `staff_activity_logs`

| Field            |
| ---------------- |
| id               |
| user_id          |
| role             |
| branch_id        |
| module           |
| action           |
| entity_type      |
| entity_id        |
| old_value_json   |
| new_value_json   |
| reason           |
| approval_user_id |
| device_id        |
| ip_address       |
| risk_level       |
| created_at       |

### `data_access_logs`

| Field            |
| ---------------- |
| id               |
| user_id          |
| role             |
| branch_id        |
| patient_id       |
| record_type      |
| record_id        |
| action_type      |
| purpose          |
| consent_status   |
| recipient        |
| channel          |
| sensitive_flag   |
| break_glass_flag |
| device_id        |
| ip_address       |
| risk_score       |
| created_at       |

### `report_alerts`

| Field           |
| --------------- |
| id              |
| alert_type      |
| severity        |
| branch_id       |
| module          |
| entity_type     |
| entity_id       |
| metric_code     |
| threshold_value |
| actual_value    |
| message         |
| assigned_to     |
| status          |
| created_at      |
| resolved_at     |

---

# 16. API design

## Report endpoints

| Endpoint                        | Purpose                  |
| ------------------------------- | ------------------------ |
| `GET /reports`                  | List available reports   |
| `POST /reports/{code}/run`      | Run report               |
| `GET /reports/{runId}/status`   | Check report run status  |
| `GET /reports/{runId}/download` | Download output          |
| `POST /reports/{runId}/export`  | Export with audit reason |
| `POST /reports/schedule`        | Schedule report          |
| `PATCH /reports/schedule/{id}`  | Update schedule          |
| `GET /reports/history`          | View report run history  |

## Dashboard endpoints

| Endpoint                         | Purpose                        |
| -------------------------------- | ------------------------------ |
| `GET /dashboards/{code}`         | Load dashboard                 |
| `GET /dashboards/{code}/widgets` | Load widgets                   |
| `GET /metrics/{code}`            | Get metric                     |
| `POST /metrics/refresh`          | Refresh metrics                |
| `GET /analytics/trends`          | Trend data                     |
| `GET /analytics/comparison`      | Branch/user/product comparison |

## Audit endpoints

| Endpoint                             | Purpose                     |
| ------------------------------------ | --------------------------- |
| `GET /audit/staff-activity`          | Staff activity log          |
| `GET /audit/data-access`             | Patient data access log     |
| `GET /audit/exports`                 | Export log                  |
| `GET /audit/overrides`               | Override report             |
| `GET /audit/security-events`         | Failed logins, role changes |
| `POST /audit/investigation`          | Open investigation case     |
| `POST /audit/access-log/{id}/review` | Mark access reviewed        |

## Alert endpoints

| Endpoint                    | Purpose           |
| --------------------------- | ----------------- |
| `GET /alerts`               | List alerts       |
| `POST /alerts/{id}/assign`  | Assign alert      |
| `POST /alerts/{id}/resolve` | Resolve alert     |
| `POST /alerts/rules`        | Create alert rule |
| `PATCH /alerts/rules/{id}`  | Update alert rule |

---

# 17. Report generation rules

## Permission rule

```text
RULE: Run sensitive report
IF report.sensitive_data_flag = true
THEN user must have report permission
AND export reason must be captured
AND export must be logged
```

## Patient data masking rule

```text
RULE: Patient identifiers
IF user.role NOT IN [clinician, pharmacist, claims_officer, DPO, auditor]
THEN mask patient name, ID, phone, and sensitive diagnosis
UNLESS explicit permission is granted
```

## eTIMS exception rule

```text
RULE: eTIMS rejected invoice alert
IF invoice.etims_status = rejected
THEN create alert for accountant
AND include rejection reason
AND mark sale as invoice_attention_required
```

## Batch recall rule

```text
RULE: Batch recall report
IF batch.recall_status = recalled
THEN block sale and dispensing
AND create affected-stock report
AND create affected-patient/customer report
```

## Controlled medicine variance rule

```text
RULE: Controlled medicine variance
IF physical_count != system_controlled_balance
THEN create critical alert
AND require superintendent review
```

## Claims rejection rule

```text
RULE: Claim denial analytics
IF claim.status = rejected
THEN classify denial reason
AND assign correction task
AND update denial dashboard
```

## Data access anomaly rule

```text
RULE: Suspicious data access
IF sensitive_record_access = true
AND user not linked to patient care team
OR access_time outside normal hours
OR bulk_export_count > threshold
THEN create DPO review alert
```

---

# 18. Report formats

| Format             | Use                                       |
| ------------------ | ----------------------------------------- |
| On-screen table    | Daily operations                          |
| PDF                | Formal reports, compliance, management    |
| Excel              | Analysis and accounting                   |
| CSV                | System imports/exports                    |
| Dashboard card     | Quick KPIs                                |
| Chart              | Trends and comparisons                    |
| Scheduled email    | Daily/weekly summaries                    |
| Secure link        | Sensitive report sharing                  |
| API response       | Integrations                              |
| Printable register | Controlled medicines, recalls, audit pack |

## Export controls

| Control              | Requirement                         |
| -------------------- | ----------------------------------- |
| Export reason        | Required for sensitive reports      |
| Export watermark     | User, date, branch, report name     |
| File hash            | Detect tampering                    |
| Access expiry        | Secure links expire                 |
| Recipient log        | Who received report                 |
| Patient data masking | Default unless permitted            |
| Approval             | Required for bulk/sensitive exports |
| Export audit         | Permanent log                       |

---

# 19. Visual analytics

The system should provide simple visuals.

| Chart             | Best for                                       |
| ----------------- | ---------------------------------------------- |
| Line chart        | Sales, claims, visits over time                |
| Bar chart         | Branch comparison, top products, top diagnoses |
| Pie/donut         | Payment mix, category mix                      |
| Heat map          | Busy hours/days                                |
| Ageing buckets    | Claims and receivables                         |
| Exception list    | Alerts, missing documents, rejected invoices   |
| Stock cover chart | Procurement                                    |
| Funnel            | Claims: draft → submitted → approved → paid    |
| Trend cards       | Month-over-month growth                        |

For small clinics and chemists, avoid overly complex BI screens. A clear table plus a few useful charts is better than a dashboard nobody uses.

---

# 20. Offline and sync reporting

Because outlets may operate with unstable internet, reporting must distinguish local and synced data.

| Scenario                | Reporting behaviour                            |
| ----------------------- | ---------------------------------------------- |
| Offline sale            | Appears in local report and marked unsynced    |
| eTIMS queued            | Appears in pending eTIMS report                |
| Offline stock movement  | Marked pending sync                            |
| Offline lab/clinic note | Marked local pending upload                    |
| Branch sync delayed     | Head office dashboard shows stale-data warning |
| Duplicate after sync    | Conflict report                                |
| Sync failure            | Admin alert                                    |

## Sync health report

| Column                    |
| ------------------------- |
| Branch                    |
| Device                    |
| Last sync time            |
| Unsynced sales            |
| Unsynced invoices         |
| Unsynced stock movements  |
| Unsynced clinical records |
| Sync errors               |
| Action required           |

---

# 21. Data retention and archiving

Reports should not permanently depend on recalculating live records only. Historical figures should be reproducible.

## Retention design

| Data type           | Approach                                               |
| ------------------- | ------------------------------------------------------ |
| Sales               | Keep transaction-level records and daily snapshots     |
| Invoices/eTIMS      | Keep invoice identifiers, statuses, payload references |
| Stock movements     | Keep permanent stock ledger                            |
| Dispensing          | Keep prescription and dispense audit                   |
| Clinical            | Keep visit records and summaries per policy            |
| Lab                 | Keep results and corrections                           |
| Claims              | Keep claim versions, submissions, denials, payments    |
| Audit logs          | Immutable retention per compliance policy              |
| Analytics snapshots | Store daily/monthly KPI snapshots                      |
| Exports             | Store export metadata, not always report file forever  |

The health information management regulations refer to retaining health data held in the national system for at least twenty years or as specified in the Act, so the application should be configurable for long-retention health records and shorter operational cache/report files. ([health.go.ke](https://health.go.ke/sites/default/files/2024-11/FINAL%20Digital%20Health%20%28Health%20Information%20Management%29%20Regulations%2019.11.24.pdf))

---

# 22. Workflows

## A. Daily close workflow

```text
1. Cashiers close shifts
2. System compares expected vs counted cash
3. M-Pesa/card payments are reconciled
4. eTIMS status is checked
5. Daily sales report is generated
6. Stock movements are checked
7. Exceptions are shown to branch manager
8. Manager approves daily close
9. Owner/accountant receives summary
```

---

## B. Stock reporting workflow

```text
1. Sales and dispensing update stock movements
2. Inventory module recalculates stock balances
3. Reorder and stockout reports run
4. Near-expiry report runs by batch
5. Slow/dead stock report runs by movement history
6. Procurement receives suggested actions
7. Manager reviews transfer/purchase/write-off decisions
```

---

## C. Pharmacy safety reporting workflow

```text
1. Dispensing creates prescription and batch records
2. Clinical warnings, substitutions, partial dispenses are logged
3. Controlled medicine register updates
4. Prescription audit report runs
5. Controlled medicine variance report runs
6. Batch recall report is available on demand
7. Pharmacist/superintendent resolves exceptions
```

---

## D. Claims reporting workflow

```text
1. Visit and billing data create claim bundle
2. Claim validation runs
3. Missing information report updates
4. Submitted claims move to ageing report
5. Rejected claims move to denial report
6. Resubmissions and recoveries update rejection analytics
7. Payments update reconciliation and receivables
```

---

## E. Data protection audit workflow

```text
1. Every patient record view/edit/export is logged
2. Sensitive access events are scored
3. Bulk exports and after-hours access are flagged
4. DPO reviews exceptions
5. Investigation notes are recorded
6. Incident or breach workflow is opened if required
7. Monthly data access summary is generated
```

---

# 23. MVP versus later versions

## MVP

Build these first:

| Feature                     | Reason                    |
| --------------------------- | ------------------------- |
| Daily sales report          | Owner visibility          |
| Cashier shift report        | Cash control              |
| eTIMS invoice status report | Tax compliance            |
| Gross margin report         | Profitability             |
| Fast/slow movers            | Procurement               |
| Stockout report             | Avoid lost sales          |
| Near-expiry report          | Reduce losses             |
| Batch recall report         | Patient safety            |
| Controlled medicine report  | Pharmacy compliance       |
| Prescription audit          | Dispensing accountability |
| Diagnosis/service report    | Clinic management         |
| Claims rejection report     | Revenue recovery          |
| Staff activity log          | Fraud/compliance          |
| Data access log             | Data protection           |
| Basic dashboards            | Fast decision-making      |
| Export controls             | Compliance                |
| Scheduled daily summary     | Owner convenience         |

## Version 2

Add:

| Feature                            | Reason                 |
| ---------------------------------- | ---------------------- |
| Advanced dashboards                | Better management      |
| Claims ageing and denial analytics | Cashflow improvement   |
| Supplier performance reports       | Procurement quality    |
| M-Pesa reconciliation              | Payment control        |
| Data quality dashboard             | Better records         |
| Audit investigation workflow       | Compliance maturity    |
| Branch comparison                  | Chain/franchise growth |
| Report builder                     | Custom needs           |
| Scheduled reports                  | Automation             |
| Visual analytics                   | Easier interpretation  |
| Role-based masking                 | Privacy improvement    |
| KPI snapshots                      | Historical accuracy    |

## Version 3

Add:

| Feature                               | Reason                       |
| ------------------------------------- | ---------------------------- |
| Data warehouse                        | Large-scale analytics        |
| Predictive stockout forecasting       | Smarter procurement          |
| AI anomaly detection                  | Fraud and leakage detection  |
| AI claim denial prediction            | Reduce rejections            |
| National aggregate reporting adapters | Digital Health Act readiness |
| FHIR analytics exports                | Interoperability             |
| Executive mobile dashboard            | Owner convenience            |
| Benchmarking across branches          | Performance improvement      |
| Cohort analytics                      | Chronic-care management      |
| Advanced data protection risk scoring | Privacy governance           |

---

# 24. Acceptance criteria

The Reporting and Analytics Module is ready when it passes these tests:

| Test                | Expected result                                                                 |
| ------------------- | ------------------------------------------------------------------------------- |
| Daily sales         | Owner sees net sales, payment methods, category sales, branch/cashier breakdown |
| Cashier shift       | Manager sees expected cash, counted cash, variance, M-Pesa/card reconciliation  |
| eTIMS status        | Accountant sees accepted, queued, rejected, retried invoices and credit notes   |
| Gross margin        | Owner sees sales, cost, profit, margin by product/category/branch               |
| Fast/slow movers    | Procurement sees movement, stock cover, reorder/stop-buy suggestions            |
| Stockout            | Procurement sees out-of-stock and below-reorder items                           |
| Near-expiry         | Pharmacist sees batch, expiry, value at risk, suggested action                  |
| Batch recall        | Pharmacist finds affected stock, branches, patients, invoices, actions          |
| Controlled medicine | Pharmacist sees register entries and balance variances                          |
| Prescription audit  | Pharmacist sees prescriptions, substitutions, partials, warnings, approvals     |
| Diagnosis/service   | Clinic manager sees diagnoses, ICD-10-ready data, services, clinician workload  |
| Claims rejection    | Billing sees denials, reasons, correction tasks, recoverable amounts            |
| Staff activity      | Owner/compliance sees high-risk actions by user and branch                      |
| Data access         | DPO sees patient record access, exports, sensitive access, anomalies            |
| Export control      | Sensitive report export requires permission and reason                          |
| Role masking        | Unauthorized users see masked patient/clinical data                             |
| Scheduled report    | Daily summary is generated and delivered                                        |
| Alert               | Rejected eTIMS, stockout, recall, data export, or claim denial creates alert    |
| Audit               | Every report run/export is logged                                               |

---

# 25. Final product behaviour

The Reporting and Analytics Module should behave like this:

| Situation                         | Correct behaviour                                                     |
| --------------------------------- | --------------------------------------------------------------------- |
| Owner opens dashboard             | Shows sales, margin, cash, stock, claims, branch performance          |
| Manager closes day                | Shift, cash, M-Pesa, eTIMS, refunds, discounts reviewed               |
| Accountant checks tax             | eTIMS status and credit notes visible                                 |
| Procurement plans buying          | Fast movers, stockouts, reorder, dead stock visible                   |
| Pharmacist manages risk           | Expiry, recall, controlled medicine, prescription audit visible       |
| Clinic manager reviews operations | Visits, diagnoses, services, waiting time, clinician workload visible |
| Claims officer follows revenue    | Rejections, missing documents, ageing, reconciliation visible         |
| DPO reviews privacy               | Data access, exports, sensitive record access, anomalies visible      |
| Auditor investigates issue        | Staff action and data access trail available                          |
| Branch goes offline               | Reports show stale/unsynced data clearly                              |
| Sensitive report is exported      | Permission, reason, watermark, and audit log required                 |

The key design principle is:

**Every important action in the business should either become a useful management report, a compliance record, an audit trail, or an exception alert.**
