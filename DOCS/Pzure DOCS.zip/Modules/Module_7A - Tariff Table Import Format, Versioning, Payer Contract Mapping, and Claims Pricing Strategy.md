Correct. Module 7 needs a formal **tariff data contract** before the import tool is built.

I would close this as:

```text
ADR-024: Tariff Table Import Format, Versioning, Payer Contract Mapping, and Claims Pricing Strategy
```

Kenya’s current SHA tariff instrument is **Legal Notice 56 of 2025: Tariffs for Healthcare Services, 2025**, published and commenced on **28 February 2025**. Kenya Law also notes that this 2025 notice repeals the earlier 2024 tariff notice. That means the system must treat tariffs as **versioned legal/contractual price schedules**, not as ordinary editable price lists. ([Kenya Law][1])

---

# 1. Architecture decision

Use a **generic tariff engine** with payer-specific import templates.

```text
Canonical internal tariff model:
    payer
    scheme
    contract
    tariff table
    tariff version
    tariff line
    service/item mapping
    effective date range
    access rules
    pre-authorisation rules
    attachment rules
    limits
    co-pay / patient portion
    claim code
```

Then provide import templates for:

```text
1. SHA tariff
2. Private insurer tariff
3. Employer/corporate tariff
4. Drug formulary tariff
5. Lab tariff
6. Procedure tariff
7. Package/bundled tariff
8. Capitation tariff
```

The import tool should **not** be SHA-only. SHA is one payer. Private insurers and employer schemes will vary, so the internal shape must be more general.

---

# 2. Why this matters

SHA regulations state that providers lodge claims for payment of healthcare services, that SHA pays based on prescribed tariffs, and that claims are reviewed and processed through the Centralized Digital Platform. They also require claims to include patient identifiers, clinical details, and the amount claimed. ([Kenya Law][2])

The same regulations say claim processing should be guided by prescribed tariffs and formularies used for benefits-package development, diagnostics mapping, costing, and tariff development. They also provide for pre-authorisation of specified services and require beneficiary, provider/facility, and service details in the pre-authorisation request. ([Kenya Law][2])

So the tariff import format must support more than “service code + price.” It needs:

```text
service identity
payer code
internal service mapping
effective dates
facility/access level
benefit package
pre-authorisation flag
referral flag
attachments
limits
co-pay
claim category
exclusions
versioning
```

---

# 3. Recommended tariff model

## 3.1 Tariff hierarchy

```text
Payer
    ↓
Benefit scheme / contract
    ↓
Tariff table
    ↓
Tariff version
    ↓
Tariff line
    ↓
Mapped internal service/product/lab/procedure/drug/package
```

Example:

```text
Payer: SHA
Scheme: Social Health Insurance Fund
Contract: SHA Contract 2026 - Branch Group A
Tariff table: SHA Tariffs for Healthcare Services
Version: LN56-2025-effective-2025-02-28
Tariff line: Consultation outpatient level 2/3
Internal mapping: SVC-CONS-GP
```

---

# 4. Tariff table data model

## `claims.tariff_tables`

| Field              | Purpose                                     |
| ------------------ | ------------------------------------------- |
| id                 | Internal ID                                 |
| payer_id           | SHA/private insurer/employer                |
| scheme_id          | Benefit scheme                              |
| contract_id        | Contract                                    |
| tariff_table_code  | Example: `SHA-LN56-2025`                    |
| tariff_table_name  | Human-readable name                         |
| tariff_type        | SHA, private, employer, capitation, package |
| source_document_id | Uploaded tariff/contract                    |
| source_reference   | Legal notice / contract / insurer document  |
| currency           | KES                                         |
| status             | draft, active, expired, superseded          |
| created_by         | User                                        |
| created_at         | Timestamp                                   |

---

## `claims.tariff_versions`

| Field           | Purpose                            |
| --------------- | ---------------------------------- |
| id              | Version ID                         |
| tariff_table_id | Parent tariff table                |
| version_code    | `2025.02.28`, `AAR-2026-V1`, etc.  |
| effective_from  | Start date                         |
| effective_to    | End date                           |
| import_batch_id | Link to import                     |
| approved_by     | Approver                           |
| approved_at     | Approval time                      |
| status          | draft, active, superseded, retired |
| notes           | Change notes                       |

---

## `claims.tariff_lines`

| Field                 | Purpose                                                         |
| --------------------- | --------------------------------------------------------------- |
| id                    | Internal line ID                                                |
| tariff_version_id     | Parent version                                                  |
| line_number           | Source line number                                              |
| benefit_fund          | PHC, SHIF, ECCIF, private OPD, corporate OPD                    |
| benefit_package       | Outpatient, inpatient, chronic, maternity, emergency            |
| service_category      | consultation, lab, drug, procedure, imaging, package, admission |
| service_group         | OPD, diagnostics, pharmacy, minor procedure                     |
| payer_service_code    | SHA/insurer tariff code                                         |
| payer_service_name    | Name from tariff source                                         |
| internal_item_type    | service, product, lab_test, procedure, package                  |
| internal_item_id      | Mapped item                                                     |
| internal_item_code    | Internal code                                                   |
| facility_level_min    | Optional                                                        |
| facility_level_max    | Optional                                                        |
| branch_scope          | all/specific                                                    |
| provider_cadre_rule   | Optional                                                        |
| diagnosis_rule        | Optional                                                        |
| age_rule              | Optional                                                        |
| sex_rule              | Optional                                                        |
| unit_of_measure       | visit, test, item, tablet, session, day, package                |
| tariff_amount         | Payer allowed amount                                            |
| patient_copay_type    | none, fixed, percent                                            |
| patient_copay_value   | Amount or percent                                               |
| payer_portion_formula | How payer amount is calculated                                  |
| quantity_min          | Optional                                                        |
| quantity_max          | Optional                                                        |
| frequency_limit       | Optional                                                        |
| limit_period          | visit, day, month, year, benefit_period                         |
| annual_limit_amount   | Optional                                                        |
| requires_preauth      | Yes/no                                                          |
| requires_referral     | Yes/no                                                          |
| requires_diagnosis    | Yes/no                                                          |
| required_attachments  | JSON/list                                                       |
| exclusion_flag        | Yes/no                                                          |
| exclusion_reason      | Optional                                                        |
| claimable_flag        | Yes/no                                                          |
| effective_from        | Line effective start                                            |
| effective_to          | Line effective end                                              |
| status                | draft, active, inactive, mapped, unmapped                       |

---

# 5. Canonical tariff import file

Use a CSV/XLSX import format with one row per tariff line.

## 5.1 Canonical tariff import headers

```csv
tariff_table_code,
tariff_table_name,
version_code,
source_reference,
payer_code,
payer_name,
scheme_code,
scheme_name,
contract_code,
effective_from,
effective_to,
benefit_fund,
benefit_package,
service_category,
service_group,
payer_service_code,
payer_service_name,
payer_service_description,
internal_item_type,
internal_item_code,
facility_level_min,
facility_level_max,
provider_cadre_rule,
diagnosis_rule,
age_min_days,
age_max_days,
sex_rule,
unit_of_measure,
tariff_amount,
currency,
patient_copay_type,
patient_copay_value,
quantity_min,
quantity_max,
frequency_limit,
limit_period,
annual_limit_amount,
requires_preauth,
requires_referral,
requires_diagnosis,
required_attachments,
claimable_flag,
exclusion_flag,
exclusion_reason,
mapping_confidence,
notes
```

The import tool should allow unknown/internal mappings initially, but not activate claim lines until required mappings are resolved.

---

# 6. SHA tariff import format

## 6.1 SHA-specific fields

SHA tariffs need to handle:

| Field             | Why                                                  |
| ----------------- | ---------------------------------------------------- |
| Benefit fund      | PHC, SHIF, Emergency/Chronic/Critical Illness        |
| Access point      | Facility level or provider access category           |
| Scope             | Outpatient, inpatient, chronic, emergency, maternity |
| Access rules      | Referral, level of care, service limits              |
| Tariff            | Payable amount                                       |
| Limits            | Visits, frequency, annual limit                      |
| Pre-authorisation | For specified services                               |
| Attachments       | Clinical notes, results, referral, prescription      |

SHA regulations require providers to deliver services within benefit limits, verify beneficiary data, provide medically necessary care, maintain beneficiary records, and maintain systems for linking benefits administration and claims submission to the Centralized Digital Platform. ([Kenya Law][2])

## 6.2 SHA sample CSV

```csv
tariff_table_code,tariff_table_name,version_code,source_reference,payer_code,payer_name,scheme_code,scheme_name,contract_code,effective_from,effective_to,benefit_fund,benefit_package,service_category,service_group,payer_service_code,payer_service_name,payer_service_description,internal_item_type,internal_item_code,facility_level_min,facility_level_max,provider_cadre_rule,diagnosis_rule,age_min_days,age_max_days,sex_rule,unit_of_measure,tariff_amount,currency,patient_copay_type,patient_copay_value,quantity_min,quantity_max,frequency_limit,limit_period,annual_limit_amount,requires_preauth,requires_referral,requires_diagnosis,required_attachments,claimable_flag,exclusion_flag,exclusion_reason,mapping_confidence,notes
SHA-LN56-2025,SHA Tariffs for Healthcare Services,2025-02-28,Legal Notice 56 of 2025,SHA,Social Health Authority,SHIF-OPD,Social Health Insurance Fund Outpatient,SHA-CONTRACT-2026,2025-02-28,,SHIF,Outpatient,consultation,OPD,SHA-OPD-CONS-GP,Outpatient consultation,General outpatient consultation,service,SVC-CONS-GP,2,4,clinical_officer_or_doctor,required,,,all,visit,0,KES,none,0,1,1,1,visit,,false,false,true,"clinical_note;diagnosis",true,false,,medium,Amount to be loaded from official SHA tariff source
SHA-LN56-2025,SHA Tariffs for Healthcare Services,2025-02-28,Legal Notice 56 of 2025,SHA,Social Health Authority,SHIF-LAB,Social Health Insurance Fund Diagnostics,SHA-CONTRACT-2026,2025-02-28,,SHIF,Outpatient,lab,Diagnostics,SHA-LAB-MAL-RDT,Malaria RDT,Malaria rapid diagnostic test,lab_test,LAB-MAL-RDT,2,4,lab_personnel,fever_or_malaria_suspected,,,all,test,0,KES,none,0,1,1,1,visit,,false,false,true,"verified_lab_result;clinical_indication",true,false,,medium,Amount to be loaded from official SHA tariff source
SHA-LN56-2025,SHA Tariffs for Healthcare Services,2025-02-28,Legal Notice 56 of 2025,SHA,Social Health Authority,SHIF-PHARM,Social Health Insurance Fund Pharmacy,SHA-CONTRACT-2026,2025-02-28,,SHIF,Outpatient,drug,Pharmacy,SHA-DRUG-AMOX-500,Amoxicillin 500mg capsule,Antibiotic medicine line,product,MED-AMOX-500-CAP,2,4,pharmacist_or_pharmtech,required,,,all,capsule,0,KES,none,0,1,21,1,visit,,false,false,true,"prescription;dispense_record",true,false,,low,Drug tariffs may be formulary-based; verify source
```

Important: the `tariff_amount` values above are placeholders. The import file should be populated from the official SHA tariff schedule, contract, or payer source approved by the client. Do not let developers type amounts manually into production without approval.

---

# 7. Private insurer tariff import format

Private insurers are more likely to have:

```text
scheme-specific prices
pre-authorisation rules
co-pay rules
exclusions
drug formulary limits
provider network restrictions
family/corporate limits
session limits
```

## 7.1 Private insurer sample CSV

```csv
tariff_table_code,tariff_table_name,version_code,source_reference,payer_code,payer_name,scheme_code,scheme_name,contract_code,effective_from,effective_to,benefit_fund,benefit_package,service_category,service_group,payer_service_code,payer_service_name,payer_service_description,internal_item_type,internal_item_code,facility_level_min,facility_level_max,provider_cadre_rule,diagnosis_rule,age_min_days,age_max_days,sex_rule,unit_of_measure,tariff_amount,currency,patient_copay_type,patient_copay_value,quantity_min,quantity_max,frequency_limit,limit_period,annual_limit_amount,requires_preauth,requires_referral,requires_diagnosis,required_attachments,claimable_flag,exclusion_flag,exclusion_reason,mapping_confidence,notes
AAR-OPD-2026,AAR Corporate OPD Tariff,2026-V1,Contract AAR/CLIENT/2026,AAR,AAR Insurance,AAR-CORP-OPD,Corporate Outpatient,AAR-CONTRACT-2026,2026-01-01,2026-12-31,PRIVATE,Outpatient,consultation,OPD,AAR-CONS-GP,GP consultation,Outpatient general consultation,service,SVC-CONS-GP,,,,required,,,all,visit,2500,KES,fixed,500,1,1,1,visit,,false,false,true,"clinical_note;diagnosis",true,false,,high,
AAR-OPD-2026,AAR Corporate OPD Tariff,2026-V1,Contract AAR/CLIENT/2026,AAR,AAR Insurance,AAR-CORP-OPD,Corporate Outpatient,AAR-CONTRACT-2026,2026-01-01,2026-12-31,PRIVATE,Outpatient,lab,Diagnostics,AAR-LAB-CBC,CBC/FBC,Complete blood count,lab_test,LAB-CBC,,,,required,,,all,test,1200,KES,none,0,1,1,1,visit,,false,false,true,"verified_lab_result",true,false,,high,
AAR-OPD-2026,AAR Corporate OPD Tariff,2026-V1,Contract AAR/CLIENT/2026,AAR,AAR Insurance,AAR-CORP-OPD,Corporate Outpatient,AAR-CONTRACT-2026,2026-01-01,2026-12-31,PRIVATE,Outpatient,procedure,Minor procedure,AAR-PROC-DRESS,Wound dressing,Wound dressing procedure,procedure,PROC-DRESSING,,,,required,,,all,session,1500,KES,percent,10,1,3,3,month,,true,false,true,"procedure_note;clinical_note",true,false,,high,
AAR-OPD-2026,AAR Corporate OPD Tariff,2026-V1,Contract AAR/CLIENT/2026,AAR,AAR Insurance,AAR-CORP-OPD,Corporate Outpatient,AAR-CONTRACT-2026,2026-01-01,2026-12-31,PRIVATE,Outpatient,drug,Pharmacy,AAR-DRUG-FORMULARY,Formulary medicine,Reimbursed formulary medicine,product,FORMULARY_GROUP,,,,required,,,all,item,0,KES,percent,10,1,30,1,visit,,false,false,true,"prescription;dispense_record",true,false,,medium,Use drug formulary file for item-level pricing
```

---

# 8. Employer/corporate tariff format

Employer schemes often have simpler rules:

```text
consultation covered
lab covered up to limit
medicine covered up to limit
co-pay optional
credit billing to employer
monthly invoice/reconciliation
```

## Sample employer CSV

```csv
tariff_table_code,tariff_table_name,version_code,source_reference,payer_code,payer_name,scheme_code,scheme_name,contract_code,effective_from,effective_to,benefit_fund,benefit_package,service_category,service_group,payer_service_code,payer_service_name,payer_service_description,internal_item_type,internal_item_code,facility_level_min,facility_level_max,provider_cadre_rule,diagnosis_rule,age_min_days,age_max_days,sex_rule,unit_of_measure,tariff_amount,currency,patient_copay_type,patient_copay_value,quantity_min,quantity_max,frequency_limit,limit_period,annual_limit_amount,requires_preauth,requires_referral,requires_diagnosis,required_attachments,claimable_flag,exclusion_flag,exclusion_reason,mapping_confidence,notes
CORP-ABC-2026,ABC Ltd Staff Medical Scheme,2026-V1,ABC Contract 2026,ABC-LTD,ABC Limited,ABC-STAFF-OPD,ABC Staff Outpatient,ABC-CONTRACT-2026,2026-01-01,2026-12-31,EMPLOYER,Outpatient,consultation,OPD,ABC-CONS-GP,Consultation,Staff outpatient consultation,service,SVC-CONS-GP,,,,required,,,all,visit,1800,KES,none,0,1,1,1,visit,50000,false,false,true,"clinical_note;diagnosis",true,false,,high,
CORP-ABC-2026,ABC Ltd Staff Medical Scheme,2026-V1,ABC Contract 2026,ABC-LTD,ABC Limited,ABC-STAFF-OPD,ABC Staff Outpatient,ABC-CONTRACT-2026,2026-01-01,2026-12-31,EMPLOYER,Outpatient,lab,Diagnostics,ABC-LAB-STD,Standard lab test,Employer standard lab coverage,lab_test,LAB_GROUP_BASIC,,,,required,,,all,test,1000,KES,none,0,1,5,month,50000,false,false,true,"verified_lab_result",true,false,,medium,
CORP-ABC-2026,ABC Ltd Staff Medical Scheme,2026-V1,ABC Contract 2026,ABC-LTD,ABC Limited,ABC-STAFF-OPD,ABC Staff Outpatient,ABC-CONTRACT-2026,2026-01-01,2026-12-31,EMPLOYER,Outpatient,drug,Pharmacy,ABC-DRUG-OPD,OPD medicines,Staff outpatient medicines,product,PRODUCT_GROUP_MEDICINES,,,,required,,,all,item,0,KES,none,0,1,30,visit,50000,false,false,true,"prescription;dispense_record",true,false,,medium,Use retail price less agreed discount unless formulary override exists
```

---

# 9. Drug formulary tariff file

Drug tariffs are different from consultation/lab/procedure tariffs because they need product, ingredient, pack, unit, formulary status, substitution, and quantity rules.

## Drug formulary import headers

```csv
tariff_table_code,
version_code,
payer_code,
scheme_code,
effective_from,
effective_to,
payer_drug_code,
internal_product_code,
generic_name,
brand_name,
strength,
dosage_form,
route,
pack_size,
unit_of_measure,
reimbursement_unit,
unit_tariff,
max_quantity_per_visit,
max_days_supply,
formulary_status,
requires_preauth,
requires_diagnosis,
requires_prescription,
substitution_allowed,
patient_copay_type,
patient_copay_value,
required_attachments,
exclusion_flag,
exclusion_reason,
notes
```

## Sample drug formulary CSV

```csv
tariff_table_code,version_code,payer_code,scheme_code,effective_from,effective_to,payer_drug_code,internal_product_code,generic_name,brand_name,strength,dosage_form,route,pack_size,unit_of_measure,reimbursement_unit,unit_tariff,max_quantity_per_visit,max_days_supply,formulary_status,requires_preauth,requires_diagnosis,requires_prescription,substitution_allowed,patient_copay_type,patient_copay_value,required_attachments,exclusion_flag,exclusion_reason,notes
AAR-OPD-2026,2026-V1,AAR,AAR-CORP-OPD,2026-01-01,2026-12-31,AAR-AMOX-500,MED-AMOX-500-CAP,Amoxicillin,,500mg,capsule,oral,21,capsule,capsule,35,21,7,preferred,false,true,true,true,percent,10,"prescription;dispense_record",false,,
AAR-OPD-2026,2026-V1,AAR,AAR-CORP-OPD,2026-01-01,2026-12-31,AAR-ATOR-20,MED-ATOR-20-TAB,Atorvastatin,,20mg,tablet,oral,30,tablet,tablet,60,30,30,preferred,false,true,true,true,percent,10,"prescription;dispense_record",false,,
AAR-OPD-2026,2026-V1,AAR,AAR-CORP-OPD,2026-01-01,2026-12-31,AAR-NONFORM,PRODUCT_GROUP_NON_FORMULARY,Non-formulary medicines,,,various,various,,item,item,0,0,0,excluded,true,true,true,false,none,0,"preauth_approval;prescription;dispense_record",true,Non-formulary medicine requires approval,
```

---

# 10. Lab tariff import file

Lab tariffs need mapping to the internal lab catalogue and sometimes LOINC/external lab codes.

## Lab tariff headers

```csv
tariff_table_code,
version_code,
payer_code,
scheme_code,
effective_from,
effective_to,
payer_lab_code,
internal_lab_test_code,
loinc_code,
test_name,
specimen_type,
in_house_or_external,
external_lab_code,
unit_of_measure,
tariff_amount,
patient_copay_type,
patient_copay_value,
requires_preauth,
requires_referral,
requires_diagnosis,
required_attachments,
max_quantity_per_visit,
frequency_limit,
limit_period,
claimable_flag,
notes
```

## Sample lab tariff CSV

```csv
tariff_table_code,version_code,payer_code,scheme_code,effective_from,effective_to,payer_lab_code,internal_lab_test_code,loinc_code,test_name,specimen_type,in_house_or_external,external_lab_code,unit_of_measure,tariff_amount,patient_copay_type,patient_copay_value,requires_preauth,requires_referral,requires_diagnosis,required_attachments,max_quantity_per_visit,frequency_limit,limit_period,claimable_flag,notes
SHA-LN56-2025,2025-02-28,SHA,SHIF-LAB,2025-02-28,,SHA-LAB-MAL-RDT,LAB-MAL-RDT,,Malaria RDT,blood,in_house,,test,0,none,0,false,false,true,"verified_lab_result;clinical_indication",1,1,visit,true,Amount from official SHA tariff source
AAR-OPD-2026,2026-V1,AAR,AAR-CORP-OPD,2026-01-01,2026-12-31,AAR-LAB-CBC,LAB-CBC,,Complete blood count,whole_blood,in_house,,test,1200,none,0,false,false,true,"verified_lab_result",1,1,visit,true,
AAR-OPD-2026,2026-V1,AAR,AAR-CORP-OPD,2026-01-01,2026-12-31,AAR-LAB-HBA1C,LAB-HBA1C,,HbA1c,blood,external,EXT-HBA1C,test,2500,percent,10,false,false,true,"external_lab_result;clinical_note",1,1,month,true,
```

---

# 11. Procedure tariff import file

Procedures often need pre-authorisation, referral, notes, limits, and sometimes package pricing.

## Procedure tariff headers

```csv
tariff_table_code,
version_code,
payer_code,
scheme_code,
effective_from,
effective_to,
payer_procedure_code,
internal_procedure_code,
procedure_name,
procedure_category,
unit_of_measure,
tariff_amount,
facility_level_min,
facility_level_max,
requires_preauth,
requires_referral,
requires_diagnosis,
required_attachments,
max_quantity_per_visit,
frequency_limit,
limit_period,
patient_copay_type,
patient_copay_value,
claimable_flag,
notes
```

## Sample procedure CSV

```csv
tariff_table_code,version_code,payer_code,scheme_code,effective_from,effective_to,payer_procedure_code,internal_procedure_code,procedure_name,procedure_category,unit_of_measure,tariff_amount,facility_level_min,facility_level_max,requires_preauth,requires_referral,requires_diagnosis,required_attachments,max_quantity_per_visit,frequency_limit,limit_period,patient_copay_type,patient_copay_value,claimable_flag,notes
AAR-OPD-2026,2026-V1,AAR,AAR-CORP-OPD,2026-01-01,2026-12-31,AAR-PROC-NEB,PROC-NEB,Nebulization,minor_procedure,session,1500,,,false,false,true,"procedure_note;clinical_note",3,3,visit,percent,10,true,
AAR-OPD-2026,2026-V1,AAR,AAR-CORP-OPD,2026-01-01,2026-12-31,AAR-PROC-DRESS,PROC-DRESSING,Wound dressing,minor_procedure,session,1200,,,false,false,true,"procedure_note",5,5,month,percent,10,true,
AAR-OPD-2026,2026-V1,AAR,AAR-CORP-OPD,2026-01-01,2026-12-31,AAR-PROC-SUTURE,PROC-SUTURE,Suturing,minor_surgery,session,3500,,,true,false,true,"procedure_note;clinical_note;preauth_approval",1,1,visit,percent,10,true,
```

---

# 12. Package / bundled tariff import file

Packages require a header plus components.

## Package header file

```csv
package_code,
package_name,
tariff_table_code,
version_code,
payer_code,
scheme_code,
effective_from,
effective_to,
package_category,
tariff_amount,
currency,
patient_copay_type,
patient_copay_value,
requires_preauth,
requires_referral,
required_attachments,
claimable_flag,
notes
```

## Package components file

```csv
package_code,
component_type,
component_code,
component_name,
included_quantity,
included_flag,
separately_billable_flag,
overage_rule,
notes
```

## Sample package

```csv
package_code,package_name,tariff_table_code,version_code,payer_code,scheme_code,effective_from,effective_to,package_category,tariff_amount,currency,patient_copay_type,patient_copay_value,requires_preauth,requires_referral,required_attachments,claimable_flag,notes
PKG-FEVER-OPD,Fever outpatient package,AAR-OPD-2026,2026-V1,AAR,AAR-CORP-OPD,2026-01-01,2026-12-31,outpatient_package,3500,KES,percent,10,false,false,"clinical_note;diagnosis;lab_result",true,
```

```csv
package_code,component_type,component_code,component_name,included_quantity,included_flag,separately_billable_flag,overage_rule,notes
PKG-FEVER-OPD,service,SVC-CONS-GP,Consultation,1,true,false,not_allowed,
PKG-FEVER-OPD,lab_test,LAB-MAL-RDT,Malaria RDT,1,true,false,not_allowed,
PKG-FEVER-OPD,lab_test,LAB-RBS,Random blood sugar,1,true,false,not_allowed,
PKG-FEVER-OPD,product,PRODUCT_GROUP_BASIC_MEDICINES,Basic medicines,1,true,true,patient_pays_overage,Within package medicine cap
```

---

# 13. Capitation tariff format

Capitation is not priced per normal service line. It requires encounter reporting and exception billing.

## Capitation import headers

```csv
payer_code,
scheme_code,
contract_code,
effective_from,
effective_to,
capitation_group_code,
capitation_group_name,
member_category,
amount_per_member,
period,
covered_service_categories,
excluded_service_categories,
exception_billable_categories,
requires_encounter_reporting,
notes
```

## Sample capitation CSV

```csv
payer_code,scheme_code,contract_code,effective_from,effective_to,capitation_group_code,capitation_group_name,member_category,amount_per_member,period,covered_service_categories,excluded_service_categories,exception_billable_categories,requires_encounter_reporting,notes
ABC-LTD,ABC-CAP-OPD,ABC-CONTRACT-2026,2026-01-01,2026-12-31,ABC-CAP-STAFF,ABC Staff OPD Capitation,employee,1200,month,"consultation;basic_lab;basic_drugs","specialist;external_lab;minor_surgery","external_lab;procedure;non_formulary_drugs",true,Normal OPD services included; exceptions separately billable
```

---

# 14. Import workflow

## 14.1 Import lifecycle

```text
Upload tariff file
    ↓
Validate file structure
    ↓
Load into staging table
    ↓
Validate payer/scheme/contract
    ↓
Validate effective dates
    ↓
Validate numeric amounts
    ↓
Validate service category
    ↓
Validate internal item mapping
    ↓
Flag unmapped lines
    ↓
Review errors/warnings
    ↓
Approve import batch
    ↓
Activate tariff version
    ↓
Old version superseded by effective date
```

## 14.2 Import statuses

```text
Uploaded
Parsed
Validation failed
Validation passed with warnings
Mapping required
Ready for approval
Approved
Activated
Rejected
Rolled back
Superseded
```

---

# 15. Validation rules

## Hard validation errors

| Error                                             | Behaviour       |
| ------------------------------------------------- | --------------- |
| Missing payer code                                | Reject row      |
| Missing scheme code                               | Reject row      |
| Missing effective_from                            | Reject row      |
| Invalid date range                                | Reject row      |
| Negative tariff amount                            | Reject row      |
| Missing service category                          | Reject row      |
| Unknown internal item type                        | Reject row      |
| Required boolean invalid                          | Reject row      |
| Duplicate active payer code for same version/item | Reject row      |
| Currency not KES or approved currency             | Reject row      |
| Claimable line with no payer service code         | Reject row      |
| Claimable line with no internal mapping           | Cannot activate |

## Warnings

| Warning                | Behaviour                                         |
| ---------------------- | ------------------------------------------------- |
| Internal item unmapped | Allow draft, block activation                     |
| LOINC missing for lab  | Allow, mark interoperability incomplete           |
| Attachment rule empty  | Warn for lab/procedure/drug                       |
| Pre-auth not specified | Default false but warn                            |
| Facility level blank   | Allow if payer contract does not require          |
| Tariff amount zero     | Warn unless capitation/free/package/included line |
| Mapping confidence low | Require review before activation                  |

---

# 16. Tariff versioning rules

## Version activation

| Rule                                  | Behaviour                                                    |
| ------------------------------------- | ------------------------------------------------------------ |
| New version same payer/scheme         | Can overlap only if line-level rules do not conflict         |
| Same service and same effective dates | Reject duplicate                                             |
| New version effective later           | Previous version gets effective_to automatically if approved |
| Claim already created                 | Keeps tariff version used at claim creation                  |
| Claim resubmitted                     | Uses original tariff unless payer requires current tariff    |
| Backdated tariff                      | Requires manager/claims-admin approval                       |
| Retired tariff line                   | Old claims remain valid; new claims cannot use it            |

## Data preservation

Each claim line must store:

```text
tariff_line_id
tariff_version_id
payer_service_code
unit_tariff_at_claim_time
quantity
gross_amount
patient_portion
payer_portion
pricing_rule_snapshot_json
```

This prevents old claims changing when tariffs are updated.

---

# 17. Tariff mapping UI

The import tool needs a mapping workbench.

## Mapping screen columns

| Column                  |
| ----------------------- |
| Import row number       |
| Payer service code      |
| Payer service name      |
| Service category        |
| Tariff amount           |
| Suggested internal item |
| Internal item type      |
| Mapping confidence      |
| Mapping status          |
| Required attachments    |
| Pre-auth flag           |
| Effective dates         |
| Errors/warnings         |
| Reviewer                |
| Approval status         |

## Mapping actions

```text
Map to internal service
Map to lab test
Map to product
Map to procedure
Map to package
Create new internal item
Mark as excluded
Mark as capitation-included
Split into multiple internal items
Request SME review
Approve mapping
Reject row
```

---

# 18. API design for tariff import

## Endpoints

| Endpoint                                       | Purpose                 |
| ---------------------------------------------- | ----------------------- |
| `POST /claims/tariff-imports`                  | Upload tariff file      |
| `GET /claims/tariff-imports/{id}`              | View import batch       |
| `GET /claims/tariff-imports/{id}/rows`         | View parsed rows        |
| `POST /claims/tariff-imports/{id}/validate`    | Validate batch          |
| `POST /claims/tariff-imports/{id}/auto-map`    | Suggest mappings        |
| `PATCH /claims/tariff-import-rows/{rowId}/map` | Map row                 |
| `POST /claims/tariff-imports/{id}/approve`     | Approve batch           |
| `POST /claims/tariff-imports/{id}/activate`    | Activate tariff version |
| `POST /claims/tariff-imports/{id}/rollback`    | Rollback if not used    |
| `GET /claims/tariffs/lookup`                   | Price a service/item    |
| `GET /claims/tariffs/differences`              | Compare versions        |

---

# 19. Tariff lookup logic

## Input

```json
{
  "payer_code": "AAR",
  "scheme_code": "AAR-CORP-OPD",
  "branch_id": "BR001",
  "service_date": "2026-05-22",
  "internal_item_type": "lab_test",
  "internal_item_code": "LAB-CBC",
  "patient_id": "PT0001",
  "diagnosis_code": "I10",
  "quantity": 1
}
```

## Output

```json
{
  "tariff_found": true,
  "tariff_version": "2026-V1",
  "payer_service_code": "AAR-LAB-CBC",
  "tariff_amount": 1200,
  "currency": "KES",
  "patient_copay_type": "none",
  "patient_copay_value": 0,
  "patient_portion": 0,
  "payer_portion": 1200,
  "requires_preauth": false,
  "requires_referral": false,
  "requires_diagnosis": true,
  "required_attachments": ["verified_lab_result"],
  "claimable": true,
  "warnings": []
}
```

---

# 20. Pricing precedence

When multiple pricing rules exist, use precedence:

```text
1. Patient-specific approval / pre-auth approved amount
2. Scheme-specific tariff line
3. Contract-specific tariff line
4. Payer default tariff
5. Employer/corporate tariff
6. Branch cash price list
7. Manual approved price override
```

Every override must be audited.

---

# 21. Claim validation rules from tariff

The tariff line drives claim readiness.

| Tariff field             | Claim validation                        |
| ------------------------ | --------------------------------------- |
| `requires_preauth`       | Approved preauth required               |
| `requires_referral`      | Referral attachment required            |
| `requires_diagnosis`     | ICD diagnosis required                  |
| `required_attachments`   | Documents/results/prescription required |
| `quantity_max`           | Quantity above limit blocked/split      |
| `frequency_limit`        | Prior claims checked                    |
| `exclusion_flag`         | Not claimable                           |
| `facility_level_min/max` | Branch scope checked                    |
| `provider_cadre_rule`    | Clinician/provider checked              |
| `claimable_flag`         | Claim line allowed or patient-pay       |

---

# 22. Reports needed for tariff governance

| Report                         | Purpose                       |
| ------------------------------ | ----------------------------- |
| Unmapped tariff lines          | Import cleanup                |
| Low-confidence mappings        | SME review                    |
| Tariff changes by version      | Governance                    |
| Services with no active tariff | Claim risk                    |
| Claims using expired tariff    | Audit                         |
| Tariff mismatch denials        | Denial reduction              |
| Pre-auth-required services     | Claims readiness              |
| Zero-amount tariff lines       | Review free/included services |
| Package overage report         | Patient balance control       |

---

# 23. Updated sprint addition

Add a dedicated tariff-import sprint before building full claims.

## New sprint: Tariff Import and Pricing Engine Foundation

### Scope

| Workstream                      | Deliverable                        |
| ------------------------------- | ---------------------------------- |
| ADR-024                         | Tariff import decision             |
| Canonical tariff schema         | `claims.tariff_*`                  |
| Tariff import staging           | Upload/parse/validate              |
| SHA import template             | SHA-specific profile               |
| Private insurer import template | Insurer profile                    |
| Employer import template        | Corporate profile                  |
| Drug formulary import           | Product/formulary tariff           |
| Lab tariff import               | Lab-test tariff                    |
| Procedure tariff import         | Procedure tariff                   |
| Package/capitation import       | Bundled and capitation             |
| Mapping workbench               | Import row to internal item        |
| Pricing lookup API              | Tariff lookup                      |
| Claim validation hooks          | Preauth/attachments/limits         |
| Versioning workflow             | Approve/activate/supersede         |
| Reports                         | Unmapped, changed, expired tariffs |

### Acceptance criteria

| Test                              | Expected result                                 |
| --------------------------------- | ----------------------------------------------- |
| SHA tariff file uploaded          | Rows parsed into staging                        |
| Private insurer file uploaded     | Rows parsed and validated                       |
| Missing internal mapping          | Row cannot activate                             |
| Duplicate active line             | Validation error                                |
| New tariff version activated      | Old version preserved                           |
| Claim priced                      | Correct tariff version used                     |
| Claim line requires preauth       | Claim validation blocks without approval        |
| Lab tariff requires result        | Claim validation requires verified lab result   |
| Drug tariff requires prescription | Claim validation requires prescription/dispense |
| Tariff updated                    | Existing claims preserve old price              |
| Unmapped report                   | Shows rows needing action                       |

---

# 24. Final recommendation

Implement Module 7 tariffs like this:

```text
MVP:
    generic tariff engine
    SHA import template
    private insurer import template
    employer scheme import template
    drug formulary import
    lab/procedure/package import
    mapping workbench
    tariff versioning
    pricing lookup API
    claim validation hooks

Version 2:
    payer-specific import profiles
    remittance and denial feedback into tariff mappings
    automated tariff comparison
    payer portal/API pricing checks

Version 3:
    contract profitability analytics
    AI tariff-mapping suggestions
    advanced package/capitation analytics
```

The core rule should be:

**No claimable service, lab test, drug, procedure, or package should be submitted unless it maps to an active payer tariff version, has a preserved price snapshot, satisfies pre-authorisation and attachment rules, and can be traced back to the source tariff document or contract.**

[1]: https://new.kenyalaw.org/akn/ke/act/ln/2025/56/eng%402025-02-28 "
      Tariffs for Healthcare Services, 2025
    \- Kenya Law"
[2]: https://new.kenyalaw.org/akn/ke/act/ln/2024/49/eng%402024-03-08 "
      The Social Health Insurance Regulations
    \- Kenya Law"
