# Module 7: Claims and Insurance Module

This module is the **payer, benefit, claim, denial, and reimbursement engine** of the system.

Modules 1–6 answer:

```text
Module 1: Is the facility/provider licensed and contracted?
Module 2: Was the service billed, invoiced, paid, credited, or receipted?
Module 3: Was the medicine dispensed safely and traceably?
Module 4: Was stock issued, valued, and controlled?
Module 5: Was the clinical encounter documented?
Module 6: Was the lab test ordered, billed, resulted, and verified?
Module 7: Can the facility prove the patient was eligible, the service was covered, the tariff was correct, the documents are complete, the claim was submitted, and the payment was reconciled?
```

For Kenya, this module must support **SHA, private medical insurers, employer/corporate schemes, capitation arrangements, cash top-ups, co-payments, exclusions, pre-authorisations, claim rejections, and receivables reconciliation**.

Kenya’s Social Health Insurance Act establishes a Claims Management Office responsible for reviewing, processing, validating, and appraising medical claims, issuing pre-authorisations, developing an e-claims system, conducting quality assurance surveillance, and establishing controls for detecting fraud. The Social Health Insurance Regulations also require claims to be lodged, reviewed, processed, validated, appraised, and paid through the Centralized Digital Platform. ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/2023/16/eng%402023-11-24)) ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/ln/2024/49/eng%402024-03-08))

---

# 1. Purpose of the module

The Claims and Insurance Module should:

| Purpose                   | Practical meaning                                                                 |
| ------------------------- | --------------------------------------------------------------------------------- |
| Configure benefit schemes | SHA, private insurer, employer, corporate, capitation, staff schemes              |
| Verify eligibility        | Confirm patient/member, policy, cover, beneficiary, limits                        |
| Manage pre-authorisation  | Request approval before service where required                                    |
| Apply tariffs             | Use contracted prices for consultation, lab, drugs, procedures                    |
| Build claim bundles       | Combine patient, provider, diagnosis, services, documents, invoices               |
| Prevent claim leakage     | Detect missing diagnosis, unsigned notes, unverified results, missing attachments |
| Prevent fraud             | Block duplicate claims, non-covered services, undocumented services               |
| Track submission          | Draft, submitted, acknowledged, returned, rejected, approved, paid                |
| Manage denials            | Capture rejection reasons, corrections, resubmissions, write-offs                 |
| Reconcile payments        | Claimed vs approved vs paid vs patient balance                                    |
| Post receivables          | Know how much each payer owes                                                     |
| Support audits            | Every claim edit, denial, resubmission, and payment allocation is traceable       |

---

# 2. Kenya-specific design basis

## A. SHA empanelment, contracting, and provider obligations

SHA pays claims to empanelled and contracted healthcare providers or facilities. Emergency claims may also be payable to a licensed and certified provider or facility where the emergency service is within the benefits package. Contracted providers are required to provide covered services within the benefits package, use and verify beneficiary data, administer services within limits, provide medically necessary care, maintain records in readily accessible format, and maintain infrastructure for linking benefits administration and claims submission to the Centralized Digital Platform. ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/ln/2024/49/eng%402024-03-08))

Software implications:

| SHA requirement                    | System behaviour                                                         |
| ---------------------------------- | ------------------------------------------------------------------------ |
| Empanelled and contracted provider | Claim submission enabled only for configured active contracts            |
| Beneficiary verification           | Patient/member eligibility fields and verification status                |
| Benefit package limits             | Check covered services, limits, co-pay, exclusions                       |
| Medically necessary service        | Link every billed service to clinical note/diagnosis/order/result        |
| Timely and accurate records        | Claim bundle generated from EMR, lab, pharmacy, billing                  |
| Centralized Digital Platform       | API/manual upload adapter and submission status tracking                 |
| Fraud controls                     | Duplicate, unprovided service, out-of-scope service, altered info checks |

---

## B. Pre-authorisation

The SHA regulations define pre-authorisation as permission required before specified healthcare services are provided to determine whether a beneficiary’s cover caters for the cost. The regulations require online pre-authorisation requests for specialized healthcare services determined by the Authority, accompanied by beneficiary details, provider/facility details, and service details; the decision should be made immediately but not later than 72 hours, and pre-authorisation does not apply to emergency services. ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/ln/2024/49/eng%402024-03-08))

Software implications:

| Pre-authorisation requirement | System behaviour                                        |
| ----------------------------- | ------------------------------------------------------- |
| Beneficiary details           | Patient/member identity required                        |
| Provider/facility details     | Branch/provider code required                           |
| Service details               | Procedure/test/drug/service with diagnosis and tariff   |
| Decision tracking             | Pending, approved, denied, partially approved, expired  |
| 72-hour decision window       | SLA timer and escalation                                |
| Emergency exemption           | Emergency override with documentation                   |
| Peer review possibility       | Attach notes, results, referral, justification          |
| Limits                        | Approval amount, quantity, service cap, validity period |

---

## C. Tariffs

Kenya has published Tariffs for Healthcare Services, 2025 under the Social Health Insurance Act. The tariff notice commenced on 28 February 2025 and should be treated as a versioned tariff source for SHA pricing, subject to updates. ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/ln/2025/56/eng%402025-02-28))

Software implications:

| Tariff requirement   | System behaviour                                      |
| -------------------- | ----------------------------------------------------- |
| Tariff versioning    | Store effective date and source                       |
| Service mapping      | Consultation, lab, procedure, drug, package           |
| Facility-level rules | Some services may depend on facility level/scope      |
| Benefit limits       | Quantity, frequency, amount, diagnosis, referral      |
| Updates              | New tariff version should not corrupt old claims      |
| Payer differences    | SHA tariff ≠ private insurer tariff ≠ employer tariff |

---

## D. Private medical insurers and claim handling

Private insurers operate under Kenya’s insurance regulatory framework. The Insurance Regulatory Authority says it regulates, supervises, and develops the insurance industry, and the Insurance Claims Management Guidelines, 2022 state that they are intended to provide principles for claims management, ensure prompt payment of claims, and promote consumer confidence. ([online.ira.go.ke](https://online.ira.go.ke/)) ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/gn/2022/3638/eng%402022-03-29))

Software implications:

| Private insurance need        | System behaviour                                               |
| ----------------------------- | -------------------------------------------------------------- |
| Different schemes             | Corporate, individual, family, inpatient, outpatient           |
| Different rules               | Co-pay, limits, exclusions, waiting periods                    |
| Different forms               | Claim forms, medical reports, invoices, prescriptions, results |
| Different submission channels | Portal, email, API, physical forms                             |
| Denial handling               | Track reasons and resubmissions                                |
| Payment reconciliation        | Match remittance advice to claims                              |

---

# 3. Core users

| User                       | Main actions                                                                 |
| -------------------------- | ---------------------------------------------------------------------------- |
| Receptionist               | Captures payer/member details, checks eligibility                            |
| Billing officer            | Applies scheme, co-pay, price split, invoice                                 |
| Clinician                  | Provides diagnosis, notes, medical justification, discharge/referral summary |
| Lab user                   | Provides verified lab results as claim evidence                              |
| Pharmacist                 | Provides prescription and dispense record                                    |
| Claims officer             | Builds, validates, submits, follows up, corrects claims                      |
| Facility manager           | Reviews claim ageing, denials, revenue leakage                               |
| Accountant                 | Reconciles approved/paid amounts and payer remittances                       |
| Owner/director             | Views payer debt, denial rate, cashflow exposure                             |
| Auditor/compliance officer | Reviews fraud controls, documentation, resubmission history                  |

---

# 4. Relationship with modules 1–6

## Module 1: Organisation and Licensing

| Data from Module 1           | Claims use                             |
| ---------------------------- | -------------------------------------- |
| Facility licence             | Claim eligibility                      |
| Provider/facility code       | Claim submission                       |
| SHA/private insurer contract | Scheme activation                      |
| Professional licences        | Clinician/lab/pharmacy sign-off        |
| Branch service scope         | Prevent claiming out-of-scope services |
| Contract expiry              | Block or warn on claims                |

## Module 2: POS, Billing and Payments

| Billing data        | Claims use              |
| ------------------- | ----------------------- |
| Bill lines          | Services/items claimed  |
| eTIMS invoice       | Financial/tax reference |
| Patient co-pay      | Patient portion         |
| Insurer/SHA portion | Receivable              |
| Credit notes        | Claim corrections       |
| Payments            | Reconciliation          |
| Refunds             | Claim adjustment        |

## Module 3: Pharmacy Dispensing

| Pharmacy data                | Claims use                                                   |
| ---------------------------- | ------------------------------------------------------------ |
| Prescription                 | Medicine claim support                                       |
| Dispense record              | Proof medicine was supplied                                  |
| Batch/expiry                 | Traceability                                                 |
| Substitution                 | Explain difference between prescribed and dispensed medicine |
| Partial dispense             | Claim only actual quantity supplied                          |
| Controlled medicine register | High-risk evidence                                           |

## Module 4: Inventory

| Inventory data        | Claims use                        |
| --------------------- | --------------------------------- |
| Stock issue           | Proves item/service consumed      |
| Drug cost             | Margin and reimbursement analysis |
| Batch data            | Recall and audit                  |
| Procedure consumables | Procedure costing                 |
| Vaccine/test-kit use  | Evidence for service provision    |

## Module 5: Clinic EMR

| EMR data             | Claims use                               |
| -------------------- | ---------------------------------------- |
| Patient demographics | Member identity                          |
| Visit                | Encounter date and provider              |
| Clinical note        | Medical necessity                        |
| Diagnosis            | Claim diagnosis                          |
| Orders               | Lab/procedure/prescription justification |
| Referral             | Referral-dependent benefits              |
| Visit summary        | Claim attachment                         |

## Module 6: Lab-lite

| Lab data                   | Claims use            |
| -------------------------- | --------------------- |
| Lab order                  | Test requested        |
| Billing link               | Test charged          |
| Result                     | Test performed        |
| Verification               | Result authenticity   |
| External lab document      | Send-out proof        |
| Critical/abnormal findings | Medical justification |

---

# 5. Core claim transaction types

| Transaction type              | Description                                      |
| ----------------------------- | ------------------------------------------------ |
| Outpatient claim              | Consultation, lab, drugs, minor procedure        |
| Pharmacy-only claim           | Covered medicines under scheme                   |
| Lab-only claim                | Diagnostic test claim                            |
| Procedure claim               | Dressing, injection, nebulization, minor surgery |
| Referral claim                | Claim requiring referral chain                   |
| Emergency claim               | Emergency service, may bypass pre-authorisation  |
| Chronic-care claim            | Diabetes, hypertension, asthma, etc.             |
| Capitation encounter          | Encounter under prepaid/capitated arrangement    |
| Employer/corporate claim      | Company pays directly                            |
| Private insurer claim         | AAR/Jubilee/Britam/etc. style schemes            |
| SHA claim                     | SHA benefit package and tariffs                  |
| Patient reimbursement support | Patient pays and later claims from insurer       |
| Claim adjustment              | Correct amount/service after submission          |
| Claim resubmission            | Re-submit returned/rejected claim                |
| Claim write-off               | Unrecoverable denied amount                      |
| Overpayment recovery          | Payer paid more than expected                    |

---

# 6. Feature-by-feature design

## A. Benefit scheme setup

Benefit scheme setup defines what a payer covers, at what price, with what rules.

### Scheme types

| Scheme type          | Example                                          |
| -------------------- | ------------------------------------------------ |
| SHA                  | Social Health Authority benefits                 |
| Private insurer      | AAR, Jubilee, Britam, CIC, Madison, etc.         |
| Employer/corporate   | Company staff scheme                             |
| Capitation           | Facility receives fixed amount per member/period |
| Fee-for-service      | Claim per service/item                           |
| Hybrid               | Capitation plus excluded fee-for-service items   |
| Staff scheme         | Facility’s own staff                             |
| Cash discount scheme | Not insurance, but special pricing               |
| Donor/NGO programme  | Specific covered services                        |
| Voucher scheme       | Maternal/child/other voucher workflows           |

### Payer master fields

| Field                   |   Required? | Notes                             |
| ----------------------- | ----------: | --------------------------------- |
| Payer name              |         Yes | SHA/private insurer/employer      |
| Payer type              |         Yes | SHA, private, employer, corporate |
| Regulator/reference     |    Optional | IRA/SHA/contract reference        |
| Contact person          | Recommended | Claims follow-up                  |
| Claims email/portal/API | Recommended | Submission route                  |
| Phone                   | Recommended |                                   |
| Address                 |    Optional |                                   |
| Payment bank/account    |    Optional | Reconciliation                    |
| Status                  |         Yes | Active, suspended, inactive       |

### Scheme fields

| Field                   |   Required? | Notes                               |
| ----------------------- | ----------: | ----------------------------------- |
| Scheme name             |         Yes | Example: Corporate Outpatient Plan  |
| Scheme code             |         Yes | Internal/payer code                 |
| Payer                   |         Yes | Link to payer                       |
| Contract number         |         Yes | From Module 1                       |
| Facility/provider code  |         Yes | From payer/SHA                      |
| Branch/facility         |         Yes | Claims are branch-specific          |
| Effective date          |         Yes |                                     |
| Expiry date             |         Yes |                                     |
| Scheme type             |         Yes | Fee-for-service/capitation/hybrid   |
| Covered services        |         Yes | Consultation, lab, drugs, procedure |
| Benefit limits          |         Yes | Amount, frequency, visit count      |
| Co-pay rules            | Recommended | Fixed, %, none                      |
| Exclusions              | Recommended | Non-covered services/drugs          |
| Waiting period          |    Optional | Private/employer schemes            |
| Referral requirement    |    Optional | Especially SHA/specialist           |
| Pre-auth rules          |         Yes | Services needing approval           |
| Tariff table            |         Yes | Link                                |
| Claim submission method |         Yes | Portal/API/email/manual             |
| Claim deadline          | Recommended | Days after visit/discharge          |
| Attachments required    |         Yes | Rules                               |
| Status                  |         Yes | Draft, active, suspended, expired   |

### Member/beneficiary fields

| Field                         |       Required? | Notes                              |
| ----------------------------- | --------------: | ---------------------------------- |
| Patient                       |             Yes | Link to EMR patient                |
| Payer                         |             Yes |                                    |
| Scheme                        |             Yes |                                    |
| Member number                 |             Yes | SHA/private insurer/employer ID    |
| Principal member              |    If dependent |                                    |
| Dependent relationship        |    If dependent | Spouse/child/etc.                  |
| ID/passport/birth certificate |     Recommended | Eligibility                        |
| SHA number                    |         For SHA |                                    |
| Policy number                 | Private insurer |                                    |
| Employer staff number         |       Corporate |                                    |
| Cover start/end               |     Recommended |                                    |
| Card photo/document           |        Optional |                                    |
| Eligibility status            |             Yes | Active, inactive, pending, expired |
| Last verified date            |             Yes |                                    |
| Verification method           |             Yes | Portal/API/manual                  |
| Notes                         |        Optional |                                    |

### Benefit scheme rules

| Rule                 | System behaviour                                                       |
| -------------------- | ---------------------------------------------------------------------- |
| Scheme expired       | Block new claims                                                       |
| Contract expired     | Block or warn based on configuration                                   |
| Patient not eligible | Require cash payment or override                                       |
| Service excluded     | Move to patient-pay or block claim                                     |
| Limit exceeded       | Alert billing and patient                                              |
| Co-pay required      | Calculate patient portion                                              |
| Pre-auth required    | Block claim until approved                                             |
| Referral required    | Require referral attachment                                            |
| Scheme capitation    | Record encounter but do not create normal receivable unless configured |
| Payer tariff missing | Block claim pricing                                                    |

---

## B. Pre-authorisation

Pre-authorisation is a formal permission workflow before selected services are provided or claimed.

### Pre-authorisation request fields

| Field                                 |     Required? | Notes                                                                               |
| ------------------------------------- | ------------: | ----------------------------------------------------------------------------------- |
| Pre-auth request number               |           Yes | Internal                                                                            |
| Payer                                 |           Yes | SHA/insurer/employer                                                                |
| Scheme                                |           Yes |                                                                                     |
| Patient/member                        |           Yes |                                                                                     |
| Facility/provider code                |           Yes |                                                                                     |
| Requesting clinician                  |           Yes |                                                                                     |
| Diagnosis                             |           Yes | ICD-10-ready                                                                        |
| Requested service/procedure/test/drug |           Yes |                                                                                     |
| Clinical justification                |           Yes |                                                                                     |
| Estimated cost                        |           Yes | From tariff                                                                         |
| Requested quantity/days               | If applicable |                                                                                     |
| Attachments                           | Based on rule | Notes, lab, imaging, referral                                                       |
| Urgency                               |           Yes | Routine/urgent/emergency                                                            |
| Submitted by                          |           Yes |                                                                                     |
| Submitted date/time                   |           Yes |                                                                                     |
| Submission channel                    |           Yes | Portal/API/email/manual                                                             |
| External reference number             |   Recommended | Payer reference                                                                     |
| Status                                |           Yes | Draft, submitted, pending, approved, partially approved, denied, expired, cancelled |

### Pre-authorisation approval fields

| Field                   | Notes                      |
| ----------------------- | -------------------------- |
| Approval number         | Payer-provided             |
| Approved service        | May differ from requested  |
| Approved amount         | Amount limit               |
| Approved quantity       | Quantity/session/day limit |
| Approved facility       | If restricted              |
| Valid from              | Start date                 |
| Valid to                | Expiry                     |
| Conditions              | Payer notes                |
| Denial/partial reason   | If not fully approved      |
| Approved by payer       | Name/reference             |
| Approval document       | Upload                     |
| Patient co-pay          | If applicable              |
| Balance patient portion | Auto                       |

### Pre-authorisation rules

| Rule                                 | System behaviour                                       |
| ------------------------------------ | ------------------------------------------------------ |
| Service requires pre-auth            | Block claim submission until approval captured         |
| Pre-auth expired                     | Require renewal or patient-pay                         |
| Approved amount lower than estimated | Split balance to patient/pending approval              |
| Service changed                      | Require pre-auth amendment                             |
| Emergency case                       | Allow emergency override with reason and documentation |
| Approval number missing              | Mark claim not ready                                   |
| Pre-auth not linked to visit         | Block claim bundle                                     |
| Pre-auth quantity exceeded           | Warn/block extra claim lines                           |
| Payer decision overdue               | Show SLA alert                                         |

### Pre-auth statuses

```text
Draft
Submitted
Acknowledged
Pending review
More information required
Approved
Partially approved
Denied
Expired
Cancelled
Used
Closed
```

---

## C. Tariff table

Tariff tables determine how much a payer pays for each service, item, drug, test, or procedure.

### Tariff table types

| Tariff type            | Use                                   |
| ---------------------- | ------------------------------------- |
| SHA national tariff    | SHA claims                            |
| Private insurer tariff | Contracted insurer rates              |
| Employer tariff        | Corporate/employer rates              |
| Facility cash tariff   | Self-pay pricing                      |
| Capitation tariff      | Included/not separately billable      |
| Package tariff         | Bundled consultation + lab/procedure  |
| Drug formulary tariff  | Medicine reimbursement rules          |
| Procedure tariff       | Minor/major procedure prices          |
| Lab tariff             | Test reimbursement                    |
| Branch-specific tariff | Different facility branches/contracts |

### Tariff header fields

| Field           |   Required? | Notes                    |
| --------------- | ----------: | ------------------------ |
| Tariff name     |         Yes | Example: SHA Tariff 2025 |
| Payer           |         Yes |                          |
| Scheme          |    Optional | If scheme-specific       |
| Version         |         Yes | 2025-v1, insurer-2026-v2 |
| Effective from  |         Yes |                          |
| Effective to    |    Optional |                          |
| Source document | Recommended | Upload tariff/contract   |
| Currency        |         Yes | KES                      |
| Status          |         Yes | Draft, active, expired   |
| Approved by     |         Yes | Internal approval        |
| Notes           |    Optional |                          |

### Tariff line fields

| Field                      | Required? | Notes                              |
| -------------------------- | --------: | ---------------------------------- |
| Tariff code                |       Yes | Payer/service code                 |
| Internal item/service code |       Yes | Link to product/service/test       |
| Service category           |       Yes | Consultation, lab, drug, procedure |
| Description                |       Yes |                                    |
| Facility level/scope       |  Optional | Level/specialty restrictions       |
| Unit of measure            |       Yes | Visit, test, tablet, pack, day     |
| Allowed quantity           |  Optional | Maximum quantity                   |
| Unit tariff                |       Yes |                                    |
| Patient co-pay             |  Optional | Fixed or %                         |
| Payer portion              |      Auto |                                    |
| Requires pre-auth          |    Yes/no |                                    |
| Requires referral          |    Yes/no |                                    |
| Requires attachment        |    Yes/no |                                    |
| Covered diagnosis rules    |  Optional |                                    |
| Exclusion flag             |    Yes/no |                                    |
| Effective from/to          |       Yes | Line-specific versioning           |
| Status                     |       Yes | Active/inactive                    |

### Tariff rules

| Rule                   | System behaviour                                       |
| ---------------------- | ------------------------------------------------------ |
| No active tariff       | Claim line not ready                                   |
| Service not covered    | Patient-pay or block claim                             |
| Facility not eligible  | Block claim                                            |
| Quantity exceeds limit | Split extra quantity to patient-pay or pre-auth        |
| Pre-auth required      | Block without approval                                 |
| Referral required      | Require referral document                              |
| Drug not on formulary  | Patient-pay or exception request                       |
| Tariff changed         | New claims use new tariff; old claims retain old price |
| Package tariff         | Prevent duplicate billing of included services         |
| Capitated service      | Mark as included, not receivable unless configured     |

---

## D. Claim bundle

A claim bundle is the complete evidence packet submitted to the payer.

### Claim bundle contents

| Bundle section             | Data source                     |
| -------------------------- | ------------------------------- |
| Patient/member details     | Registration, scheme membership |
| Provider/facility details  | Module 1                        |
| Visit/encounter details    | EMR                             |
| Clinician details          | Module 1 + EMR                  |
| Diagnosis                  | EMR                             |
| Services rendered          | Billing/EMR/lab/pharmacy        |
| Lab results                | Lab-lite                        |
| Prescriptions              | EMR/pharmacy                    |
| Dispensed drugs            | Pharmacy                        |
| Procedures                 | EMR/procedure notes             |
| Invoices/receipts          | POS/billing                     |
| Pre-authorisation          | Claims module                   |
| Referral/discharge summary | EMR                             |
| Attachments                | Documents module                |
| Tariff/pricing             | Tariff table                    |
| Co-pay/patient payment     | Billing                         |
| Claim form                 | Generated                       |

### Claim header fields

| Field                       |      Required? |
| --------------------------- | -------------: |
| Claim number                |            Yes |
| External payer claim number | When available |
| Payer                       |            Yes |
| Scheme                      |            Yes |
| Patient/member              |            Yes |
| Facility/provider code      |            Yes |
| Branch                      |            Yes |
| Visit/admission number      |            Yes |
| Claim type                  |            Yes |
| Encounter start/end         |            Yes |
| Primary diagnosis           |            Yes |
| Claim amount                |            Yes |
| Patient portion             |            Yes |
| Payer portion               |            Yes |
| Submitted amount            |            Yes |
| Claim status                |            Yes |
| Submitted by                |            Yes |
| Submitted date              | When submitted |
| Submission channel          |            Yes |
| Deadline date               |    Recommended |

### Claim line fields

| Field                          |            Required? |
| ------------------------------ | -------------------: |
| Claim line number              |                  Yes |
| Service/item/test/drug         |                  Yes |
| Internal code                  |                  Yes |
| Payer tariff code              |                  Yes |
| Date of service                |                  Yes |
| Quantity                       |                  Yes |
| Unit price/tariff              |                  Yes |
| Gross amount                   |                  Yes |
| Co-pay                         |        If applicable |
| Patient portion                |                  Yes |
| Payer portion                  |                  Yes |
| Diagnosis link                 | Recommended/required |
| Order/result/prescription link |     Where applicable |
| Pre-auth link                  |          If required |
| Attachment required flag       |                 Auto |
| Status                         |                  Yes |

### Claim status lifecycle

```text
Draft
Missing information
Ready for validation
Validation failed
Ready to submit
Submitted
Acknowledged
Under review
Returned for correction
Rejected
Approved
Partially approved
Paid
Partially paid
Reconciled
Written off
Closed
```

### Claim validation checks

| Check                           | Why                                  |
| ------------------------------- | ------------------------------------ |
| Active contract                 | Facility must be eligible            |
| Patient eligible                | Member/beneficiary cover active      |
| Diagnosis present               | Clinical justification               |
| ICD-10 code present             | Claims/reporting                     |
| Clinician signed note           | Proof service was provided           |
| Service covered                 | Avoid denial                         |
| Tariff mapped                   | Correct pricing                      |
| Pre-auth present                | Required for specified services      |
| Referral present                | Required for referral-based benefits |
| Lab result verified             | Proof test was performed             |
| Prescription and dispense match | Proof medicine supplied              |
| Invoice exists                  | Financial evidence                   |
| Attachment exists               | Documentation                        |
| No duplicate claim              | Fraud prevention                     |
| Within deadline                 | Avoid late denial                    |
| Quantity within limit           | Avoid overclaim                      |
| Facility scope valid            | Avoid out-of-scope denial            |

### Claim fraud prevention rules

SHA regulations allow termination of a contract where a provider bills for unnecessary services, services not covered within the facility’s level of care, services outside professional scope, services or medicine not provided, falsifies or alters information with intent to defraud, or submits separate claims for the same service. The system should therefore treat these as hard validation and audit controls, not just reports. ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/ln/2024/49/eng%402024-03-08))

| Fraud risk                     | System control                              |
| ------------------------------ | ------------------------------------------- |
| Claiming service not provided  | Require EMR/order/result/procedure evidence |
| Claiming medicine not supplied | Require dispense record                     |
| Duplicate claim                | Duplicate detector by patient/date/service  |
| Out-of-scope service           | Facility/service scope rule                 |
| Falsified edited data          | Immutable audit trail and addendum model    |
| Split duplicate claims         | Claim-line duplicate rules                  |
| Upcoding                       | Diagnosis-service consistency checks        |
| Billing after contract expiry  | Contract status block                       |

---

## E. Denial management

Denial management is where many clinics lose money. The system must track every rejection and whether it is recoverable.

### Denial types

| Denial type              | Example                                  |
| ------------------------ | ---------------------------------------- |
| Eligibility denial       | Member inactive                          |
| Authorization denial     | Pre-auth missing/expired                 |
| Benefit denial           | Service not covered                      |
| Limit denial             | Benefit exhausted                        |
| Documentation denial     | Missing lab result/referral/prescription |
| Coding denial            | Wrong diagnosis/service code             |
| Tariff denial            | Wrong price/code                         |
| Duplicate denial         | Already claimed                          |
| Timeliness denial        | Submitted late                           |
| Medical necessity denial | Insufficient clinical justification      |
| Facility-scope denial    | Facility not authorized for service      |
| Provider-scope denial    | Clinician not authorized/signed          |
| Technical denial         | Portal/API format error                  |
| Partial denial           | Some lines approved, others rejected     |

### Denial fields

| Field                    |                                                   Required? |
| ------------------------ | ----------------------------------------------------------: |
| Denial ID                |                                                         Yes |
| Claim ID                 |                                                         Yes |
| Claim line ID            |                           Optional/required for line denial |
| Payer denial code        |                                                 Recommended |
| Internal denial category |                                                         Yes |
| Denial reason text       |                                                         Yes |
| Denial date              |                                                         Yes |
| Received by              |                                                         Yes |
| Recoverable?             |                                                      Yes/no |
| Responsible department   |                   Billing, clinician, lab, pharmacy, claims |
| Required correction      |                                                         Yes |
| Correction deadline      |                                                 Recommended |
| Resubmission allowed     |                                                      Yes/no |
| Amount denied            |                                                         Yes |
| Patient billable?        |                                               Yes/no/policy |
| Write-off amount         |                                            If unrecoverable |
| Status                   | Open, corrected, resubmitted, accepted, written off, closed |

### Denial workflow

```text
1. Payer returns/rejects claim
2. Claims officer records denial reason
3. System classifies denial
4. Task assigned to responsible department
5. Missing/corrected document or data is added
6. Claim is resubmitted
7. Payer response is tracked
8. If unrecoverable, amount is written off or moved to patient balance
9. Denial analytics update
```

### Denial rules

| Rule                            | System behaviour                                         |
| ------------------------------- | -------------------------------------------------------- |
| Denial reason missing           | Cannot close denial                                      |
| Recoverable denial              | Create resubmission task                                 |
| Clinician documentation missing | Task clinician/medical records                           |
| Lab result missing              | Task lab                                                 |
| Prescription/dispense mismatch  | Task pharmacy                                            |
| Tariff error                    | Task billing/claims                                      |
| Non-covered service             | Move to patient balance only if policy and consent allow |
| Late claim                      | Manager approval for write-off                           |
| Repeated denial reason          | Show process improvement alert                           |

---

## F. Reconciliation

Reconciliation answers:

```text
What did we claim?
What did payer approve?
What did payer pay?
What did patient pay?
What remains outstanding?
What must be written off or billed to patient?
```

### Reconciliation sources

| Source                      | Data                          |
| --------------------------- | ----------------------------- |
| Claim submission            | Claimed amount                |
| Payer approval/remittance   | Approved amount               |
| Bank/M-Pesa/payment receipt | Paid amount                   |
| Patient receipt             | Co-pay/self-pay               |
| Credit notes                | Reversed claim/patient amount |
| Denial records              | Unpaid/rejected amount        |
| Write-off approval          | Unrecoverable amount          |
| Accounts receivable         | Outstanding balance           |

### Reconciliation fields

| Field                       |                                           Required? |
| --------------------------- | --------------------------------------------------: |
| Reconciliation batch number |                                                 Yes |
| Payer                       |                                                 Yes |
| Remittance advice number    |                                         Recommended |
| Payment date                |                                                 Yes |
| Bank reference              |                                                 Yes |
| Total paid                  |                                                 Yes |
| Claims included             |                                                 Yes |
| Claim amount                |                                                Auto |
| Approved amount             |                                                 Yes |
| Paid amount                 |                                                 Yes |
| Difference                  |                                                Auto |
| Withheld amount             |                                            Optional |
| Denied amount               |                                                Auto |
| Patient balance             |                                                Auto |
| Write-off amount            |                                         If approved |
| Posted to accounting        |                                              Yes/no |
| Reconciled by               |                                                 Yes |
| Reconciled date             |                                                 Yes |
| Status                      | Draft, matched, partially matched, disputed, posted |

### Reconciliation outcomes

| Outcome         | Meaning                       |
| --------------- | ----------------------------- |
| Fully paid      | Claimed/approved/paid matches |
| Partially paid  | Some amount unpaid            |
| Overpaid        | Payer paid more than expected |
| Underpaid       | Payer paid less than approved |
| Denied          | Not paid due to rejection     |
| Adjusted        | Payer changed amount          |
| Patient balance | Amount transferred to patient |
| Written off     | Facility absorbs loss         |
| Disputed        | Follow-up with payer needed   |

### Reconciliation rules

| Rule                             | System behaviour                                          |
| -------------------------------- | --------------------------------------------------------- |
| Paid amount lower than approved  | Create underpayment dispute                               |
| Paid amount higher than approved | Flag overpayment                                          |
| Claim rejected                   | Remove from expected payer receivable or keep as disputed |
| Patient co-pay unpaid            | Create patient receivable                                 |
| Denied non-covered service       | Move to patient balance only if policy allows             |
| Claim paid                       | Lock core claim fields                                    |
| Payment cannot be matched        | Keep in suspense account                                  |
| Remittance imported              | Auto-match by claim number/member/date/amount             |

---

## G. Attachments

Attachments are critical because many claims fail due to missing documentation.

### Attachment types

| Attachment                 | Source                               |
| -------------------------- | ------------------------------------ |
| Signed clinical note       | EMR                                  |
| Visit summary              | EMR                                  |
| Lab result                 | Lab-lite                             |
| Prescription               | EMR/pharmacy                         |
| Dispense record            | Pharmacy                             |
| Referral letter            | EMR                                  |
| Discharge summary          | EMR/inpatient module/facility upload |
| Procedure note             | EMR                                  |
| Imaging report             | EMR/external upload                  |
| Pre-authorisation approval | Claims module                        |
| Invoice/eTIMS receipt      | Billing                              |
| Patient ID/card            | Registration                         |
| Consent form               | EMR/documents                        |
| External lab report        | Lab-lite                             |
| Sick-off/certificate       | EMR                                  |
| Claim form                 | Generated PDF                        |
| Medical report             | Clinician-generated                  |
| Accident/emergency notes   | EMR                                  |

### Attachment rule setup

| Rule field                 | Example                            |
| -------------------------- | ---------------------------------- |
| Payer                      | SHA/private insurer                |
| Scheme                     | Corporate outpatient               |
| Service category           | Lab/procedure/drug/referral        |
| Attachment required        | Yes/no                             |
| Attachment type            | Lab result, referral, prescription |
| Required before submission | Yes                                |
| Required after denial only | Optional                           |
| File format                | PDF/JPEG/PNG                       |
| Max file size              | Configurable                       |
| Source module              | EMR/lab/pharmacy/billing           |
| Sensitive flag             | Yes/no                             |

### Attachment rules

| Rule                               | System behaviour                         |
| ---------------------------------- | ---------------------------------------- |
| Lab claim                          | Require verified lab result              |
| Drug claim                         | Require prescription and dispense record |
| Referral service                   | Require referral letter                  |
| Procedure claim                    | Require procedure note                   |
| Pre-auth service                   | Require approval document/reference      |
| Discharge-related claim            | Require discharge summary                |
| Missing attachment                 | Claim not ready                          |
| Attachment edited after submission | Create new version and resubmission flag |
| Sensitive attachment               | Restrict access and sharing              |
| Reprint/export                     | Log user and reason                      |

---

# 7. Required screens

## Screen 1: Payer and scheme setup

Sections:

| Section          | Contents                             |
| ---------------- | ------------------------------------ |
| Payer profile    | Name, type, contact, portal/API      |
| Scheme details   | Code, contract, branch, dates        |
| Benefits         | Covered services, exclusions, limits |
| Co-pay rules     | Fixed/percentage/none                |
| Pre-auth rules   | Services requiring approval          |
| Tariffs          | Linked tariff table                  |
| Attachment rules | Required documents                   |
| Submission rules | Portal/API/email/deadline            |
| Status           | Active/suspended/expired             |

---

## Screen 2: Member eligibility screen

Search by:

| Search key            |
| --------------------- |
| Patient number        |
| SHA number            |
| Member number         |
| National ID           |
| Phone                 |
| Policy number         |
| Employer staff number |

Shows:

```text
Patient
Payer
Scheme
Eligibility status
Cover start/end
Dependants
Available limits
Co-pay
Pre-auth requirements
Last verification
```

Actions:

```text
Verify eligibility
Attach card/document
Change payer
Mark cash/self-pay
Start pre-authorisation
```

---

## Screen 3: Pre-authorisation screen

Sections:

| Section                | Contents                      |
| ---------------------- | ----------------------------- |
| Beneficiary            | Patient/member                |
| Provider               | Facility/provider code        |
| Service requested      | Procedure/test/drug/admission |
| Diagnosis              | ICD-10-ready                  |
| Clinical justification | Notes                         |
| Estimated cost         | From tariff                   |
| Attachments            | Lab, referral, imaging, notes |
| Submission             | Portal/API/email/manual       |
| Decision               | Approved/denied/partial       |
| Limits                 | Amount, quantity, validity    |
| Status                 | Pending/approved/expired      |

---

## Screen 4: Tariff table screen

Features:

| Feature                     |
| --------------------------- |
| Import tariff CSV/Excel     |
| Manual tariff entry         |
| Version management          |
| Service mapping             |
| Drug formulary mapping      |
| Lab tariff mapping          |
| Procedure tariff mapping    |
| Effective dates             |
| Payer/scheme-specific rates |
| Facility-level restrictions |
| Approval workflow           |

---

## Screen 5: Claim workbench

This is the main claims officer screen.

Filters:

| Filter              |
| ------------------- |
| Draft               |
| Missing information |
| Ready to submit     |
| Submitted           |
| Returned            |
| Rejected            |
| Approved            |
| Paid                |
| Overdue             |
| Payer               |
| Branch              |
| Clinician           |
| Date range          |
| Claim type          |
| Denial reason       |

Columns:

| Column           |
| ---------------- |
| Claim number     |
| Patient          |
| Payer            |
| Visit date       |
| Diagnosis        |
| Claimed amount   |
| Patient portion  |
| Payer portion    |
| Missing items    |
| Status           |
| Days outstanding |
| Assigned user    |

---

## Screen 6: Claim bundle viewer

Sections:

| Section            | Contents                             |
| ------------------ | ------------------------------------ |
| Patient/member     | Identity, eligibility                |
| Provider           | Facility, provider code, clinician   |
| Visit              | Encounter dates and service type     |
| Diagnosis          | Primary/secondary ICD-10             |
| Claim lines        | Consultation, lab, drugs, procedures |
| Tariffs            | Expected payer amount                |
| Pre-auth           | Approval details                     |
| Attachments        | Required and uploaded documents      |
| Validation         | Errors/warnings                      |
| Submission history | Portal/API/email/manual              |
| Audit              | Edits and approvals                  |

---

## Screen 7: Denial management screen

Sections:

| Section           | Contents                                          |
| ----------------- | ------------------------------------------------- |
| Denied claim      | Claim and line                                    |
| Payer reason      | Code/text                                         |
| Internal category | Eligibility, authorization, documentation, coding |
| Amount denied     | Value                                             |
| Responsible party | Clinician/lab/pharmacy/billing/claims             |
| Correction task   | Required action                                   |
| Deadline          | Resubmission deadline                             |
| Resubmission      | New submission reference                          |
| Outcome           | Paid/written off/patient balance                  |

---

## Screen 8: Reconciliation screen

Sections:

| Section                | Contents                    |
| ---------------------- | --------------------------- |
| Payer remittance       | Payment batch               |
| Bank/payment reference | Amount received             |
| Claims paid            | Matched claims              |
| Differences            | Under/over payments         |
| Denials                | Unpaid claims               |
| Patient balances       | Co-pay or uncovered balance |
| Write-offs             | Approved losses             |
| Posting                | Accounting status           |

---

## Screen 9: Claim ageing dashboard

Cards:

```text
Total claims submitted
Claims pending submission
Claims awaiting payer response
Claims returned for correction
Claims rejected
Claims approved not paid
Claims paid
Claims overdue
Value outstanding
Denial rate
Average days to payment
Top denial reasons
```

---

# 8. Workflows

## A. Basic outpatient insured visit

```text
1. Patient is registered or selected
2. Payer and scheme are selected
3. Eligibility is verified
4. Co-pay and cover rules are displayed
5. Patient enters consultation queue
6. Clinician documents note and diagnosis
7. Lab/procedure/prescription orders are created where needed
8. Billing applies tariff and patient/payer split
9. Required services are performed and documented
10. Claim bundle is generated
11. Claims officer validates bundle
12. Claim is submitted
13. Payer response is tracked
14. Payment is reconciled
```

---

## B. Service requiring pre-authorisation

```text
1. Clinician orders service requiring pre-auth
2. System detects pre-auth rule
3. Pre-auth request is created
4. Diagnosis, justification, estimated cost, and documents are attached
5. Request is submitted to payer/SHA
6. Decision is captured
7. If approved, service proceeds within approved limits
8. If partially approved, patient balance or amendment is created
9. If denied, service is blocked or converted to cash/self-pay
10. Claim later references the approval number
```

---

## C. Lab claim workflow

```text
1. Clinician orders lab test
2. Billing applies payer tariff
3. Patient co-pay is collected if required
4. Lab collects sample and enters result
5. Lab verifies result
6. Claim bundle pulls verified result automatically
7. Claim validation confirms result attachment exists
8. Claim is submitted
```

---

## D. Drug claim workflow

```text
1. Clinician prescribes medicine
2. Pharmacy reviews and dispenses actual medicine
3. Substitution or partial dispense is captured where applicable
4. Billing applies drug tariff/formulary
5. Claim bundle includes prescription and dispense record
6. Claim amount reflects actual quantity supplied
7. Claim is submitted
```

---

## E. Denial and resubmission workflow

```text
1. Payer rejects or returns claim
2. Claims officer records denial reason
3. System classifies denial
4. Task is assigned to responsible department
5. Missing/corrected evidence is added
6. Claim is resubmitted
7. Resubmission result is tracked
8. If paid, reconciliation closes it
9. If unrecoverable, write-off or patient-balance workflow starts
```

---

## F. Reconciliation workflow

```text
1. Payer sends remittance/payment
2. Accountant imports or enters payment batch
3. System matches payment to claims
4. Approved amount, paid amount, denied amount, and patient balance are calculated
5. Differences are flagged
6. Underpayments become disputes
7. Denials become denial tasks
8. Patient balances move to receivables
9. Matched payments are posted to accounting
10. Claims are marked reconciled
```

---

## G. Capitation workflow

```text
1. Scheme is configured as capitation
2. Patient eligibility is verified
3. Visit is recorded as covered under capitation
4. Services are marked as included unless excluded
5. Claim/encounter report is generated for utilization
6. No normal fee-for-service receivable is created unless service is outside capitation
7. Utilization and cost are monitored
```

---

# 9. Rules engine

## Eligibility

```text
RULE: Patient eligible
IF member.status = active
AND scheme.status = active
AND contract.status = active
AND visit_date BETWEEN cover_start AND cover_end
THEN allow insured billing
ELSE route to cash/self-pay or require override
```

## Benefit coverage

```text
RULE: Covered service
IF service IN scheme.covered_services
AND service NOT IN scheme.exclusions
AND facility.scope_allows_service = true
THEN allow payer pricing
ELSE mark patient-pay or block claim
```

## Pre-authorisation

```text
RULE: Pre-authorisation required
IF tariff_line.requires_preauth = true
THEN preauth.status must be approved
AND preauth.valid_until >= service_date
AND claimed_amount <= approved_amount
ELSE claim line not ready
```

## Tariff pricing

```text
RULE: Apply tariff
IF active_tariff_line exists for payer, scheme, service, date
THEN claim_line.unit_price = tariff_line.amount
ELSE claim_line.status = missing_tariff
```

## Claim readiness

```text
RULE: Claim ready
IF patient_eligibility_verified = true
AND diagnosis.primary exists
AND clinician_note.signed = true
AND all claim_lines have tariffs
AND all required attachments are present
AND no duplicate claim detected
THEN claim.status = ready_to_submit
ELSE claim.status = missing_information
```

## Lab attachment

```text
RULE: Lab claim evidence
IF claim_line.category = lab
THEN verified_lab_result must exist
ELSE block submission
```

## Drug attachment

```text
RULE: Drug claim evidence
IF claim_line.category = drug
THEN prescription exists
AND dispense_record exists
AND quantity_claimed <= quantity_dispensed
ELSE block submission
```

## Duplicate claim

```text
RULE: Duplicate detection
IF same payer + member + service_code + service_date + provider_code already submitted
THEN flag duplicate
AND require manager approval or correction
```

## Denial closure

```text
RULE: Close denial
IF denial.status = open
THEN require resolution_type IN [resubmitted, accepted, written_off, patient_billed, payer_dispute]
AND resolution_note is required
```

## Reconciliation

```text
RULE: Reconcile claim
IF paid_amount = approved_amount
THEN claim.status = reconciled
ELSE create variance record
```

---

# 10. Data model

## Main tables

### `payers`

| Field                   |
| ----------------------- |
| id                      |
| payer_name              |
| payer_type              |
| regulator_reference     |
| contact_person          |
| phone                   |
| email                   |
| portal_url              |
| api_endpoint            |
| claim_submission_method |
| status                  |
| created_at              |

### `benefit_schemes`

| Field                 |
| --------------------- |
| id                    |
| payer_id              |
| scheme_code           |
| scheme_name           |
| scheme_type           |
| contract_id           |
| branch_id             |
| provider_code         |
| effective_from        |
| effective_to          |
| covered_services_json |
| exclusions_json       |
| benefit_limits_json   |
| copay_rules_json      |
| preauth_rules_json    |
| claim_deadline_days   |
| status                |

### `scheme_members`

| Field                     |
| ------------------------- |
| id                        |
| patient_id                |
| payer_id                  |
| scheme_id                 |
| member_number             |
| policy_number             |
| sha_number                |
| principal_member_name     |
| principal_member_number   |
| relationship_to_principal |
| cover_start_date          |
| cover_end_date            |
| eligibility_status        |
| last_verified_at          |
| verification_method       |
| verification_reference    |
| status                    |

### `tariff_tables`

| Field              |
| ------------------ |
| id                 |
| payer_id           |
| scheme_id          |
| tariff_name        |
| version            |
| effective_from     |
| effective_to       |
| source_document_id |
| currency           |
| status             |
| approved_by        |
| approved_at        |

### `tariff_lines`

| Field                        |
| ---------------------------- |
| id                           |
| tariff_table_id              |
| tariff_code                  |
| internal_item_type           |
| internal_item_id             |
| service_category             |
| description                  |
| facility_level_rule          |
| unit_of_measure              |
| allowed_quantity             |
| unit_tariff                  |
| copay_type                   |
| copay_value                  |
| requires_preauth             |
| requires_referral            |
| required_attachments_json    |
| covered_diagnosis_rules_json |
| exclusion_flag               |
| effective_from               |
| effective_to                 |
| status                       |

### `preauthorisations`

| Field                   |
| ----------------------- |
| id                      |
| preauth_number          |
| payer_id                |
| scheme_id               |
| patient_id              |
| member_id               |
| visit_id                |
| provider_code           |
| requesting_clinician_id |
| diagnosis_id            |
| requested_service_type  |
| requested_service_id    |
| clinical_justification  |
| estimated_amount        |
| requested_quantity      |
| urgency                 |
| submission_channel      |
| external_reference      |
| submitted_by            |
| submitted_at            |
| status                  |
| decision_at             |
| decision_by_payer       |
| approval_number         |
| approved_amount         |
| approved_quantity       |
| valid_from              |
| valid_to                |
| denial_reason           |
| conditions              |
| document_id             |

### `claims`

| Field                 |
| --------------------- |
| id                    |
| claim_number          |
| external_claim_number |
| payer_id              |
| scheme_id             |
| patient_id            |
| member_id             |
| branch_id             |
| visit_id              |
| provider_code         |
| claim_type            |
| encounter_start       |
| encounter_end         |
| primary_diagnosis_id  |
| total_claimed_amount  |
| total_patient_portion |
| total_payer_portion   |
| total_approved_amount |
| total_paid_amount     |
| status                |
| submission_channel    |
| submitted_by          |
| submitted_at          |
| acknowledged_at       |
| deadline_date         |
| validation_status     |
| created_at            |

### `claim_lines`

| Field              |
| ------------------ |
| id                 |
| claim_id           |
| line_number        |
| service_category   |
| internal_item_type |
| internal_item_id   |
| tariff_line_id     |
| payer_tariff_code  |
| service_date       |
| quantity           |
| unit_price         |
| gross_amount       |
| copay_amount       |
| patient_portion    |
| payer_portion      |
| approved_amount    |
| paid_amount        |
| diagnosis_id       |
| preauth_id         |
| source_module      |
| source_record_id   |
| status             |
| denial_id          |

### `claim_attachments`

| Field            |
| ---------------- |
| id               |
| claim_id         |
| claim_line_id    |
| attachment_type  |
| source_module    |
| source_record_id |
| document_id      |
| required_flag    |
| uploaded_by      |
| uploaded_at      |
| status           |

### `claim_submissions`

| Field                |
| -------------------- |
| id                   |
| claim_id             |
| submission_number    |
| submission_channel   |
| external_reference   |
| payload_json         |
| submitted_by         |
| submitted_at         |
| response_status      |
| response_message     |
| response_document_id |
| status               |

### `claim_denials`

| Field                  |
| ---------------------- |
| id                     |
| claim_id               |
| claim_line_id          |
| payer_denial_code      |
| denial_category        |
| denial_reason_text     |
| denial_date            |
| amount_denied          |
| recoverable_flag       |
| responsible_department |
| required_correction    |
| correction_deadline    |
| resubmission_allowed   |
| patient_billable_flag  |
| writeoff_amount        |
| status                 |
| created_by             |
| closed_by              |
| closed_at              |
| resolution_type        |
| resolution_notes       |

### `claim_reconciliations`

| Field                       |
| --------------------------- |
| id                          |
| reconciliation_batch_number |
| payer_id                    |
| scheme_id                   |
| remittance_number           |
| payment_date                |
| bank_reference              |
| total_paid                  |
| total_claimed               |
| total_approved              |
| total_denied                |
| total_writeoff              |
| total_patient_balance       |
| status                      |
| reconciled_by               |
| reconciled_at               |
| posted_to_accounting        |
| posted_at                   |

### `claim_reconciliation_lines`

| Field             |
| ----------------- |
| id                |
| reconciliation_id |
| claim_id          |
| claim_line_id     |
| claimed_amount    |
| approved_amount   |
| paid_amount       |
| denied_amount     |
| variance_amount   |
| patient_balance   |
| writeoff_amount   |
| status            |
| notes             |

### `claim_audit_logs`

| Field          |
| -------------- |
| id             |
| entity_type    |
| entity_id      |
| claim_id       |
| action         |
| old_value_json |
| new_value_json |
| reason         |
| performed_by   |
| approved_by    |
| branch_id      |
| created_at     |

---

# 11. API design

## Payer and scheme endpoints

| Endpoint                           | Purpose                  |
| ---------------------------------- | ------------------------ |
| `POST /payers`                     | Create payer             |
| `GET /payers/search`               | Search payers            |
| `POST /benefit-schemes`            | Create scheme            |
| `PATCH /benefit-schemes/{id}`      | Update scheme            |
| `POST /scheme-members`             | Add member/patient cover |
| `POST /scheme-members/{id}/verify` | Verify eligibility       |

## Tariff endpoints

| Endpoint                           | Purpose                         |
| ---------------------------------- | ------------------------------- |
| `POST /tariff-tables`              | Create tariff table             |
| `POST /tariff-tables/{id}/import`  | Import CSV/Excel tariff         |
| `POST /tariff-tables/{id}/approve` | Approve tariff                  |
| `POST /tariff-lines`               | Add tariff line                 |
| `GET /tariffs/lookup`              | Find active tariff for service  |
| `POST /tariffs/map-service`        | Map internal item to payer code |

## Pre-authorisation endpoints

| Endpoint                                | Purpose                     |
| --------------------------------------- | --------------------------- |
| `POST /preauthorisations`               | Create request              |
| `POST /preauthorisations/{id}/submit`   | Submit to payer             |
| `POST /preauthorisations/{id}/decision` | Record decision             |
| `POST /preauthorisations/{id}/attach`   | Attach documents            |
| `GET /preauthorisations/pending`        | Pending approvals           |
| `POST /preauthorisations/{id}/extend`   | Request extension/amendment |

## Claim endpoints

| Endpoint                            | Purpose                   |
| ----------------------------------- | ------------------------- |
| `POST /claims`                      | Create claim              |
| `POST /claims/from-visit/{visitId}` | Generate claim from visit |
| `POST /claims/{id}/validate`        | Run validation            |
| `POST /claims/{id}/submit`          | Submit claim              |
| `POST /claims/{id}/attachments`     | Add attachment            |
| `POST /claims/{id}/return`          | Mark returned             |
| `POST /claims/{id}/approve`         | Record approval           |
| `POST /claims/{id}/reject`          | Record rejection          |
| `POST /claims/{id}/resubmit`        | Resubmit corrected claim  |
| `GET /claims/search`                | Search claims             |
| `GET /claims/{id}/bundle`           | View claim bundle         |

## Denial endpoints

| Endpoint                             | Purpose                 |
| ------------------------------------ | ----------------------- |
| `POST /claim-denials`                | Create denial           |
| `POST /claim-denials/{id}/assign`    | Assign correction task  |
| `POST /claim-denials/{id}/resubmit`  | Resubmit denial         |
| `POST /claim-denials/{id}/write-off` | Write off denied amount |
| `POST /claim-denials/{id}/close`     | Close denial            |
| `GET /claim-denials/report`          | Denial report           |

## Reconciliation endpoints

| Endpoint                                             | Purpose                     |
| ---------------------------------------------------- | --------------------------- |
| `POST /claim-reconciliations`                        | Create reconciliation batch |
| `POST /claim-reconciliations/{id}/import-remittance` | Import payer remittance     |
| `POST /claim-reconciliations/{id}/match`             | Match claims                |
| `POST /claim-reconciliations/{id}/post`              | Post reconciliation         |
| `GET /claim-reconciliations/unmatched`               | Unmatched payments          |
| `GET /claim-reconciliations/ageing`                  | Receivables ageing          |

---

# 12. Integration points

| Integration                  | Purpose                                                         |
| ---------------------------- | --------------------------------------------------------------- |
| Organisation/licensing       | Facility, provider code, contract, professional scope           |
| EMR                          | Clinical note, diagnosis, visit summary, referral, certificates |
| Lab-lite                     | Verified lab results and external lab attachments               |
| Pharmacy                     | Prescription, dispense, batch, actual quantity                  |
| Inventory                    | Consumed items, stock evidence, drug costing                    |
| POS/billing                  | Invoice, co-pay, patient payments, credit notes                 |
| eTIMS                        | Invoice references                                              |
| SHA portal/API               | Eligibility, pre-auth, claim submission, status                 |
| Private insurer portals/APIs | Claim submission/status                                         |
| Accounting                   | Receivables, payments, write-offs, suspense                     |
| Notifications                | Pre-auth decisions, denial tasks, patient balances              |
| Document storage             | Attachments and claim forms                                     |
| Audit/security               | Access, exports, edits, resubmissions                           |

---

# 13. Permissions

| Permission              | Reception | Billing | Clinician | Lab | Pharmacy | Claims officer | Accountant | Manager | Auditor |
| ----------------------- | --------: | ------: | --------: | --: | -------: | -------------: | ---------: | ------: | ------: |
| Add payer/member        |       Yes |     Yes |        No |  No |       No |            Yes |         No |     Yes |    View |
| Verify eligibility      |       Yes |     Yes |        No |  No |       No |            Yes |         No |     Yes |    View |
| Create pre-auth         |   Limited |     Yes |       Yes |  No |       No |            Yes |         No |     Yes |    View |
| Submit pre-auth         |        No | Limited |        No |  No |       No |            Yes |         No |     Yes |    View |
| Configure scheme        |        No |      No |        No |  No |       No |        Limited |         No |     Yes |    View |
| Configure tariff        |        No | Limited |        No |  No |       No |            Yes |        Yes |     Yes |    View |
| Generate claim          |        No |     Yes |        No |  No |       No |            Yes |         No |     Yes |    View |
| Validate claim          |        No |     Yes |        No |  No |       No |            Yes |         No |     Yes |    View |
| Submit claim            |        No |      No |        No |  No |       No |            Yes |         No |     Yes |    View |
| Add clinical attachment |        No |      No |       Yes |  No |       No |            Yes |         No |     Yes |    View |
| Add lab attachment      |        No |      No |        No | Yes |       No |            Yes |         No |     Yes |    View |
| Add pharmacy attachment |        No |      No |        No |  No |      Yes |            Yes |         No |     Yes |    View |
| Record denial           |        No |      No |        No |  No |       No |            Yes |         No |     Yes |    View |
| Write off claim         |        No |      No |        No |  No |       No |        Request |         No |     Yes |    View |
| Reconcile payment       |        No |      No |        No |  No |       No |        Limited |        Yes |     Yes |    View |
| Export claims           |        No |      No |        No |  No |       No |            Yes |        Yes |     Yes |     Yes |
| View audit logs         |        No |      No |        No |  No |       No |        Limited |    Limited |     Yes |     Yes |

---

# 14. Reports

## Claims operations reports

| Report                         | Purpose                                    |
| ------------------------------ | ------------------------------------------ |
| Claims by status               | Draft, submitted, approved, paid, rejected |
| Claims ageing                  | Outstanding by days and payer              |
| Claims by payer                | SHA/private/employer performance           |
| Claims by branch               | Branch performance                         |
| Claims by clinician            | Documentation and claim volume             |
| Claims by service category     | Consultation, lab, drugs, procedure        |
| Claim value report             | Claimed, approved, paid                    |
| Denial report                  | Rejection reasons and amounts              |
| Denial ageing report           | Open denials by days                       |
| Resubmission report            | Recoverable denials                        |
| Pre-auth pending report        | Waiting payer decisions                    |
| Pre-auth expiry report         | Approved but expiring                      |
| Missing attachment report      | Claims blocked by documents                |
| Missing diagnosis report       | Claims blocked by clinical data            |
| Tariff mismatch report         | Pricing issues                             |
| Duplicate claim alert report   | Fraud prevention                           |
| Patient balance report         | Co-pay/uncovered amounts                   |
| Payer remittance report        | Payment batches                            |
| Reconciliation variance report | Under/over payments                        |
| Write-off report               | Lost revenue                               |
| Capitation utilization report  | Cost and service use under capitation      |

## Owner/manager dashboard

```text
Claims submitted today
Claims value this month
Claims approved
Claims paid
Claims rejected
Claims pending correction
Claims overdue
Top denial reasons
Average days to payment
Payer outstanding balances
Patient balances from insurance
Pre-auth pending
Pre-auth expiring
Write-offs this month
```

---

# 15. Quality, fraud, and compliance controls

| Control                       | Requirement                                 |
| ----------------------------- | ------------------------------------------- |
| Duplicate claim detection     | Same member/service/date/provider           |
| Signed note requirement       | Prevent undocumented claims                 |
| Diagnosis-service consistency | Reduce inappropriate claims                 |
| Pre-auth validation           | Prevent unauthorized service claims         |
| Facility-scope validation     | Prevent out-of-scope billing                |
| Clinician-scope validation    | Prevent wrong provider claims               |
| Service-performed evidence    | Lab result, procedure note, dispense record |
| Quantity limits               | Prevent excessive drug/test claims          |
| Immutable submitted claim     | Corrections through version/resubmission    |
| Audit trail                   | All edits, submissions, denials, payments   |
| Attachment versioning         | Preserve original and corrected documents   |
| Payment matching              | Avoid hidden underpayments                  |
| Write-off approval            | Prevent revenue leakage                     |
| Denial analytics              | Fix root causes                             |
| Patient balance rules         | Avoid improper billing after payer denial   |

---

# 16. Edge cases

| Edge case                                           | Correct handling                                                       |
| --------------------------------------------------- | ---------------------------------------------------------------------- |
| Patient claims to be insured but eligibility fails  | Route to cash/self-pay or hold visit pending verification              |
| Payer portal is down                                | Mark verification/submission pending and log manual evidence           |
| Patient has two covers                              | Support primary/secondary payer or manual selection                    |
| Service requires pre-auth but was done in emergency | Emergency override with documentation                                  |
| Pre-auth approved after service                     | Link approval and validate date/payer policy                           |
| Approval amount lower than bill                     | Split balance to patient or request extension                          |
| Claim submitted with missing lab result             | Validation should block before submission                              |
| Lab result comes after claim submission             | Submit addendum/resubmission if payer allows                           |
| Payer rejects for wrong tariff                      | Correct tariff and resubmit                                            |
| Payer pays partially                                | Reconcile partial payment and create denial/variance                   |
| Payer overpays                                      | Flag overpayment/suspense                                              |
| Patient paid cash then insurer pays                 | Refund/allocate patient credit according to policy                     |
| Drug substituted                                    | Claim actual dispensed item with substitution note                     |
| Partial dispense                                    | Claim only quantity supplied                                           |
| Payer denies non-covered medicine                   | Move to patient balance only if policy allows and patient was informed |
| Claim deadline missed                               | Manager review and potential write-off                                 |
| Facility contract expires mid-visit                 | Apply date-of-service contract rule                                    |
| Claim edited after submission                       | Create correction version, not silent edit                             |
| Payer requests more information                     | Task relevant department and track deadline                            |
| Fraud suspicion                                     | Freeze claim and escalate to manager/compliance                        |

---

# 17. MVP versus later versions

## MVP

Build these first:

| Feature                     | Reason                                            |
| --------------------------- | ------------------------------------------------- |
| Payer master                | SHA/private/employer setup                        |
| Benefit scheme setup        | Contract, cover, limits, co-pay                   |
| Member/eligibility record   | Patient cover tracking                            |
| Tariff table                | Correct pricing                                   |
| Claim generation from visit | Reduce double entry                               |
| Claim validation checklist  | Prevent rejections                                |
| Pre-authorisation tracking  | Required for selected services                    |
| Claim bundle                | Patient, provider, diagnosis, services, documents |
| Attachment management       | Lab, prescription, referral, summary              |
| Claim submission status     | Follow-up                                         |
| Denial management           | Recover rejected claims                           |
| Reconciliation              | Paid vs claimed vs patient balance                |
| Receivables ageing          | Cashflow visibility                               |
| Audit logs                  | Compliance and fraud control                      |

## Version 2

Add:

| Feature                             | Reason                                     |
| ----------------------------------- | ------------------------------------------ |
| SHA portal/API adapter              | Faster eligibility, pre-auth, claim status |
| Private insurer portal/API adapters | Reduce manual submissions                  |
| Remittance import                   | Faster reconciliation                      |
| Advanced denial analytics           | Reduce repeat rejections                   |
| Automated claim-form generation     | Faster submission                          |
| Tariff import/mapping tools         | Easier payer setup                         |
| Co-insurance/secondary payer        | Complex insurance support                  |
| Capitation analytics                | Monitor utilization and profitability      |
| Patient balance automation          | Convert uncovered amounts to receivables   |
| Pre-auth SLA alerts                 | Avoid delays                               |
| Medical-necessity checklist         | Stronger claim evidence                    |

## Version 3

Add:

| Feature                              | Reason                                         |
| ------------------------------------ | ---------------------------------------------- |
| AI claim validator                   | Detect missing/weak evidence before submission |
| Fraud/waste/abuse analytics          | Detect duplicate/upcoded/unusual claims        |
| Real-time payer eligibility APIs     | Faster reception workflow                      |
| Automated remittance matching        | Accounting efficiency                          |
| Predictive denial risk               | Reduce claim losses                            |
| Multi-payer coordination of benefits | Advanced insurance                             |
| FHIR Claim/ClaimResponse APIs        | Interoperability                               |
| National platform integration        | Digital Health Act/SHA readiness               |
| Contract profitability analytics     | Know which schemes make/lose money             |
| Provider scorecards                  | Clinician documentation quality                |

---

# 18. Acceptance criteria

The Claims and Insurance Module is ready when it passes these tests:

| Test                               | Expected result                                                                     |
| ---------------------------------- | ----------------------------------------------------------------------------------- |
| Create SHA/private/employer scheme | Scheme has payer, contract, branch, benefits, tariff, dates                         |
| Add member                         | Patient is linked to member number and scheme                                       |
| Verify eligibility                 | Eligibility status and verification record saved                                    |
| Apply tariff                       | Consultation/lab/drug/procedure priced by active payer tariff                       |
| Calculate co-pay                   | Patient and payer portions calculated correctly                                     |
| Detect pre-auth need               | Service requiring pre-auth is blocked until approval                                |
| Record pre-auth approval           | Approval number, amount, quantity, validity stored                                  |
| Generate claim from visit          | Claim pulls patient, provider, diagnosis, services, bill lines                      |
| Attach lab result                  | Verified lab result added to claim bundle                                           |
| Attach prescription/dispense       | Medicine evidence added to claim bundle                                             |
| Validate claim                     | Missing diagnosis, unsigned note, missing result, or tariff issue blocks submission |
| Submit claim                       | Submission reference and status captured                                            |
| Record denial                      | Denial reason, amount, responsible department, correction task captured             |
| Resubmit claim                     | Corrected claim version submitted with history                                      |
| Reconcile payment                  | Paid vs claimed vs approved vs patient balance calculated                           |
| Detect underpayment                | Variance/dispute created                                                            |
| Write off denied amount            | Requires approval and audit                                                         |
| Claims dashboard                   | Shows ageing, denials, pending pre-auths, payer balances                            |
| Audit                              | Every claim edit, attachment, submission, denial, resubmission, payment logged      |

---

# 19. Final product behaviour

The Claims and Insurance Module should behave like this:

| Situation                     | Correct behaviour                                          |
| ----------------------------- | ---------------------------------------------------------- |
| Patient has SHA/private cover | Eligibility and benefit rules are checked                  |
| Service has tariff            | Correct payer price is applied                             |
| Co-pay exists                 | Patient portion is billed immediately                      |
| Pre-auth is required          | Request and approval are captured before claim             |
| Clinician documents visit     | Diagnosis and signed note feed the claim                   |
| Lab test is claimed           | Verified lab result is attached                            |
| Medicine is claimed           | Prescription and dispense record are attached              |
| Referral is required          | Referral letter is attached                                |
| Claim is incomplete           | Submission is blocked with clear missing items             |
| Claim is submitted            | Status and payer reference are tracked                     |
| Claim is rejected             | Reason, amount, correction, and resubmission are tracked   |
| Payer pays                    | Payment is matched to claim lines                          |
| Payer underpays               | Variance and dispute are created                           |
| Patient owes balance          | Patient receivable is created if policy allows             |
| Claim is unrecoverable        | Write-off requires approval                                |
| Owner reviews business        | Payer debt, denial rate, and cashflow exposure are visible |

The key design principle is:

**No insured service should be claimed unless the patient is eligible, the provider is contracted, the service is covered, the tariff is correct, the clinical evidence exists, required attachments are present, and the final payment can be reconciled.**
