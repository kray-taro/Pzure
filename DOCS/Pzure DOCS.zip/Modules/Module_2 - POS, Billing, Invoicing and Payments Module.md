# Module 2: POS, Billing, Invoicing and Payments Module

This module is the **commercial engine** of the system. It handles everything involving money:

```text
Sale → bill/invoice → payment → receipt → eTIMS → stock movement → accounting → shift close → reporting
```

For Kenya, this module must be designed around four realities:

1. **eTIMS compliance is mandatory for businesses issuing taxable business invoices.** KRA says all persons engaged in business are required to onboard eTIMS and issue electronic tax invoices. ([Kenya Revenue Authority][1])
2. **M-Pesa is a primary payment rail**, not an optional add-on. Safaricom’s Daraja platform exposes APIs for M-Pesa payment integration, including C2B, reversals, and transaction-status queries. ([developer.safaricom.co.ke][2])
3. **Pharmacy, clinic, lab, and retail sales are different transaction types** and should not all be treated as ordinary shop sales.
4. **Cash leakage and stock leakage are major risks**, so cashier shifts, approvals, audit logs, and stock-to-sale reconciliation are core features.

---

# 1. Purpose of the module

The POS and Billing Module should:

| Purpose                      | Practical meaning                                                   |
| ---------------------------- | ------------------------------------------------------------------- |
| Sell products and services   | Drugs, OTC items, retail goods, consultation, lab tests, procedures |
| Generate compliant invoices  | eTIMS-ready invoice data and credit notes                           |
| Receive payments             | M-Pesa, cash, card, bank, credit, insurer, split payments           |
| Control discounts            | Prevent unauthorized price cutting                                  |
| Control cash                 | Cashier shifts, float, expected cash, variances                     |
| Update stock                 | Medicine and retail stock reduce correctly                          |
| Support claims               | Patient/insurer portions separated                                  |
| Support multiple price lists | Retail, wholesale, insurer, corporate, branch-specific              |
| Support receipts             | Thermal receipt, A4 invoice, WhatsApp/SMS/email                     |
| Support audit                | Every sale, void, return, discount, payment, and edit is traceable  |

---

# 2. Core principle: separate sale, invoice, receipt, and payment

Many weak POS systems mix these together. A proper system should treat them separately.

| Object             | Meaning                                                                   |
| ------------------ | ------------------------------------------------------------------------- |
| **Cart / bill**    | Draft list of items/services before finalization                          |
| **Sale**           | Completed commercial transaction                                          |
| **Invoice**        | Tax/commercial document issued for the sale                               |
| **eTIMS invoice**  | KRA-recognized electronic tax invoice                                     |
| **Receipt**        | Evidence given to customer showing what was sold and how payment was made |
| **Payment**        | Cash, M-Pesa, card, insurer, credit, or mixed settlement                  |
| **Credit note**    | Reversal/correction linked to original invoice                            |
| **Refund**         | Money returned to customer                                                |
| **Stock movement** | Inventory deduction, return, adjustment, or transfer                      |

This matters because a customer can receive an invoice before full payment, an insurer can pay later, and a return may require a credit note rather than deleting the original sale.

---

# 3. Main users

| User           | Main actions                                                   |
| -------------- | -------------------------------------------------------------- |
| Cashier        | Sell items, receive payment, print receipt                     |
| Pharmacist     | Approve/dispense medicine sale, override pharmacy restrictions |
| Receptionist   | Bill consultation, register patient payments                   |
| Lab cashier    | Bill tests and packages                                        |
| Clinician      | Add billable services, procedures, prescription items          |
| Branch manager | Approve discounts, voids, refunds, shift variances             |
| Owner          | View sales, cash, profit, stock, branch performance            |
| Accountant     | Reconcile eTIMS, payments, credit notes, taxes                 |
| Claims officer | Split bill between patient and insurer/SHA                     |
| Auditor        | Review all transaction logs                                    |

---

# 4. Core transaction types

The system should support different transaction categories.

| Transaction type           | Example                           |      Stock affected? |      Patient record? |                        eTIMS? |
| -------------------------- | --------------------------------- | -------------------: | -------------------: | ----------------------------: |
| Retail goods sale          | Soap, glucose, cosmetics          |                  Yes |             Optional |         Yes, where applicable |
| OTC medicine sale          | Paracetamol, ORS                  |                  Yes | Optional/recommended |                           Yes |
| Prescription medicine sale | Antibiotic, chronic medicine      |                  Yes |      Yes/recommended |                           Yes |
| Consultation               | Doctor/clinical officer visit     |                   No |                  Yes | Yes, unless excluded/exempted |
| Lab test                   | Malaria test, CBC, urinalysis     | Consumables optional |                  Yes |                           Yes |
| Procedure                  | Dressing, injection, nebulization | Consumables optional |                  Yes |                           Yes |
| Package sale               | Consultation + lab + medicine     |                Mixed |                  Yes |                           Yes |
| Wholesale sale             | Bulk medicines/retail items       |                  Yes |             Optional |                           Yes |
| Insurance/SHA bill         | Insurer pays part/all             |                Mixed |                  Yes |                  Claim-linked |
| Credit customer sale       | Employer/corporate account        |                Mixed |         Optional/yes |                           Yes |
| Return                     | Customer returns item             |                  Yes |             Optional |                   Credit note |
| Void/cancel                | Mistaken sale before finalization |       No or reversed |             Optional |       Depends on eTIMS status |

---

# 5. Feature-by-feature design

## A. Fast checkout

The checkout screen should work quickly for both touchscreen and keyboard users.

### Required features

| Feature             | Requirement                                                    |
| ------------------- | -------------------------------------------------------------- |
| Product search      | Search by brand, generic, barcode, SKU, category               |
| Keyboard shortcuts  | New sale, quantity, discount, payment, hold bill, print        |
| Touch buttons       | Common items, categories, payment buttons                      |
| Customer lookup     | Phone, name, patient number, insurer membership                |
| Hold/resume bill    | Useful when customer pauses to get money                       |
| Quick quantity edit | `2x`, pack split, unit selection                               |
| Fast payment        | Cash, M-Pesa, card, split                                      |
| Repeat last sale    | Useful for common services/products                            |
| Offline checkout    | Continue selling when internet is down                         |
| Role-aware checkout | Cashier sees sale functions; pharmacist sees dispense controls |

### Recommended checkout layout

```text
LEFT: product/service search + cart
RIGHT: customer/patient + price list + payment
BOTTOM: total, tax, discount, eTIMS status, print/send buttons
TOP: cashier, branch, shift, online/offline status
```

### Keyboard shortcuts

| Shortcut | Action               |
| -------- | -------------------- |
| F1       | Search item          |
| F2       | Add customer/patient |
| F3       | Hold bill            |
| F4       | Resume bill          |
| F5       | Apply discount       |
| F6       | Cash payment         |
| F7       | M-Pesa payment       |
| F8       | Card payment         |
| F9       | Print receipt        |
| F10      | Complete sale        |
| Ctrl + R | Return/credit note   |
| Ctrl + V | Void draft bill      |
| Ctrl + L | Lock POS             |

---

## B. Barcode scanning

Barcode scanning must support both retail goods and medicine stock.

### Barcode types

| Barcode type         | Use                                                           |
| -------------------- | ------------------------------------------------------------- |
| Internal SKU barcode | Locally generated code for items without manufacturer barcode |
| Manufacturer barcode | Retail goods and packaged medicines                           |
| GS1 GTIN             | Standard product identification                               |
| QR/DataMatrix-ready  | Future medicine traceability and serialization                |
| Batch barcode        | Warehouse/pharmacy stock receiving                            |
| Patient barcode      | Clinic/patient file lookup                                    |
| Receipt barcode/QR   | Return lookup and invoice verification                        |

### Barcode behaviour

| Scenario                       | System behaviour                                 |
| ------------------------------ | ------------------------------------------------ |
| Product barcode found          | Add item to cart                                 |
| Multiple products share code   | Ask user to select                               |
| Product found but stock zero   | Warn or block depending on settings              |
| Product expired                | Block sale                                       |
| Product near expiry            | Warn before sale                                 |
| Prescription-only item scanned | Require prescription/pharmacist approval         |
| Batch-controlled item scanned  | Ask/select batch                                 |
| Serial-controlled item scanned | Capture serial number                            |
| Unknown barcode                | Allow “create product” only for authorized staff |

---

## C. Item and service sale

The POS must sell both physical products and services.

### Product/service classification

| Type                  | Examples                               | Special handling             |
| --------------------- | -------------------------------------- | ---------------------------- |
| Retail product        | Soap, lotion, tissue                   | Normal stock                 |
| OTC medicine          | ORS, painkillers                       | Stock + medicine category    |
| Prescription medicine | Antibiotics, antihypertensives         | Prescription workflow        |
| Controlled medicine   | Narcotic/psychotropic where applicable | Strict register and approval |
| Consultation          | General consultation, review           | Patient/clinician link       |
| Lab test              | Malaria, CBC, pregnancy test           | Lab order/result link        |
| Procedure             | Dressing, injection                    | Clinical note/procedure link |
| Package               | Consultation + test + medicine         | Bundle pricing               |
| Non-stock service     | Registration, certificate              | No inventory                 |
| Stock-linked service  | Injection using syringe/drug           | Consumes stock               |

### Required line-item fields

| Field                     | Notes                                           |
| ------------------------- | ----------------------------------------------- |
| Item/service code         | Internal code                                   |
| Description               | Receipt/eTIMS description                       |
| Category                  | Retail, medicine, lab, procedure, consultation  |
| Quantity                  | Units sold                                      |
| Unit of measure           | Tablet, bottle, pack, service, test             |
| Batch                     | For medicine/controlled stock                   |
| Expiry date               | For medicine/perishable stock                   |
| Unit price                | Before discount                                 |
| Discount                  | Amount/percentage                               |
| Tax code/rate             | VAT/exempt/non-VAT depending on product/service |
| Gross amount              | Line total                                      |
| Net amount                | After discount                                  |
| Patient link              | Required for clinical/pharmacy workflows        |
| Prescriber/clinician link | Where relevant                                  |
| Cost price                | For margin reporting                            |
| Price list used           | Retail, wholesale, insurer, etc.                |
| Approval status           | For restricted line items                       |

---

## D. eTIMS invoice

This is one of the most important Kenya-specific parts.

KRA’s eTIMS page states that eTIMS is a software solution for electronic invoicing and that all persons engaged in business are required to onboard and issue electronic tax invoices. ([Kenya Revenue Authority][1]) The Electronic Tax Invoice Regulations require each sale to be recorded in the system, an invoice generated for each sale, invoice details transmitted to the Commissioner, and stock-in/stock-out records maintained where applicable. ([Kenya Law][3])

### eTIMS invoice data requirements

The regulations specify that an electronic tax invoice should contain items such as the seller’s PIN, date and time, serial number, buyer PIN where the buyer intends to claim the expense or input tax, gross amount, tax amount where applicable, item code, goods/services description, quantity, unit of measure, tax rate, unique system identifier, unique invoice identifier, QR code, and any other information specified by the Commissioner. ([Kenya Law][3])

### Required eTIMS fields in the system

| Field                    | Source                                                                       |
| ------------------------ | ---------------------------------------------------------------------------- |
| Seller KRA PIN           | Organisation/branch tax setup                                                |
| Branch/outlet identifier | Branch setup                                                                 |
| Invoice date and time    | POS transaction                                                              |
| Invoice serial number    | System sequence                                                              |
| Buyer PIN                | Customer/patient/company profile, optional unless needed for claim/input tax |
| Buyer name               | Customer/patient/company profile                                             |
| Item code                | Product/service master                                                       |
| Description              | Product/service master                                                       |
| Quantity                 | Cart                                                                         |
| Unit of measure          | Product/service master                                                       |
| Unit price               | Price list                                                                   |
| Tax rate                 | Tax mapping                                                                  |
| Gross amount             | POS calculation                                                              |
| Tax amount               | POS calculation                                                              |
| Discount                 | POS calculation                                                              |
| Unique invoice ID        | eTIMS response/system                                                        |
| QR code                  | eTIMS response/system                                                        |
| Credit note reference    | Original invoice                                                             |
| Transmission status      | Pending, submitted, accepted, rejected                                       |
| Error message            | If rejected                                                                  |
| Retry count              | For offline/sync                                                             |

### eTIMS workflow

```text
1. Cashier builds bill
2. System validates item tax codes and customer details
3. User confirms sale
4. System generates internal sale number
5. System sends invoice data to eTIMS or queues it if offline
6. eTIMS returns/accepts invoice identifiers and QR details
7. Receipt is printed/sent with invoice details
8. Stock and financial records are finalized
9. Accountant can reconcile eTIMS status later
```

### eTIMS status model

| Status         | Meaning                                  |
| -------------- | ---------------------------------------- |
| Not required   | Internal transaction not requiring eTIMS |
| Draft          | Bill not finalized                       |
| Pending        | Invoice waiting to be sent               |
| Queued offline | Internet/eTIMS unavailable               |
| Submitted      | Sent to eTIMS                            |
| Accepted       | eTIMS accepted invoice                   |
| Rejected       | eTIMS rejected invoice                   |
| Retrying       | System retrying                          |
| Cancelled      | Voided before final tax invoice          |
| Credit-noted   | Corrected/reversed using credit note     |

### Offline eTIMS handling

The regulations require system continuity and state that where a user cannot use the system, the user should notify the Commissioner within twenty-four hours and record sales using other specified means; once use is restored, the sales recorded during the outage should be entered into the system. ([Kenya Law][3])

System behaviour should therefore be:

| Scenario              | System behaviour                                           |
| --------------------- | ---------------------------------------------------------- |
| Internet down         | Allow sale, mark eTIMS status as queued offline            |
| eTIMS service down    | Allow sale if configured, queue invoice                    |
| eTIMS rejection       | Show reason and block final “compliant” status until fixed |
| Offline queue too old | Escalate to accountant/admin                               |
| Reconnected           | Auto-sync pending invoices                                 |
| Sale synced later     | Preserve original sale time and sync time                  |
| Manual outage         | Generate outage report for compliance/admin use            |

### eTIMS audit requirements

The regulations require systems to be secure, tamper-proof, capable of integrating with KRA systems, transmitting data, recording and storing required information, maintaining data integrity, authenticating authorized users, logging all activities, and assigning a unique identifier to each invoice. ([Kenya Law][3])

So the POS must log:

| Event              | Logged data                    |
| ------------------ | ------------------------------ |
| Invoice created    | User, branch, time, device     |
| Invoice submitted  | Payload reference, time        |
| Invoice accepted   | eTIMS ID/QR/status             |
| Invoice rejected   | Error and correction           |
| Credit note issued | Original invoice reference     |
| Invoice reprint    | User and reason                |
| Tax code changed   | Old value, new value, approver |
| eTIMS retry        | Retry time and response        |

---

## E. Multiple payment methods

The system must support Kenya’s real payment reality: one bill can be paid partly by M-Pesa, partly by cash, partly by insurer, and partly on credit.

### Payment methods

| Method                  | Required fields                                                    |
| ----------------------- | ------------------------------------------------------------------ |
| Cash                    | Amount tendered, change, cashier, drawer                           |
| M-Pesa                  | Phone, Till/Paybill, receipt code, transaction ID, callback status |
| Card                    | Terminal ID, authorization code, masked card reference             |
| Bank transfer           | Bank, reference, date, amount                                      |
| Credit/customer account | Customer/company account, due date, credit limit                   |
| Insurer/SHA             | Payer, member number, authorization, patient co-pay                |
| Voucher/loyalty         | Voucher code, balance, approval                                    |
| Split payment           | Multiple payment lines against one bill                            |

### M-Pesa integration

Safaricom’s Daraja platform connects web/mobile applications to M-Pesa APIs. Safaricom’s business developer portal describes exposed APIs including C2B, reversals, and transaction status queries. ([developer.safaricom.co.ke][2])

Recommended M-Pesa flows:

| Flow                             | Use case                                      |
| -------------------------------- | --------------------------------------------- |
| STK Push / Lipa na M-Pesa Online | Cashier initiates prompt to customer phone    |
| C2B confirmation                 | Customer pays Till/Paybill manually           |
| Transaction status query         | Confirm payment not received through callback |
| Reversal                         | Refund or wrong payment handling              |
| Reconciliation                   | Match M-Pesa statement to POS payments        |

### M-Pesa payment states

| Status                     | Meaning                                           |
| -------------------------- | ------------------------------------------------- |
| Initiated                  | STK/C2B request started                           |
| Pending customer action    | Customer has not entered PIN                      |
| Paid                       | Callback/confirmation received                    |
| Failed                     | Customer cancelled, timeout, insufficient funds   |
| Manual verification needed | Customer claims paid but no callback              |
| Reversed                   | Payment reversed                                  |
| Partially allocated        | Payment received but not fully matched to invoice |
| Overpaid                   | Payment exceeds invoice                           |
| Underpaid                  | Payment less than invoice                         |

### Split payment example

```text
Bill total: KES 3,800

M-Pesa: KES 2,000
Cash: KES 500
Insurer: KES 1,000
Patient credit: KES 300

Balance: KES 0
```

The system should not finalize the bill as fully paid until allocated payments equal the payable amount, unless it is intentionally posted to credit.

---

## F. Credit notes

Credit notes are required for returns and invoice corrections after a tax invoice has already been issued. The Electronic Tax Invoice Regulations state that where a credit note or debit note is issued, it should reference the original invoice number to which the supply relates. ([Kenya Law][3])

### Credit note reasons

| Reason               | Example                                  |
| -------------------- | ---------------------------------------- |
| Customer return      | Wrong item bought                        |
| Damaged product      | Returned due to defect                   |
| Pricing error        | Wrong price charged                      |
| Quantity error       | Sold 10 instead of 1                     |
| Duplicate invoice    | Same sale billed twice                   |
| Insurance correction | Wrong payer/patient split                |
| Prescription change  | Clinician changed drug before dispensing |
| Service cancellation | Lab/procedure cancelled before delivery  |

### Credit note rules

| Rule                                    | System behaviour                                |
| --------------------------------------- | ----------------------------------------------- |
| Must reference original invoice         | Block standalone credit note                    |
| Cannot credit more than original amount | Block excess credit                             |
| Medicine return may be restricted       | Require pharmacist approval                     |
| Controlled medicine return              | Require strict audit and stock decision         |
| Expired/damaged return                  | Return to quarantine, not sellable stock        |
| Cash refund                             | Manager approval required                       |
| M-Pesa/card refund                      | Link to original payment and reversal/reference |
| Insurer claim affected                  | Flag claim for correction                       |
| eTIMS invoice already accepted          | Issue eTIMS credit note, do not delete invoice  |

### Return stock handling

| Returned item condition | Stock action                                      |
| ----------------------- | ------------------------------------------------- |
| Unopened, acceptable    | Return to sellable stock if policy allows         |
| Opened medicine         | Quarantine/dispose                                |
| Cold-chain item         | Quarantine unless temperature integrity confirmed |
| Expired item            | Quarantine/write-off                              |
| Controlled item         | Pharmacist/superintendent approval                |
| Service return          | No stock movement                                 |

---

## G. Cashier shift close

Shift close is essential for fraud and cash control.

### Shift lifecycle

```text
Open shift → sell/receive payments → cash drops/expenses → close shift → manager review → post to accounts
```

### Opening shift fields

| Field               | Notes              |
| ------------------- | ------------------ |
| Cashier             | User opening shift |
| Branch              | Outlet             |
| Terminal/device     | POS terminal       |
| Opening float       | Starting cash      |
| Open time           | Timestamp          |
| Supervisor approval | Optional           |
| Expected drawer     | Calculated         |

### Closing shift fields

| Field            | Notes                                        |
| ---------------- | -------------------------------------------- |
| Cash sales       | System calculated                            |
| Cash refunds     | System calculated                            |
| Cash expenses    | Petty cash if allowed                        |
| Cash drops       | Money removed from drawer                    |
| Expected cash    | Opening float + cash sales - refunds - drops |
| Counted cash     | Cashier-entered                              |
| Variance         | Counted minus expected                       |
| M-Pesa expected  | System total                                 |
| M-Pesa confirmed | Callback/statement total                     |
| Card expected    | System total                                 |
| Card settlement  | Terminal batch total                         |
| Credit sales     | Posted to accounts                           |
| Insurer sales    | Claim receivables                            |
| Closing notes    | Reason for variance                          |
| Manager approval | Required above variance limit                |

### Shift close rules

| Rule                                      | System behaviour                                     |
| ----------------------------------------- | ---------------------------------------------------- |
| Cashier cannot close with open held bills | Require bill resolution                              |
| Variance above threshold                  | Manager approval required                            |
| Missing M-Pesa confirmations              | Flag reconciliation issue                            |
| Refunds in shift                          | Require refund report                                |
| Voids in shift                            | Require void report                                  |
| Discounts in shift                        | Require discount report                              |
| Unsubmitted eTIMS invoices                | Warn before close                                    |
| Offline shift                             | Close locally, sync later, manager sees offline flag |

---

## H. Receipt printer

The POS should support 58mm and 80mm thermal printers because these are common in small Kenyan retail and pharmacy environments.

### Printer types

| Printer                     | Use                                               |
| --------------------------- | ------------------------------------------------- |
| 58mm thermal                | Small shops, low-cost setups                      |
| 80mm thermal                | Pharmacies and busy outlets                       |
| A4 printer                  | Insurance invoices, clinic bills, formal invoices |
| Label printer               | Pharmacy labels                                   |
| PDF receipt                 | WhatsApp/email download                           |
| Kitchen-style order printer | Optional for procedure/lab collection points      |

### Receipt content

| Receipt section | Content                                     |
| --------------- | ------------------------------------------- |
| Header          | Business name, branch, KRA PIN, contacts    |
| Licence info    | Optional PPB/KMPDC line for pharmacy/clinic |
| Invoice details | Invoice number, date, cashier               |
| Customer        | Name/phone/PIN if captured                  |
| Items           | Description, quantity, price, discount, tax |
| Payments        | Cash/M-Pesa/card/credit/insurer             |
| eTIMS details   | QR/unique invoice details where available   |
| Return policy   | Especially for medicines                    |
| Footer          | Thank you, support contact                  |

### Pharmacy receipt additions

| Field                    | Purpose                                                         |
| ------------------------ | --------------------------------------------------------------- |
| Patient name             | Dispensing accountability                                       |
| Prescription reference   | Links to prescription                                           |
| Pharmacist initials/name | Accountability                                                  |
| Batch/expiry optional    | Useful for recall, may be hidden by default on customer receipt |
| Medicine return warning  | Safety and legal control                                        |

---

## I. Discount controls

Discounts are a major leakage point. The system should control who can discount what.

### Discount types

| Type                        | Example                     |
| --------------------------- | --------------------------- |
| Line discount               | 5% off one item             |
| Bill discount               | KES 100 off full bill       |
| Promotion                   | Buy 2 get 1                 |
| Staff discount              | Employee benefit            |
| Corporate discount          | Employer scheme             |
| Insurance tariff adjustment | Contracted payer price      |
| Expiry discount             | Near-expiry stock clearance |
| Manager goodwill discount   | Complaint resolution        |
| Rounding discount           | Small rounding adjustment   |

### Discount rules

| Rule                                | System behaviour                          |
| ----------------------------------- | ----------------------------------------- |
| Cashier discount limit              | Example: max 2% or KES 50                 |
| Manager approval threshold          | Required above configured limit           |
| No discount below cost              | Block or require owner approval           |
| No discount on controlled medicines | Block unless allowed by policy            |
| No discount on insurer-tariff items | Use contracted tariff                     |
| Expiry discount                     | Require batch selection and expiry reason |
| Promotion discount                  | Auto-applied, not manually edited         |
| Discount reason required            | Mandatory for audit                       |
| Approval audit                      | Store approver, time, reason              |

### Sensitive discount categories

| Category               | Recommended control               |
| ---------------------- | --------------------------------- |
| Prescription medicines | Pharmacist/manager approval       |
| Controlled medicines   | Block or strict approval          |
| High-value items       | Manager approval                  |
| Insurance/SHA bills    | Contract tariff only              |
| Lab packages           | Manager/clinic admin approval     |
| Wholesale prices       | Customer account must be eligible |

---

## J. Multi-price lists

The same item can have different prices depending on branch, customer, payer, or channel.

### Price list types

| Price list         | Use                              |
| ------------------ | -------------------------------- |
| Retail cash        | Default walk-in customer         |
| Wholesale          | Bulk buyers                      |
| Branch-specific    | Different rent/competition/costs |
| Insurer tariff     | Private insurer contract price   |
| SHA tariff         | SHA contract/benefit pricing     |
| Corporate/employer | Staff/company accounts           |
| Online price       | E-commerce/online pharmacy       |
| Promotion price    | Campaigns                        |
| Staff price        | Internal staff purchases         |
| Chronic-care price | Repeat patient programmes        |

### Price selection hierarchy

Recommended order:

```text
1. Explicit payer contract tariff
2. Customer/corporate contract price
3. Branch-specific price
4. Active promotion price
5. Default retail price
6. Fallback base price
```

### Price-list fields

| Field             | Notes                                 |
| ----------------- | ------------------------------------- |
| Price list name   | Retail, wholesale, AAR, SHA, Branch A |
| Applies to        | Branch/customer/payer/channel         |
| Effective date    | Start                                 |
| Expiry date       | End                                   |
| Item/service code | Product/service                       |
| Unit price        | Selling price                         |
| Minimum quantity  | For wholesale tiers                   |
| Approval status   | Draft/approved                        |
| Approved by       | Manager/owner                         |
| Version           | Historical pricing                    |
| Margin check      | Warn below cost                       |

### Price rules

| Rule                 | System behaviour                                 |
| -------------------- | ------------------------------------------------ |
| Price expired        | Fall back to next valid price                    |
| Price below cost     | Warn/block                                       |
| Wrong payer selected | Do not apply insurer tariff                      |
| Branch override      | Use branch-specific price if active              |
| Price changed        | Log old price, new price, user, reason           |
| Backdated price      | Owner/admin only                                 |
| Wholesale price      | Requires eligible customer or quantity threshold |

---

# 6. Screens required

## Screen 1: Main POS checkout

Key panels:

| Panel            | Contents                                                     |
| ---------------- | ------------------------------------------------------------ |
| Header           | Branch, terminal, cashier, shift, online/eTIMS/M-Pesa status |
| Search           | Barcode/product/service search                               |
| Cart             | Line items, quantities, discounts, tax, batch                |
| Customer/patient | Walk-in, patient, company, insurer                           |
| Price list       | Active price list and override warning                       |
| Payment          | Cash, M-Pesa, card, credit, insurer                          |
| Actions          | Hold, void, discount, complete, print, send receipt          |

Must show:

```text
Subtotal
Discount
Tax
Total
Paid
Balance
eTIMS status
Stock warning
Approval warning
```

---

## Screen 2: Service billing screen

For clinics/labs.

Sections:

| Section         | Purpose                               |
| --------------- | ------------------------------------- |
| Patient details | Patient/account/insurer               |
| Visit/encounter | Links bill to clinical visit          |
| Services        | Consultation, procedure, lab, imaging |
| Prescriptions   | Pulls billable medicines              |
| Claim split     | Patient vs insurer                    |
| Payment         | Co-pay, cash, M-Pesa, insurer credit  |
| Invoice         | eTIMS/commercial invoice              |

---

## Screen 3: Payment screen

Must support split payments.

Example layout:

```text
Bill total:       KES 5,250
Amount paid:      KES 3,000
Balance:          KES 2,250

[Cash] [M-Pesa] [Card] [Insurer] [Credit] [Bank]
```

Payment line table:

| Method  | Amount | Reference    | Status        |
| ------- | -----: | ------------ | ------------- |
| M-Pesa  |  2,000 | QF45...      | Confirmed     |
| Cash    |    500 | Drawer 1     | Confirmed     |
| Insurer |  2,750 | Preauth #123 | Pending claim |

---

## Screen 4: Returns and credit notes

Required fields:

| Field                    | Notes                                |
| ------------------------ | ------------------------------------ |
| Original invoice number  | Mandatory                            |
| Item selection           | Cannot exceed original sale          |
| Reason                   | Mandatory                            |
| Return condition         | Sellable/quarantine/damaged/expired  |
| Refund method            | Cash/M-Pesa/card/credit account      |
| Approval                 | Manager/pharmacist depending on item |
| eTIMS credit note status | Pending/accepted/rejected            |

---

## Screen 5: Shift close

Sections:

| Section       | Shows                         |
| ------------- | ----------------------------- |
| Shift summary | Opening/closing time, cashier |
| Cash          | Expected vs counted           |
| M-Pesa        | Expected vs confirmed         |
| Card          | Expected vs terminal batch    |
| Credit        | Customer account sales        |
| Insurer       | Claims receivable             |
| Discounts     | Total and approvals           |
| Voids         | Count and value               |
| Refunds       | Count and value               |
| eTIMS         | Submitted, queued, rejected   |
| Variance      | Difference and explanation    |
| Approval      | Manager sign-off              |

---

## Screen 6: Sales history

Search by:

| Search key       |
| ---------------- |
| Receipt number   |
| Invoice number   |
| eTIMS identifier |
| M-Pesa code      |
| Customer phone   |
| Patient number   |
| Product          |
| Batch            |
| Cashier          |
| Date/time        |
| Branch           |
| Payment method   |

Actions:

| Action             | Control             |
| ------------------ | ------------------- |
| Reprint receipt    | Logged              |
| Send receipt       | Logged              |
| View invoice       | Role-based          |
| Create credit note | Permission required |
| Refund             | Permission required |
| View audit trail   | Manager/auditor     |
| Link payment       | Accountant/manager  |
| Export             | Permission required |

---

# 7. Workflows

## A. Retail cash sale

```text
1. Cashier scans/searches item
2. System checks stock and price
3. Cashier confirms quantity
4. Customer pays cash/M-Pesa/card
5. System finalizes sale
6. eTIMS invoice generated/submitted
7. Receipt printed/sent
8. Stock decremented
9. Sale appears in shift close
```

---

## B. Prescription medicine sale

```text
1. Cashier/pharmacist searches medicine
2. System detects prescription-only category
3. Patient and prescription are required
4. Pharmacist validates prescription
5. Batch/expiry selected
6. Price/tax calculated
7. Payment taken
8. eTIMS invoice generated/submitted
9. Receipt and medicine label printed
10. Stock decremented
11. Dispensing audit recorded
```

The sale should not behave like an ordinary retail item. It should be connected to the dispensing module.

---

## C. Clinic consultation billing

```text
1. Patient is registered
2. Reception selects consultation type
3. System applies price list
4. Patient pays or insurer/SHA is selected
5. Invoice generated
6. Patient joins queue
7. Consultation service is marked as paid or billable
```

Configuration option:

| Setting                 | Behaviour                                       |
| ----------------------- | ----------------------------------------------- |
| Pay before consultation | Common in outpatient clinics                    |
| Pay after consultation  | Useful where clinician adds services            |
| Mixed                   | Consultation paid first, lab/drugs after review |

---

## D. Lab test billing

```text
1. Clinician or reception orders test
2. Billing confirms price
3. Patient/insurer pays or bill is posted
4. Lab receives paid/pending order
5. Result is entered later
6. Bill and result remain linked
```

Important rule:

```text
A lab result should not be detached from the bill, patient, and visit.
```

---

## E. Insurer/SHA split bill

```text
1. Patient selected
2. Payer selected
3. Eligibility/preauth captured
4. Services/items priced by payer tariff
5. Patient co-pay calculated
6. Patient pays co-pay
7. Insurer portion posted to claims receivable
8. Claim record created
9. Invoice/receipt issued according to configured policy
```

### Bill split example

| Line         |     Total | Patient |   Insurer |
| ------------ | --------: | ------: | --------: |
| Consultation |     1,000 |     200 |       800 |
| Lab          |       700 |       0 |       700 |
| Medicine     |     1,500 |     300 |     1,200 |
| **Total**    | **3,200** | **500** | **2,700** |

---

## F. Credit customer sale

```text
1. Customer/company account selected
2. System checks credit limit
3. Sale is completed
4. eTIMS invoice generated
5. Amount posted to accounts receivable
6. Payment collected later
7. Receipt issued for payment allocation
```

Controls:

| Rule                          | Behaviour                             |
| ----------------------------- | ------------------------------------- |
| Customer exceeds credit limit | Block or manager approval             |
| Customer overdue              | Block new credit sale                 |
| Credit sale to walk-in        | Not allowed                           |
| Payment received later        | Allocate against outstanding invoices |

---

## G. Return and refund

```text
1. Search original invoice
2. Select item/service to return
3. System validates return eligibility
4. User enters reason
5. Manager/pharmacist approves if needed
6. Credit note issued referencing original invoice
7. Stock returned/quarantined where applicable
8. Refund or account credit processed
9. Shift and reports updated
```

---

# 8. Rules engine

The module should expose pricing, tax, payment, and compliance rules to other modules.

## Example rules

```text
RULE: Complete sale
IF cart has at least one line
AND all restricted items are approved
AND all stock-controlled lines have available stock
AND all required customer/patient fields are present
AND payment status is valid or sale is allowed on credit
THEN allow sale completion
ELSE show blocker list
```

```text
RULE: Prescription medicine sale
IF item.category = prescription_medicine
AND prescription_reference exists
AND pharmacist_approval = true
AND batch is selected
AND batch.expiry_date > today
THEN allow dispensing sale
ELSE block sale
```

```text
RULE: eTIMS invoice
IF transaction.requires_etims = true
AND seller_kra_pin exists
AND all line items have tax codes
AND invoice total is valid
THEN generate/send eTIMS invoice
ELSE block final compliant invoice
```

```text
RULE: Credit note
IF original_invoice.status = accepted
AND credit_amount <= original_invoice_remaining_amount
AND reason is provided
THEN issue credit note referencing original invoice
ELSE block credit note
```

```text
RULE: Discount
IF requested_discount <= user.discount_limit
THEN allow
ELSE require manager approval
```

```text
RULE: Shift close
IF counted_cash variance <= allowed_threshold
AND all critical payments reconciled
THEN allow cashier close
ELSE require manager approval
```

---

# 9. Tax and item-code configuration

The system should not hard-code tax treatment carelessly. It should allow tax configuration by product/service category, branch, and effective date.

## Tax configuration fields

| Field             | Notes                                  |
| ----------------- | -------------------------------------- |
| Tax code          | Internal/KRA mapping                   |
| Tax name          | VAT, exempt, zero-rated, non-VAT, etc. |
| Rate              | Percentage                             |
| Effective date    | Start date                             |
| End date          | End date                               |
| Applies to        | Product/service/category               |
| KRA item code     | Where applicable                       |
| Editable by       | Accountant/admin only                  |
| Approval required | Yes                                    |
| Audit log         | Mandatory                              |

## Product/service tax rules

| Item type          | Requirement                                |
| ------------------ | ------------------------------------------ |
| Retail item        | Tax code required                          |
| Medicine           | Tax code required                          |
| Consultation       | Tax code required                          |
| Lab test           | Tax code required                          |
| Procedure          | Tax code required                          |
| Insurance bill     | Tax rules still need clear mapping         |
| Exempt transaction | Must be explicitly configured, not assumed |

---

# 10. Stock integration

The POS must never sell stock without writing inventory movements.

## Stock movements triggered by POS

| Transaction                      | Stock movement                                |
| -------------------------------- | --------------------------------------------- |
| Sale                             | Stock out                                     |
| Return to sellable stock         | Stock in                                      |
| Return to quarantine             | Stock in quarantine                           |
| Credit note for service          | No stock                                      |
| Void before finalization         | No stock or reverse reservation               |
| Prescription dispense            | Stock out by batch                            |
| Package/service with consumables | Stock out for consumables                     |
| Stock unavailable                | Block or backorder depending on configuration |

## FEFO for medicine stock

For medicines, the POS should recommend **FEFO: first-expiry, first-out**.

```text
If two batches exist:
Batch A expires in July 2026
Batch B expires in December 2026

System recommends Batch A first.
```

The user may override only with reason and permission.

---

# 11. Customer, patient, and buyer PIN handling

The POS should support anonymous walk-in retail sales but also structured customer/patient billing.

## Customer types

| Type               | Use                                 |
| ------------------ | ----------------------------------- |
| Walk-in            | Quick OTC/retail sale               |
| Patient            | Clinic/pharmacy patient             |
| Corporate customer | Employer/company account            |
| Wholesale buyer    | Bulk pricing                        |
| Insurer/SHA member | Claims workflow                     |
| Staff member       | Staff purchases                     |
| Supplier           | Supplier return/contra transactions |

## Buyer PIN

The Electronic Tax Invoice Regulations include buyer PIN where the buyer intends to claim an expense or input tax. ([Kenya Law][3])

System behaviour:

| Scenario                              | Buyer PIN requirement                  |
| ------------------------------------- | -------------------------------------- |
| Walk-in patient buying medicine       | Optional unless required by policy     |
| Company buying supplies               | Required/recommended                   |
| Employer/corporate account            | Required                               |
| Insurer/corporate payer               | Required/recommended                   |
| Patient wants invoice for tax/expense | Capture buyer PIN                      |
| Buyer PIN missing                     | Warn if invoice is corporate/claimable |

---

# 12. Audit logs

Every financially sensitive action must be logged.

| Action                | Log details                     |
| --------------------- | ------------------------------- |
| Sale created          | User, branch, terminal, time    |
| Sale completed        | Amount, payment, invoice        |
| Price changed         | Old/new price, reason, approver |
| Discount applied      | Amount, reason, approver        |
| Item removed          | Item, user, reason              |
| Bill voided           | User, reason                    |
| Refund issued         | User, amount, method, approver  |
| Credit note issued    | Original invoice, reason        |
| eTIMS submission      | Status, response, error         |
| M-Pesa payment linked | Code, amount, user              |
| Shift opened/closed   | Cashier, float, variance        |
| Cash drawer opened    | User, reason                    |
| Receipt reprinted     | User, reason                    |
| Offline sale synced   | Original time, sync time        |

---

# 13. Reports

## Daily business reports

| Report                    | Purpose                                     |
| ------------------------- | ------------------------------------------- |
| Daily sales summary       | Total revenue by branch/date                |
| Sales by cashier          | Staff performance/control                   |
| Sales by payment method   | Cash, M-Pesa, card, credit, insurer         |
| Sales by category         | Drugs, retail, consultation, lab, procedure |
| Gross margin report       | Revenue minus cost                          |
| Discount report           | Detect leakage                              |
| Void/cancellation report  | Fraud control                               |
| Refund/credit note report | Returns monitoring                          |
| Cashier shift report      | Expected vs counted cash                    |
| eTIMS status report       | Submitted, queued, rejected                 |
| M-Pesa reconciliation     | Expected vs confirmed payments              |
| Credit customer ageing    | Outstanding balances                        |
| Insurer receivables       | Claims pending/payment                      |
| Price override report     | Unauthorized price changes                  |
| Stock sold by batch       | Recall and traceability                     |
| Near-expiry sales         | Monitor expiry clearance                    |
| Branch comparison         | Chain/franchise performance                 |

## Owner dashboard

Recommended cards:

```text
Today’s sales
Today’s cash expected
M-Pesa confirmed
eTIMS pending/rejected
Gross margin
Top-selling products
Low-stock fast movers
Discounts today
Refunds today
Open shifts
Unreconciled payments
Claims receivable
```

---

# 14. Database design

## Main tables

### `pos_terminals`

| Field               |
| ------------------- |
| id                  |
| branch_id           |
| terminal_name       |
| device_identifier   |
| printer_config_json |
| cash_drawer_enabled |
| status              |
| last_seen_at        |

### `shifts`

| Field               |
| ------------------- |
| id                  |
| branch_id           |
| terminal_id         |
| cashier_user_id     |
| opened_at           |
| opening_float       |
| closed_at           |
| expected_cash       |
| counted_cash        |
| variance            |
| manager_approved_by |
| status              |
| notes               |

### `sales`

| Field             |
| ----------------- |
| id                |
| organisation_id   |
| branch_id         |
| terminal_id       |
| shift_id          |
| sale_number       |
| sale_type         |
| customer_id       |
| patient_id        |
| visit_id          |
| payer_contract_id |
| price_list_id     |
| subtotal          |
| discount_total    |
| tax_total         |
| gross_total       |
| amount_paid       |
| balance_due       |
| payment_status    |
| invoice_status    |
| etims_status      |
| status            |
| created_by        |
| completed_by      |
| completed_at      |
| created_at        |

### `sale_lines`

| Field           |
| --------------- |
| id              |
| sale_id         |
| line_number     |
| item_type       |
| product_id      |
| service_id      |
| description     |
| quantity        |
| unit_of_measure |
| unit_price      |
| discount_amount |
| tax_code_id     |
| tax_rate        |
| tax_amount      |
| line_total      |
| cost_amount     |
| batch_id        |
| expiry_date     |
| prescription_id |
| clinician_id    |
| approval_status |
| approved_by     |
| notes           |

### `payments`

| Field                   |
| ----------------------- |
| id                      |
| sale_id                 |
| branch_id               |
| shift_id                |
| payment_method          |
| amount                  |
| currency                |
| status                  |
| reference_number        |
| mpesa_receipt_code      |
| card_authorization_code |
| payer_contract_id       |
| customer_account_id     |
| received_by             |
| received_at             |
| reconciled_at           |
| reversal_status         |
| notes                   |

### `invoices`

| Field                   |
| ----------------------- |
| id                      |
| sale_id                 |
| invoice_number          |
| invoice_type            |
| buyer_name              |
| buyer_pin               |
| seller_pin              |
| issue_datetime          |
| subtotal                |
| tax_total               |
| gross_total             |
| status                  |
| etims_unique_identifier |
| etims_qr_code           |
| etims_response_json     |
| submitted_at            |
| accepted_at             |
| rejected_at             |
| rejection_reason        |

### `credit_notes`

| Field               |
| ------------------- |
| id                  |
| original_invoice_id |
| credit_note_number  |
| reason_code         |
| reason_text         |
| subtotal            |
| tax_total           |
| gross_total         |
| refund_method       |
| status              |
| approved_by         |
| etims_status        |
| created_by          |
| created_at          |

### `credit_note_lines`

| Field                 |
| --------------------- |
| id                    |
| credit_note_id        |
| original_sale_line_id |
| quantity              |
| amount                |
| tax_amount            |
| stock_action          |
| return_condition      |

### `price_lists`

| Field             |
| ----------------- |
| id                |
| name              |
| type              |
| branch_id         |
| customer_group_id |
| payer_contract_id |
| effective_from    |
| effective_to      |
| status            |
| approved_by       |

### `price_list_items`

| Field            |
| ---------------- |
| id               |
| price_list_id    |
| product_id       |
| service_id       |
| unit_price       |
| minimum_quantity |
| maximum_quantity |
| margin_rule      |
| effective_from   |
| effective_to     |

### `tax_codes`

| Field          |
| -------------- |
| id             |
| code           |
| name           |
| rate           |
| applies_to     |
| effective_from |
| effective_to   |
| kra_mapping    |
| status         |

### `mpesa_transactions`

| Field                 |
| --------------------- |
| id                    |
| branch_id             |
| sale_id               |
| checkout_request_id   |
| merchant_request_id   |
| phone_number          |
| amount                |
| mpesa_receipt_code    |
| transaction_date      |
| result_code           |
| result_description    |
| callback_payload_json |
| status                |
| reconciled_by         |
| reconciled_at         |

### `audit_logs`

| Field          |
| -------------- |
| id             |
| entity_type    |
| entity_id      |
| action         |
| old_value_json |
| new_value_json |
| reason         |
| performed_by   |
| approved_by    |
| branch_id      |
| terminal_id    |
| created_at     |

---

# 15. API design

## POS endpoints

| Endpoint                               | Purpose                    |
| -------------------------------------- | -------------------------- |
| `POST /pos/sales`                      | Create draft sale          |
| `POST /pos/sales/{id}/lines`           | Add item/service           |
| `PATCH /pos/sales/{id}/lines/{lineId}` | Edit quantity/discount     |
| `POST /pos/sales/{id}/hold`            | Hold bill                  |
| `POST /pos/sales/{id}/resume`          | Resume bill                |
| `POST /pos/sales/{id}/complete`        | Finalize sale              |
| `POST /pos/sales/{id}/void`            | Void draft or allowed sale |
| `GET /pos/sales/search`                | Search sales history       |
| `POST /pos/sales/{id}/print`           | Print receipt              |
| `POST /pos/sales/{id}/send-receipt`    | SMS/email/WhatsApp receipt |

## Payment endpoints

| Endpoint                          | Purpose                  |
| --------------------------------- | ------------------------ |
| `POST /payments/cash`             | Record cash payment      |
| `POST /payments/mpesa/stk`        | Initiate M-Pesa prompt   |
| `POST /payments/mpesa/callback`   | Receive M-Pesa callback  |
| `GET /payments/mpesa/status/{id}` | Query payment status     |
| `POST /payments/card`             | Record card payment      |
| `POST /payments/credit`           | Post to customer account |
| `POST /payments/refund`           | Process refund           |
| `POST /payments/reconcile`        | Reconcile payment        |

## Invoice/eTIMS endpoints

| Endpoint                               | Purpose               |
| -------------------------------------- | --------------------- |
| `POST /invoices`                       | Create invoice        |
| `POST /invoices/{id}/submit-etims`     | Submit invoice        |
| `GET /invoices/{id}/etims-status`      | Check status          |
| `POST /credit-notes`                   | Create credit note    |
| `POST /credit-notes/{id}/submit-etims` | Submit credit note    |
| `GET /etims/queue`                     | View pending invoices |
| `POST /etims/retry`                    | Retry failed invoices |

## Shift endpoints

| Endpoint                      | Purpose                               |
| ----------------------------- | ------------------------------------- |
| `POST /shifts/open`           | Open cashier shift                    |
| `POST /shifts/{id}/cash-drop` | Record cash drop                      |
| `POST /shifts/{id}/expense`   | Record petty cash expense, if allowed |
| `POST /shifts/{id}/close`     | Close shift                           |
| `POST /shifts/{id}/approve`   | Manager approval                      |
| `GET /shifts/{id}/summary`    | Shift report                          |

---

# 16. Integration points

| Integration                   | Purpose                                                  |
| ----------------------------- | -------------------------------------------------------- |
| Organisation/licensing module | Confirms branch can sell medicines, consult, bill claims |
| Inventory module              | Stock availability, batch, expiry, cost                  |
| Pharmacy module               | Prescription validation and dispensing                   |
| Clinic EMR                    | Consultation, procedure, prescription billing            |
| Lab module                    | Test billing and payment status                          |
| Claims module                 | Insurer/SHA split, preauth, claim receivable             |
| eTIMS                         | Tax invoice and credit note submission                   |
| M-Pesa Daraja                 | STK, C2B, transaction status, reversal                   |
| Accounting                    | Revenue, VAT/tax, receivables, cash, bank                |
| Notifications                 | Send receipt/payment reminders                           |
| User management               | Cashier, manager, pharmacist, accountant permissions     |

---

# 17. Permissions

| Permission             |    Cashier |   Pharmacist |    Reception |      Manager |   Accountant |        Owner |
| ---------------------- | ---------: | -----------: | -----------: | -----------: | -----------: | -----------: |
| Create sale            |        Yes |          Yes |          Yes |          Yes |           No |          Yes |
| Sell OTC item          |        Yes |          Yes | Configurable |          Yes |           No |          Yes |
| Sell prescription item | No/limited |          Yes |           No | Configurable |           No | Configurable |
| Apply small discount   |        Yes |          Yes |          Yes |          Yes |           No |          Yes |
| Approve large discount |         No | Configurable |           No |          Yes |           No |          Yes |
| Void sale              | No/limited |   No/limited |   No/limited |          Yes |           No |          Yes |
| Issue refund           |         No |   No/limited |           No |          Yes | Configurable |          Yes |
| Issue credit note      |         No | Configurable |           No |          Yes |          Yes |          Yes |
| Open/close own shift   |        Yes |          Yes |          Yes |          Yes |           No |          Yes |
| Approve shift variance |         No |           No |           No |          Yes |          Yes |          Yes |
| Change tax code        |         No |           No |           No |           No |          Yes |          Yes |
| Change price list      |         No |           No |           No |      Limited |          Yes |          Yes |
| View all branch sales  |         No |      Limited |      Limited |          Yes |          Yes |          Yes |

---

# 18. Edge cases the system must handle

| Edge case                                | Correct handling                                               |
| ---------------------------------------- | -------------------------------------------------------------- |
| Customer pays M-Pesa but callback delays | Mark payment pending; allow status query/manual reconciliation |
| Customer overpays M-Pesa                 | Mark overpayment; allocate/refund/hold as customer credit      |
| Sale completed while offline             | Queue eTIMS and sync later                                     |
| eTIMS rejects invoice                    | Keep sale, flag invoice as rejected, require correction/retry  |
| Cashier sells wrong item                 | Use credit note/return, not database deletion                  |
| Medicine returned after leaving pharmacy | Quarantine or block resale depending on policy                 |
| Insurer rejects claim                    | Move balance to patient/receivable workflow                    |
| Price changed during sale                | Lock price once bill is created unless refreshed               |
| Batch sold out before finalization       | Ask user to select another batch                               |
| Shift closed with pending M-Pesa         | Show unreconciled payment report                               |
| Receipt printer fails                    | Save sale and allow reprint/send digital receipt               |
| Customer has no phone                    | Allow cash sale but no SMS receipt                             |
| Corporate buyer needs PIN                | Capture buyer PIN before invoice finalization                  |
| Power outage                             | Local recovery from last saved draft/transaction queue         |

---

# 19. MVP versus later versions

## MVP

Build these first:

| Feature                                   | Reason                        |
| ----------------------------------------- | ----------------------------- |
| Fast POS checkout                         | Daily operations              |
| Product/service sale                      | Retail, medicine, clinic, lab |
| Cash and M-Pesa recording                 | Kenya payment reality         |
| Basic M-Pesa confirmation/manual matching | Prevent fake payment claims   |
| eTIMS-ready invoice data                  | Compliance foundation         |
| Receipt printing                          | Customer proof                |
| Credit notes/returns                      | Corrections                   |
| Cashier shift close                       | Fraud control                 |
| Discounts with approval                   | Margin protection             |
| Retail and branch price lists             | Pricing flexibility           |
| Basic reports                             | Owner visibility              |
| Stock decrement                           | Inventory accuracy            |
| Audit logs                                | Accountability                |

## Version 2

Add:

| Feature                            | Reason                            |
| ---------------------------------- | --------------------------------- |
| Full Daraja STK/C2B integration    | Better payment automation         |
| eTIMS system-to-system integration | Reduce manual invoicing           |
| Advanced split payments            | Insurance/corporate workflows     |
| Customer credit accounts           | Corporate/employer billing        |
| Insurer/SHA tariff pricing         | Claims accuracy                   |
| Label printing                     | Pharmacy workflow                 |
| Barcode batch scanning             | Faster pharmacy/warehouse control |
| Refund/reversal automation         | Cleaner reconciliation            |
| Offline sync dashboard             | Compliance visibility             |
| Advanced cash drawer controls      | Better anti-fraud                 |

## Version 3

Add:

| Feature                         | Reason                               |
| ------------------------------- | ------------------------------------ |
| AI margin/discount alerts       | Detect suspicious discounts          |
| Dynamic price optimization      | Branch and competition pricing       |
| Loyalty wallet                  | Retail retention                     |
| Customer portal invoices        | Self-service                         |
| Automated bank reconciliation   | Accounting efficiency                |
| Multi-branch treasury dashboard | Chain management                     |
| Advanced fraud analytics        | Detect cashier/stock/payment leakage |
| Full accounting integration     | ERP readiness                        |

---

# 20. Acceptance criteria

The module is ready when it passes these tests:

| Test              | Expected result                                                            |
| ----------------- | -------------------------------------------------------------------------- |
| Fast retail sale  | Cashier scans item, takes payment, prints receipt, stock reduces           |
| OTC sale          | Item sells normally with stock and invoice update                          |
| Prescription sale | System requires prescription/pharmacist approval before completion         |
| Clinic billing    | Consultation bill links to patient visit                                   |
| Lab billing       | Lab test bill creates payable/paid lab order                               |
| M-Pesa payment    | Payment is recorded with reference and matched to sale                     |
| Split payment     | One bill can be paid by M-Pesa + cash + insurer                            |
| eTIMS invoice     | Sale generates required invoice data and stores eTIMS status               |
| Offline sale      | Sale completes locally and queues invoice/payment sync                     |
| Credit note       | Credit note references original invoice and updates return/refund          |
| Shift close       | Expected cash and counted cash are compared                                |
| Discount approval | Cashier cannot exceed discount limit without approval                      |
| Multi-price       | Correct price list applies by branch/customer/payer                        |
| Return medicine   | Return requires reason and correct stock action                            |
| Audit trail       | Sale edits, voids, refunds, discounts, and reprints are logged             |
| Owner dashboard   | Owner sees sales, cash, M-Pesa, eTIMS, discounts, refunds, and open shifts |

---

# 21. Final product behaviour

The POS and Billing Module should not be a generic supermarket till. It should behave like a **Kenya-ready health retail billing engine**:

| Situation                  | Correct behaviour                                              |
| -------------------------- | -------------------------------------------------------------- |
| Retail item sold           | Fast POS, stock out, receipt, eTIMS                            |
| Medicine sold              | Stock, batch, expiry, pharmacy controls                        |
| Prescription medicine sold | Prescription and pharmacist approval required                  |
| Clinic service billed      | Patient visit and clinician workflow linked                    |
| Lab test billed            | Lab order and payment status linked                            |
| Insurer involved           | Patient/insurer split and claim receivable created             |
| M-Pesa used                | Payment matched, reconciled, and auditable                     |
| Cash used                  | Shift close controls expected cash                             |
| Return happens             | Credit note, original invoice reference, stock/refund handling |
| Discount applied           | Approval and reason captured                                   |
| Internet fails             | Sales continue, eTIMS/payment sync queued                      |
| Owner reviews business     | Clear sales, margin, payment, stock, and compliance reports    |

The key design principle is:

**Every shilling, every invoice, every stock movement, and every cashier action must be traceable.**

[1]: https://www.kra.go.ke/online-services/etims " eTIMS - KRA "
[2]: https://developer.safaricom.co.ke/ "Daraja Developer Portal | Safaricom"
[3]: https://new.kenyalaw.org/akn/ke/act/ln/2024/64 "
      The Tax Procedures (Electronic Tax Invoice) Regulations
    \- Kenya Law"
