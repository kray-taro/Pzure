Correct. Module 6 needs a formal lab terminology decision.

I would close this as:

```text
ADR-023: Laboratory Test Catalogue, LOINC Mapping, Kenya KEDL Alignment, and Result Terminology Strategy
```

# 1. Architecture decision

For this Kenyan 10-branch implementation, use a **hybrid lab catalogue**:

```text
Canonical operational catalogue:
    Internal facility lab test catalogue

Kenya alignment:
    Kenya Essential Diagnostics List / local facility scope

Interoperability mapping:
    LOINC where a suitable code exists

FHIR mapping:
    ServiceRequest for orders
    Specimen for samples
    Observation for atomic results
    DiagnosticReport for released lab reports
```

So the answer is:

| Question                               | Decision                                                                                          |
| -------------------------------------- | ------------------------------------------------------------------------------------------------- |
| Internal or LOINC?                     | **Both**. Internal catalogue is operational; LOINC is interoperability mapping.                   |
| Kenya-specific?                        | **Yes**. Align test availability with Kenya Essential Diagnostics List and branch/facility scope. |
| Full LOINC import?                     | Not necessary for MVP. Import/map a controlled subset first.                                      |
| Can tests exist without LOINC?         | Yes, but marked `loinc_mapping_status = unmapped`.                                                |
| Can claims/reports use internal codes? | Yes, but with payer/KHIS/export mappings where needed.                                            |
| External labs?                         | Support external lab test codes and cross-mapping.                                                |

LOINC is a universal code system for tests, measurements, and observations, and is widely used to identify and exchange clinical and laboratory observations. It is best used here as a mapping layer rather than the operational catalogue itself. ([Regenstrief Institute][1])

---

# 2. Why not use LOINC as the only catalogue?

LOINC is powerful, but it is not a complete operational lab catalogue by itself.

A clinic still needs local operational fields:

| Operational need      | Why LOINC alone is not enough                      |
| --------------------- | -------------------------------------------------- |
| Local price           | LOINC does not define your branch price            |
| Billing item          | LOINC does not define your POS/service item        |
| Sample workflow       | Facility-specific collection process needed        |
| Container             | EDTA, plain tube, urine container, swab            |
| Turnaround time       | Local branch/external lab dependent                |
| In-house vs send-out  | Local operational rule                             |
| Machine/manual method | Depends on equipment                               |
| Reference ranges      | Depend on method, unit, age, sex, pregnancy        |
| Result template       | Panel layout differs by facility/device            |
| Claims tariff         | Payer-specific                                     |
| Stock consumption     | Reagents, kits, strips, consumables                |
| Branch availability   | Some tests available in one branch but not another |

Therefore:

```text
Use internal lab test codes to run the clinic.
Use LOINC codes to interoperate, report, and exchange data.
```

---

# 3. Kenya-specific source layer

The Kenya Essential Diagnostics List 2023 should be used as a **local alignment reference** for what diagnostics are essential in Kenya’s health system context. The KEDL 2023 describes 249 essential in-vitro diagnostics for clinical management, public-health surveillance, and forensic testing for Kenya’s priority communicable and non-communicable diseases. ([prescribingcompanion.com][2])

Use it for:

| Use                       | Example                                             |
| ------------------------- | --------------------------------------------------- |
| Facility test scope       | Which tests are reasonable for a small clinic/lab   |
| Public health alignment   | Priority communicable and non-communicable diseases |
| Procurement alignment     | Essential diagnostic supplies/kits                  |
| Branch capability mapping | Which KEPH/facility level can perform what          |
| Reporting alignment       | Internal grouping and future KHIS/DHIS2 mapping     |

Do **not** treat KEDL as a result-code system. It is a diagnostics list/reference, not a full interoperability terminology like LOINC.

---

# 4. Lab code systems needed

The lab module needs multiple code systems, not one.

| Code system                | Role                                                          |
| -------------------------- | ------------------------------------------------------------- |
| Internal lab test code     | Operational ordering, billing, workflow                       |
| LOINC                      | Interoperability and standardized observation/result identity |
| External lab code          | Reference lab’s own test code                                 |
| Payer tariff code          | Claims and reimbursement                                      |
| KHIS/DHIS2 reporting group | Aggregate reporting                                           |
| Inventory item code        | Reagent/kit/consumable link                                   |
| Device/analyser code       | Future analyser integration                                   |
| Local synonym/alias        | Clinician search UX                                           |

Example:

```text
Internal test: LAB-MAL-RDT
Display name: Malaria rapid diagnostic test
LOINC: mapped where appropriate
Specimen: capillary/whole blood
Method: RDT
Billing code: SVC-LAB-MAL-RDT
Payer tariff code: depends on payer
Inventory link: malaria RDT kit
Reporting group: Malaria diagnostics
External lab code: not applicable
```

---

# 5. Data model additions

Add a `terminology` layer for lab codes and a `lab` operational catalogue.

## 5.1 `terminology.code_systems`

Already proposed for ICD-10; extend it to LOINC and local lab systems.

| Field           | Purpose                                      |
| --------------- | -------------------------------------------- |
| id              | Internal ID                                  |
| code_system_key | LOINC, LOCAL_LAB, EXTERNAL_LAB, PAYER_TARIFF |
| name            | Code system name                             |
| version         | Version                                      |
| publisher       | Regenstrief, internal, external lab, payer   |
| canonical_uri   | FHIR/terminology URI                         |
| licence_notes   | Usage notes                                  |
| active_flag     | Active/inactive                              |
| imported_at     | Import timestamp                             |

---

## 5.2 `lab.lab_tests`

This is the operational catalogue.

| Field                     | Purpose                                          |
| ------------------------- | ------------------------------------------------ |
| id                        | Internal ID                                      |
| test_code                 | Internal code, e.g. `LAB-CBC`                    |
| test_name                 | Display name                                     |
| short_name                | CBC, RBS, UPT                                    |
| category                  | Haematology, chemistry, microbiology, urinalysis |
| test_type                 | Single, panel, profile, package                  |
| orderable_flag            | Can be ordered                                   |
| resultable_flag           | Can have results                                 |
| in_house_flag             | In-house or external                             |
| default_external_lab_id   | If send-out                                      |
| specimen_type             | Blood, urine, stool, swab, serum                 |
| collection_container      | EDTA, plain tube, urine cup                      |
| sample_volume             | Optional                                         |
| method                    | RDT, microscopy, analyser, dipstick              |
| turnaround_minutes        | Expected TAT                                     |
| requires_fasting          | Yes/no                                           |
| requires_consent          | Yes/no                                           |
| requires_clinician_order  | Yes/no                                           |
| requires_verification     | Yes/no                                           |
| branch_availability_scope | All branches/specific branches                   |
| billing_service_id        | Link to POS service                              |
| claim_category            | Lab                                              |
| active_flag               | Active/inactive                                  |

---

## 5.3 `lab.lab_test_code_mappings`

Maps internal test to LOINC, external lab, payer, or reporting code.

| Field                  | Purpose                                                 |
| ---------------------- | ------------------------------------------------------- |
| id                     | Mapping ID                                              |
| lab_test_id            | Internal test                                           |
| code_system_id         | LOINC/external/payer/KHIS                               |
| external_code          | Mapped code                                             |
| external_display       | External display name                                   |
| mapping_type           | exact, broader, narrower, panel, component, approximate |
| mapping_confidence     | high, medium, low                                       |
| mapped_by              | User/system                                             |
| clinically_verified_by | Lab in-charge/clinician                                 |
| active_flag            | Active/inactive                                         |
| effective_from         | Date                                                    |
| effective_to           | Date                                                    |

Important: not all mappings are exact. A local “LFT” panel may map to multiple component LOINC codes, not one single code.

---

## 5.4 `lab.lab_test_components`

For panel tests.

| Field                 | Purpose                           |
| --------------------- | --------------------------------- |
| id                    | Component ID                      |
| parent_lab_test_id    | Panel/profile                     |
| component_lab_test_id | Atomic test/component             |
| display_name          | Hb, WBC, Platelets                |
| display_order         | Print order                       |
| required_flag         | Required result                   |
| result_type           | Numeric, coded, text              |
| unit                  | g/dL, mmol/L, cells/µL            |
| loinc_code            | Optional direct component mapping |
| active_flag           | Active/inactive                   |

Example:

```text
CBC / FBC
    Hb
    WBC
    RBC
    Platelets
    MCV
    MCH
    MCHC
    Differential counts
```

Each component may have its own LOINC mapping.

---

## 5.5 `lab.lab_reference_ranges`

Reference ranges are not purely terminology; they are method, unit, age, sex, and sometimes pregnancy dependent.

| Field            | Purpose                    |
| ---------------- | -------------------------- |
| id               | Range ID                   |
| lab_test_id      | Test/component             |
| sex              | Male/female/all            |
| min_age_days     | Age lower bound            |
| max_age_days     | Age upper bound            |
| pregnancy_status | pregnant/non-pregnant/all  |
| method           | Optional                   |
| unit             | Unit                       |
| low_value        | Numeric low                |
| high_value       | Numeric high               |
| critical_low     | Critical low               |
| critical_high    | Critical high              |
| text_range       | For non-numeric            |
| source           | Local/lab/device/reference |
| verified_by      | Lab in-charge              |
| active_flag      | Active/inactive            |

---

## 5.6 `lab.lab_result_value_sets`

For coded results.

| Field         | Purpose                                                  |
| ------------- | -------------------------------------------------------- |
| id            | Value set ID                                             |
| lab_test_id   | Test/component                                           |
| allowed_value | Positive, negative, reactive, non-reactive, trace, +, ++ |
| display_label | Human display                                            |
| abnormal_flag | Normal/high/low/abnormal                                 |
| critical_flag | Yes/no                                                   |
| display_order | Order                                                    |
| active_flag   | Active/inactive                                          |

---

## 5.7 `lab.external_lab_test_catalogues`

For reference labs.

| Field                  | Purpose               |
| ---------------------- | --------------------- |
| id                     | External catalogue ID |
| external_lab_id        | Partner lab           |
| external_test_code     | Their code            |
| external_test_name     | Their display name    |
| specimen_requirement   | Their requirement     |
| turnaround_time        | Their TAT             |
| external_price         | Cost to facility      |
| result_delivery_method | Portal/email/API/PDF  |
| mapped_lab_test_id     | Internal test         |
| active_flag            | Active/inactive       |

---

# 6. Import strategy

## MVP import

Do not import full LOINC immediately unless the team is ready to govern it. LOINC is large and broad, including many non-lab observations.

Recommended MVP approach:

```text
1. Build internal lab catalogue for in-house and send-out tests.
2. Seed common tests:
   CBC/FBC
   malaria RDT
   malaria microscopy if offered
   urinalysis
   urine pregnancy test
   random blood sugar
   fasting blood sugar
   HbA1c if send-out
   blood group if offered
   HIV/HBsAg/syphilis screening if configured and compliant
   LFT/RFT/lipid profile if send-out
3. Map each test or component to LOINC where clear.
4. Mark uncertain mappings as pending verification.
5. Maintain external lab code mappings separately.
```

## Version 2 import

| Import                  | Purpose                                      |
| ----------------------- | -------------------------------------------- |
| LOINC subset            | Only lab-relevant codes used by the facility |
| KEDL alignment table    | Kenya essential diagnostics mapping          |
| External lab catalogues | Send-out mapping                             |
| Payer tariff tables     | Claims mapping                               |
| KHIS reporting groups   | Aggregate reports                            |

## Version 3 import

| Import                           | Purpose                                |
| -------------------------------- | -------------------------------------- |
| Full LOINC or terminology server | Advanced interoperability              |
| FHIR terminology service         | `$lookup`, `$validate-code`, `$expand` |
| Analyser/device mappings         | Automated result import                |
| External lab API mappings        | Electronic result exchange             |

---

# 7. LOINC mapping strategy

## Mapping rule

Do not map casually by test name alone. LOINC depends on:

```text
Component
Property
Time
System/specimen
Scale
Method
```

For example, “glucose” may differ by specimen, timing, and method.

## Mapping confidence

| Confidence | Meaning                                                   |
| ---------- | --------------------------------------------------------- |
| High       | Exact component/specimen/unit/method match                |
| Medium     | Clinically acceptable but method not exact                |
| Low        | Approximate mapping; not used for exchange without review |
| Unmapped   | No mapping yet                                            |

## Governance rule

```text
No LOINC mapping should be marked high confidence until reviewed by lab in-charge or qualified clinical/lab governance user.
```

---

# 8. Search UX for test catalogue

Lab test search should work for both clinicians and lab users.

## Search should support

| Search input | Result                                  |
| ------------ | --------------------------------------- |
| CBC          | Complete blood count / full blood count |
| FBC          | CBC/FBC                                 |
| Malaria      | Malaria RDT, microscopy                 |
| RBS          | Random blood sugar                      |
| UPT          | Urine pregnancy test                    |
| Urine        | Urinalysis, urine microscopy, pregnancy |
| LFT          | Liver function tests                    |
| RFT          | Renal function tests                    |
| HbA1c        | HbA1c                                   |
| HIV          | HIV screening tests where configured    |
| Blood group  | ABO/Rh                                  |

## Ranking

```text
score =
    exact_code_match
  + exact_short_name_match
  + synonym_match
  + branch_available_boost
  + clinician_recent_boost
  + branch_frequency_boost
  + in_house_boost
  - inactive_penalty
  - unavailable_at_branch_penalty
```

## Test picker result row

```text
CBC / FBC
Category: Haematology
Specimen: Whole blood
Container: EDTA
Location: In-house
TAT: 30 min
Price: KES ...
LOINC: mapped / pending
```

---

# 9. Lab ordering and result model

## FHIR-aligned design

Use FHIR concepts even before exposing FHIR APIs.

| Workflow object  | FHIR equivalent   |
| ---------------- | ----------------- |
| Lab order        | ServiceRequest    |
| Sample           | Specimen          |
| Result component | Observation       |
| Final report     | DiagnosticReport  |
| Attachment/PDF   | DocumentReference |

FHIR ServiceRequest represents an order/request for a service such as a diagnostic investigation, and DiagnosticReport is used for reports such as laboratory reports that can reference observations/results. ([FHIR][3])

---

# 10. Result template design

## Single result test

Example: Malaria RDT

| Field                             |
| --------------------------------- |
| Result: Positive/Negative/Invalid |
| Method                            |
| Kit lot                           |
| Kit expiry                        |
| Comment                           |
| Verified by                       |

## Numeric result

Example: Random blood sugar

| Field           |
| --------------- |
| Numeric value   |
| Unit            |
| Reference range |
| Abnormal flag   |
| Critical flag   |
| Comment         |

## Panel result

Example: CBC

| Component    | Result type        |
| ------------ | ------------------ |
| Hb           | Numeric            |
| WBC          | Numeric            |
| Platelets    | Numeric            |
| RBC          | Numeric            |
| MCV          | Numeric            |
| MCH          | Numeric            |
| MCHC         | Numeric            |
| Differential | Numeric/percentage |

## Semi-quantitative result

Example: urinalysis

| Component        | Allowed values              |
| ---------------- | --------------------------- |
| Protein          | Negative, trace, +, ++, +++ |
| Glucose          | Negative, trace, +, ++, +++ |
| Ketones          | Negative, trace, +, ++, +++ |
| Blood            | Negative, trace, +, ++, +++ |
| Nitrite          | Negative, positive          |
| Leukocytes       | Negative, trace, +, ++, +++ |
| pH               | Numeric                     |
| Specific gravity | Numeric                     |

---

# 11. Kenya reporting and KHIS/DHIS2 mapping

The lab module should support aggregate reporting groups, not just individual tests. Kenya’s Ministry of Health Virtual Academy describes KHIS Aggregate as powered by DHIS2, with data entry, reporting, and visualizations. ([MOH-VA][4])

Add:

## `lab.lab_reporting_groups`

| Field               | Purpose                                              |
| ------------------- | ---------------------------------------------------- |
| id                  | Group                                                |
| group_name          | Malaria diagnostics, HIV testing, diabetes screening |
| reporting_framework | Internal, KHIS, payer, public health                 |
| active_flag         | Active                                               |

## `lab.lab_reporting_group_members`

| Field            | Purpose                                                       |
| ---------------- | ------------------------------------------------------------- |
| group_id         | Reporting group                                               |
| lab_test_id      | Test                                                          |
| aggregation_rule | Count ordered, count resulted, count positive, count abnormal |

This allows reports like:

```text
Malaria tests ordered
Malaria positive rate
Pregnancy tests performed
Glucose screening count
External send-outs by category
```

---

# 12. Claims integration

Each lab test must map to billable service and payer tariff.

## Required mappings

| Mapping                               | Purpose              |
| ------------------------------------- | -------------------- |
| `lab_test_id → billing.service_id`    | POS billing          |
| `billing.service_id → tariff_line_id` | Claims pricing       |
| `lab_result_id → claim_attachment`    | Claim evidence       |
| `lab_test_id → payer_test_code`       | Payer-specific claim |
| `lab_test_id → LOINC`                 | Interoperability     |
| `lab_test_id → reporting_group`       | Analytics            |

## Claim readiness rule

```text
If claim line category = lab,
then a verified lab result must exist,
and the test must have an active tariff mapping for the payer,
and required attachment rules must be satisfied.
```

---

# 13. Inventory integration

Lab tests consume stock.

## Required stock links

| Lab item           | Inventory link                         |
| ------------------ | -------------------------------------- |
| Malaria RDT        | Test kit batch                         |
| Pregnancy test     | Test kit batch                         |
| Glucose test       | Strip/lancet/gloves                    |
| Urinalysis         | Dipstick strip                         |
| CBC                | EDTA tube/reagent if configured        |
| External send-out  | Sample container/transport consumables |
| Cold-chain reagent | Cold-chain stock                       |

## Data model

### `lab.lab_test_consumables`

| Field                  | Purpose                  |
| ---------------------- | ------------------------ |
| id                     | ID                       |
| lab_test_id            | Test                     |
| product_id             | Reagent/kit/consumable   |
| quantity_per_test      | Consumption quantity     |
| required_flag          | Whether stock must exist |
| batch_capture_required | For kits/reagents        |
| active_flag            | Active                   |

---

# 14. Governance model

Lab catalogue governance should be owned by the lab in-charge and clinical governance team.

## Rule lifecycle

```text
Draft test
    ↓
Configure sample, result template, reference range, billing, branch availability
    ↓
Map to LOINC/payer/reporting group where applicable
    ↓
Lab in-charge review
    ↓
Billing/claims review
    ↓
Activate
```

## Required activation checklist

| Checklist item                        |
| ------------------------------------- |
| Test name and code                    |
| Specimen                              |
| Result type/template                  |
| Reference range or value set          |
| Billing service                       |
| Branch availability                   |
| Verification requirement              |
| In-house/send-out status              |
| External lab mapping if send-out      |
| Payer tariff mapping where applicable |
| LOINC mapping status                  |
| Inventory consumables if stock-linked |
| Lab in-charge approval                |

---

# 15. Architecture principle

Replace:

```text
Test catalogue: CBC, malaria, urinalysis, glucose, pregnancy, etc.
```

With:

```text
The lab catalogue must be an operational internal catalogue aligned to Kenya diagnostic scope, mapped to LOINC where possible, linked to billing/tariffs, inventory, result templates, reference ranges, external lab codes, reporting groups, and future FHIR ServiceRequest/Observation/DiagnosticReport exchange.
```

---

# 16. Sprint addition

Add a dedicated terminology sprint before Lab-lite implementation.

## New sprint: Lab Terminology and Test Catalogue Foundation

### Scope

| Workstream                    | Deliverable                                   |
| ----------------------------- | --------------------------------------------- |
| ADR-023                       | Lab terminology decision                      |
| Internal lab catalogue schema | `lab.lab_tests`                               |
| LOINC mapping schema          | `lab.lab_test_code_mappings`                  |
| Panel/component schema        | `lab.lab_test_components`                     |
| Reference range schema        | `lab.lab_reference_ranges`                    |
| Result value sets             | Positive/negative/semi-quantitative values    |
| Kenya KEDL alignment          | Essential diagnostics reference mapping       |
| External lab catalogue        | Send-out test mapping                         |
| Billing service mapping       | Lab test → service                            |
| Payer tariff mapping          | Lab service → tariff                          |
| Inventory consumable mapping  | Lab test → stock item                         |
| Test search UX                | Autocomplete, synonyms, favourites, frequency |
| Governance workflow           | Draft/review/approve/activate                 |
| Import tools                  | CSV import for lab catalogue and mappings     |

### Acceptance criteria

| Test                       | Expected result                                           |
| -------------------------- | --------------------------------------------------------- |
| Create CBC panel           | Components and result template configured                 |
| Search `FBC`               | CBC/FBC appears                                           |
| Search `RBS`               | Random blood sugar appears                                |
| Order send-out test        | External lab workflow triggered                           |
| Test lacks billing code    | Cannot activate                                           |
| Test lacks result template | Cannot activate                                           |
| LOINC mapping pending      | Test can operate but marked not interoperability-complete |
| Result entered             | Reference range and abnormal flag work                    |
| Lab claim generated        | Verified result attached                                  |
| Kit-linked test performed  | Consumable deducted if configured                         |

---

# 17. Final recommendation

For Module 6, implement:

```text
MVP:
    Internal lab test catalogue
    Kenya KEDL-aligned scope
    LOINC mapping field and mapping table
    Core in-house tests
    External send-out catalogue
    Result templates
    Reference ranges
    Value sets
    Billing/tariff links
    Inventory consumable links
    Lab search UX
    Governance workflow

Version 2:
    LOINC subset import
    KHIS/DHIS2 aggregate mappings
    External lab catalogue imports
    QC and kit/reagent lot governance

Version 3:
    FHIR terminology service
    Analyser/device code mappings
    External lab API/FHIR integration
    Full interoperability-grade LOINC governance
```

The important rule is:

**The lab module should run on an internal operational test catalogue, but every test should be capable of mapping to LOINC, payer tariffs, external lab codes, inventory consumables, Kenya reporting groups, and FHIR resources.**

[1]: https://www.regenstrief.org/real-world-solutions/loinc/?utm_source=chatgpt.com "LOINC Data Standards - Regenstrief Institute"
[2]: https://prescribingcompanion.com/media/1729/kenya-essential-diagnostics-list-2023.pdf?utm_source=chatgpt.com "Published by the Ministry of Health Kenya 2023 - 2023"
[3]: https://fhir.hl7.org/fhir/servicerequest.html?utm_source=chatgpt.com "ServiceRequest - FHIR v5.0.0 - fhir.hl7.org"
[4]: https://elearning.health.go.ke/course/index.php?categoryid=5&utm_source=chatgpt.com "KHIS/DHIS2 Aggregate - Ministry of Health"
