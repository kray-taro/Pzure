You are right. **Module 5 has a diagnosis-terminology architecture gap.** “ICD-10-ready” is not enough. We must decide the exact code system, import method, search UX, indexing, ranking, favourites, governance, claims mapping, and update process.

I would close this as:

```text
ADR-022: Diagnosis Coding Terminology, ICD-10 Import, Search and Governance Strategy
```

---

# 1. Architecture decision

For Kenya, I recommend:

```text
MVP / Version 1:
    WHO ICD-10 Version 2019 as the canonical diagnosis code set
    Full code set loaded
    Kenya/common outpatient diagnosis favourites layered on top
    Frequency-ranked autocomplete
    Recent and clinician favourites
    Synonyms/local terms table

Version 2:
    Add claims/payer-specific diagnosis rule mapping
    Add clinical templates tied to common diagnoses
    Add KHIS/DHIS2-style aggregate reporting groupings

Version 3:
    Add ICD-11 readiness and FHIR terminology services
```

Do **not** use ICD-10-CM as the canonical Kenyan diagnosis code system unless a payer specifically demands it. ICD-10-CM is the United States clinical modification; CDC describes ICD-10-CM as the U.S. morbidity classification used for diagnoses and reasons for visits in healthcare settings. WHO ICD-10 is the international base classification and is the safer canonical choice for Kenya unless local payer rules say otherwise. ([ICD-11][1])

---

# 2. Full ICD-10 vs ICD-10-CM vs short list

## Recommended decision

| Option                          | Decision                             | Reason                                                                               |
| ------------------------------- | ------------------------------------ | ------------------------------------------------------------------------------------ |
| **WHO ICD-10 full set**         | **Use as canonical MVP code system** | International base ICD-10; best fit for Kenya-first implementation                   |
| **ICD-10-CM full set**          | Do not use as canonical              | U.S.-specific clinical modification; can be mapped later if a private payer requires |
| **WHO ICD-10 short list only**  | Do not use alone                     | Too limited for claims, referrals, reporting, audits                                 |
| **Common diagnosis favourites** | Use as UX layer                      | Makes clinician workflow fast without losing full-code coverage                      |

So the actual design is:

```text
Store full WHO ICD-10
Expose fast common-diagnosis UX
Allow full-code search when needed
Track frequency, favourites, recent diagnoses
```

---

# 3. Why full ICD-10 should be loaded

Even if 90% of clinic use is common outpatient diagnoses, the system still needs the full set because:

| Reason                  | Example                                                                    |
| ----------------------- | -------------------------------------------------------------------------- |
| Claims                  | Payer may require a specific ICD-10 code                                   |
| Referrals               | Higher facility may need precise diagnosis                                 |
| Reporting               | Aggregates require stable standard codes                                   |
| Chronic care            | Diabetes, hypertension, asthma, HIV/TB, CKD need structured classification |
| Audit                   | Free-text-only diagnoses are weak evidence                                 |
| Future interoperability | FHIR Condition needs standard coding                                       |
| Avoid rework            | Adding full codes later causes mapping pain                                |

Clinician UX should hide the complexity, but the database should contain the full code set.

---

# 4. Code system choice

## Canonical diagnosis system

```text
Code system: WHO ICD-10
Version: 2019
Canonical source: WHO ICD-10 Browser / downloadable ICD-10 release where licensed/available
```

WHO’s ICD-10 browser identifies the classification as the International Statistical Classification of Diseases and Related Health Problems, 10th Revision, Version 2019, and supports browsing by hierarchy and search. ([ICD-11][1])

## Secondary mappings

| Mapping                        | Use                                                       |
| ------------------------------ | --------------------------------------------------------- |
| ICD-10-CM                      | Only if a private insurer, partner, or export requires it |
| Local common diagnosis terms   | Clinician search and favourites                           |
| KHIS/DHIS2 aggregate group     | Reporting                                                 |
| Chronic-care registry category | Hypertension, diabetes, asthma, etc.                      |
| Claims diagnosis group         | Payer validation                                          |
| FHIR coding system URI         | Interoperability                                          |

HL7 notes that ICD is a family of code systems maintained by WHO, and countries may publish their own variants; this supports keeping WHO ICD-10 canonical while allowing variant mappings when necessary. ([HL7 Terminology][2])

---

# 5. Import format

## Recommended import pipeline

```text
ICD source file
    ↓
Raw staging table
    ↓
Validation and normalization
    ↓
Canonical diagnosis table
    ↓
Search index table
    ↓
Common favourites and synonyms layer
    ↓
Version activation
```

## Import formats to support

| Format              | Purpose                                             |
| ------------------- | --------------------------------------------------- |
| CSV                 | Simple controlled import                            |
| XML                 | Better hierarchy preservation if source provides it |
| JSON                | Internal normalized import/export                   |
| SQL seed            | Deployment seeding                                  |
| Manual admin import | Future updates                                      |

ICD-10-CM files are commonly available from CDC in PDF and XML formats, but that is for the U.S. modification. For WHO ICD-10, the project should confirm licensing and approved downloadable format before import. ([CDC][3])

---

# 6. Data model additions

Add a terminology schema:

```text
terminology.*
```

## `terminology.code_systems`

| Field           | Purpose                               |
| --------------- | ------------------------------------- |
| id              | Internal ID                           |
| code_system_key | WHO_ICD10, ICD10_CM, LOCAL_DIAGNOSIS  |
| name            | Display name                          |
| version         | 2019, FY2026, etc.                    |
| publisher       | WHO, CDC, local                       |
| canonical_uri   | FHIR/terminology URI where applicable |
| licence_notes   | Usage/licence notes                   |
| active_flag     | Active/inactive                       |
| imported_at     | Import timestamp                      |
| imported_by     | User/system                           |

---

## `terminology.diagnosis_codes`

| Field           | Purpose                                |
| --------------- | -------------------------------------- |
| id              | Internal ID                            |
| code_system_id  | Link to code system                    |
| code            | ICD-10 code                            |
| title           | Official title                         |
| short_title     | Short display                          |
| description     | Longer text if available               |
| chapter_code    | ICD chapter                            |
| chapter_title   | Chapter name                           |
| block_code      | ICD block                              |
| parent_code     | Parent hierarchy                       |
| code_level      | Chapter/block/category/subcategory     |
| billable_flag   | Whether selectable for diagnosis/claim |
| selectable_flag | Whether clinician can select it        |
| active_flag     | Active/inactive                                   |
| effective_from  | Version date                                      |
| effective_to    | Retirement date                                   |
| created_at      | Import timestamp                                  |

---

## `terminology.diagnosis_synonyms`

| Field             | Purpose                                            |
| ----------------- | -------------------------------------------------- |
| id                | Internal ID                                        |
| diagnosis_code_id | Link to ICD code                                   |
| synonym           | Common/local term                                  |
| language          | English, Kiswahili, local language                 |
| synonym_type      | Common, abbreviation, lay term, clinical shorthand |
| approved_by       | Governance                                         |
| active_flag       | Active/inactive                                    |

Examples:

| Synonym             | Maps to                                                         |
| ------------------- | --------------------------------------------------------------- |
| High blood pressure | Essential hypertension                                          |
| BP                  | Essential hypertension                                          |
| Sugar disease       | Diabetes mellitus                                               |
| UTI                 | Urinary tract infection                                         |
| Flu                 | Acute upper respiratory infection / influenza depending context |
| Malaria             | Malaria category/code                                           |
| Ulcers              | Gastritis/peptic ulcer depending clinician choice               |

---

## `terminology.diagnosis_favourites`

| Field             | Purpose                        |
| ----------------- | ------------------------------ |
| id                | Internal ID                    |
| user_id           | Clinician                      |
| branch_id         | Optional branch scope          |
| diagnosis_code_id | ICD code                       |
| favourite_type    | Personal, branch, organisation |
| display_order     | Ranking                        |
| created_at        | Timestamp                      |

---

## `terminology.diagnosis_usage_stats`

| Field                | Purpose          |
| -------------------- | ---------------- |
| id                   | Internal ID      |
| diagnosis_code_id    | ICD code         |
| branch_id            | Branch           |
| clinician_id         | Optional         |
| use_count            | Frequency        |
| last_used_at         | Last use         |
| rolling_30_day_count | Recent frequency |
| rolling_90_day_count | Recent frequency |

---

## `terminology.diagnosis_mappings`

| Field                 | Purpose                                 |
| --------------------- | --------------------------------------- |
| id                    | Internal ID                             |
| source_code_system_id | WHO ICD-10                              |
| source_code           | ICD-10 code                             |
| target_code_system_id | ICD-10-CM, local claim code, KHIS group |
| target_code           | Mapped code                             |
| mapping_type          | exact, broader, narrower, approximate   |
| confidence            | high, medium, low                       |
| approved_by           | Governance                              |
| active_flag           | Active/inactive                         |

---

## `emr.diagnoses`

This is the actual patient diagnosis table.

| Field               | Purpose                                    |
| ------------------- | ------------------------------------------ |
| id                  | Diagnosis record                           |
| visit_id            | Visit                                      |
| patient_id          | Patient                                    |
| diagnosis_code_id   | Link to terminology.diagnosis_codes        |
| diagnosis_text      | Clinician-facing text                      |
| icd10_code          | Denormalized for reporting/claim stability |
| code_system_version | Version used                               |
| diagnosis_type      | provisional, final, differential           |
| primary_flag        | Primary diagnosis                          |
| chronic_flag        | Chronic diagnosis marker                   |
| onset_date          | Optional                                   |
| severity            | Optional                                   |
| status              | active, resolved, recurrent                |
| clinician_id        | User                                       |
| created_at          | Timestamp                                  |
| updated_at          | Timestamp                                  |

Important: store both the foreign key and the denormalized code/version at time of use. This protects old claims and reports when the terminology version changes.

---

# 7. Search UX design

The clinician should not be forced to browse 70,000 codes manually.

## Search design

The diagnosis picker should have four layers:

```text
1. Favourites
2. Recent diagnoses
3. Facility/branch common diagnoses
4. Full ICD-10 search
```

## Search box behaviour

The user should be able to type:

```text
malaria
uti
bp
hypertension
diabetes
fever
pregnancy
asthma
ulcer
back pain
J45
I10
E11
```

The search should return:

| Result type         | Example                         |
| ------------------- | ------------------------------- |
| Exact code match    | `I10 - Essential hypertension`  |
| Exact text match    | `Malaria, unspecified`          |
| Synonym match       | `BP → Essential hypertension`   |
| Abbreviation match  | `UTI → Urinary tract infection` |
| Recent match        | Recently used by this clinician |
| Branch common match | Common in this branch           |
| Fuzzy match         | “diabetis” → diabetes           |
| Chapter/block match | Respiratory infections          |

---

## Ranking formula

A practical ranking model:

```text
score =
    exact_code_match * 100
  + exact_title_match * 80
  + synonym_match * 70
  + prefix_match * 50
  + fuzzy_match * 30
  + clinician_favourite * 40
  + branch_frequency_score * 30
  + clinician_recent_score * 25
  + organisation_frequency_score * 15
  - inactive_penalty
  - non_selectable_penalty
```

## Ranking principles

| Rule                        | Behaviour                                       |
| --------------------------- | ----------------------------------------------- |
| Exact code wins             | Typing `I10` should show I10 first              |
| Favourites rank high        | Clinician’s own common diagnoses appear early   |
| Branch frequency matters    | Malaria-heavy branch sees malaria high          |
| Recent matters              | Diagnoses used this week rank higher            |
| Non-selectable categories   | Show but prevent final selection if not allowed |
| Misspellings tolerated      | Fuzzy search                                    |
| Abbreviations supported     | UTI, URTI, BP, DM, HTN, ANC                     |
| Claims-ready status visible | Show if code is acceptable for claim            |

---

# 8. Diagnosis picker UI

## Recommended UI

```text
Diagnosis search box
    ↓
Tabs:
    - Common
    - Recent
    - Favourites
    - Full ICD-10
    - Chronic
    - Claims suggestions

Search result row:
    Code
    Diagnosis name
    Chapter/category
    Common/local synonym
    Selectable indicator
    Star/favourite button
```

Example row:

```text
I10 | Essential hypertension
Chapter IX: Diseases of the circulatory system
Common: High blood pressure, BP
[Primary] [Add as secondary] [★]
```

## Selection workflow

When selected:

```text
Select diagnosis
    ↓
Set primary/secondary
    ↓
Set provisional/final
    ↓
Set chronic flag if applicable
    ↓
Attach to visit
    ↓
Attach to orders/claims
```

## Common outpatient favourites

For Kenyan outpatient clinics, seed a practical common list:

| Category       | Examples                                              |
| -------------- | ----------------------------------------------------- |
| Infectious     | Malaria, URTI, gastroenteritis, UTI                   |
| Chronic        | Hypertension, diabetes, asthma                        |
| Respiratory    | Pneumonia, bronchitis, allergic rhinitis              |
| GI             | Gastritis, peptic ulcer disease, diarrhoea            |
| Skin           | Dermatitis, fungal infection, cellulitis              |
| Injury         | Wound, sprain, burn                                   |
| Maternal/child | Pregnancy-related visits, immunisation encounter      |
| Eye/ENT        | Otitis media, conjunctivitis, tonsillitis             |
| Genitourinary  | UTI, vaginal discharge, STI syndrome where configured |
| Administrative | Medical examination, follow-up visit                  |

These must be mapped to the correct ICD-10 codes during clinical governance, not guessed casually by developers.

---

# 9. Claims integration

Diagnosis codes must support claims validation.

## Claim-readiness rules

| Rule                            | Behaviour                                               |
| ------------------------------- | ------------------------------------------------------- |
| Claim visit                     | Primary diagnosis required                              |
| Payer requires ICD-10           | ICD-10 code required                                    |
| Diagnosis free-text only        | Claim not ready                                         |
| Diagnosis not selectable        | Claim not ready                                         |
| Service-diagnosis mismatch      | Warning                                                 |
| Lab/procedure without diagnosis | Claim warning/block depending payer                     |
| Chronic-care claim              | Chronic diagnosis/status required                       |
| Pre-authorisation               | Diagnosis required before submission                    |
| Denial correction               | Diagnosis correction creates claim resubmission version |

## Diagnosis-to-claim linkage

Each claim line should optionally link to diagnosis:

```text
claims.claim_lines.diagnosis_id → emr.diagnoses.id
```

This allows:

| Use                                      |
| ---------------------------------------- |
| Diagnosis-based medical necessity checks |
| Claim validation                         |
| Denial management                        |
| Payer review                             |
| Analytics                                |
| Audit                                    |

---

# 10. Reporting integration

Diagnosis coding feeds Module 8.

## Reports enabled

| Report                       | Use                       |
| ---------------------------- | ------------------------- |
| Diagnosis/service report     | Clinic manager            |
| Top diagnoses                | Operational planning      |
| Diagnosis by branch          | Branch comparison         |
| Diagnosis by age/sex         | Public health/management  |
| Diagnosis by clinician       | Clinical workload         |
| Diagnosis by payer           | Claims analytics          |
| Chronic-care registry        | Continuity                |
| Lab orders by diagnosis      | Utilization               |
| Prescription by diagnosis    | Pharmacy analytics        |
| Referral by diagnosis        | Service capability        |
| Claim rejection by diagnosis | Revenue cycle improvement |

## Aggregation groups

Add a table:

### `terminology.diagnosis_reporting_groups`

| Field               | Purpose                                               |
| ------------------- | ----------------------------------------------------- |
| id                  | Group ID                                              |
| group_name          | Fever/malaria, respiratory, chronic, maternal, injury |
| reporting_framework | Internal, KHIS, payer, custom                         |
| active_flag         | Active/inactive                                       |

### `terminology.diagnosis_reporting_group_members`

| Field             | Purpose                    |
| ----------------- | -------------------------- |
| group_id          | Reporting group            |
| diagnosis_code_id | ICD code                   |
| mapping_type      | exact/chapter/block/custom |

---

# 11. FHIR and interoperability readiness

For future interoperability, diagnosis should map to FHIR Condition.

## FHIR mapping

| Local field       | FHIR Condition field                       |
| ----------------- | ------------------------------------------ |
| patient_id        | `Condition.subject`                        |
| visit_id          | `Condition.encounter`                      |
| diagnosis_code_id | `Condition.code.coding`                    |
| diagnosis_text    | `Condition.code.text`                      |
| diagnosis_type    | `Condition.verificationStatus` / extension |
| primary_flag      | Encounter diagnosis rank/use               |
| onset_date        | `Condition.onsetDateTime`                  |
| status            | `Condition.clinicalStatus`                 |
| clinician_id      | `Condition.recorder`                       |
| created_at        | `Condition.recordedDate`                   |

Use WHO ICD-10 canonical coding system where applicable, and retain mapping flexibility for ICD-10-CM or ICD-11 later.

---

# 12. Import and update governance

## Import lifecycle

```text
Acquire official code set
    ↓
Load into staging
    ↓
Validate code count, hierarchy, duplicates
    ↓
Run selectable/billable rules
    ↓
Build search index
    ↓
Clinical governance review
    ↓
Activate version
    ↓
Freeze old version for historical claims
```

## Update rules

| Rule                        | Behaviour                                       |
| --------------------------- | ----------------------------------------------- |
| New ICD version imported    | Do not overwrite old diagnosis records          |
| Code retired                | Keep old records, stop new selection            |
| Code title changes          | New version effective from activation date      |
| Mapping changes             | Version mappings                                |
| Claim already submitted     | Preserve old code/version                       |
| Favourite uses retired code | Prompt replacement                              |
| Synonym changed             | Keep history if used in searches/selection logs |

---

# 13. Search implementation options

## SQL Server full-text search

For MVP, SQL Server full-text search can work well.

| Component                | Use                                    |
| ------------------------ | -------------------------------------- |
| Full-text index          | Diagnosis title, short title, synonyms |
| Normalized search column | Lowercase, stripped punctuation        |
| Usage stats table        | Ranking                                |
| Favourites table         | Personal ranking                       |
| Recent diagnosis cache   | Fast clinician UX                      |
| Frontend debounce        | 250–400 ms                             |
| Result limit             | 20–50 results                          |
| Async preload            | Common/favourite/recent codes          |

## Optional later search engine

If search grows more complex, add:

| Tool                     | Use                                      |
| ------------------------ | ---------------------------------------- |
| Azure AI Search          | Better ranking, synonyms, typo tolerance |
| Elasticsearch/OpenSearch | Advanced full-text and analytics         |
| Redis search/cache       | Very fast common-code search             |

For 10 branches, SQL Server full-text plus caching is enough for MVP.

---

# 14. Frontend UX details

## Autocomplete behaviour

| UX requirement                | Behaviour                       |
| ----------------------------- | ------------------------------- |
| Debounced search              | Do not query on every keystroke |
| Keyboard friendly             | Arrow keys, Enter to select     |
| Mouse/touch friendly          | Tablet-compatible               |
| Shows code and name           | Avoid selecting wrong diagnosis |
| Shows favourites first        | Faster for common diagnoses     |
| Allows star/favourite         | Personalise                     |
| Recent diagnoses              | Clinician and branch recent     |
| Allows secondary diagnosis    | Multi-diagnosis visits          |
| Requires primary diagnosis    | For claim-ready visit           |
| Allows provisional diagnosis  | Before lab results              |
| Allows update/final diagnosis | With addendum/audit             |
| Warns free-text-only          | Not claim-ready                 |

---

# 15. Data quality controls

## Required controls

| Control                        | Behaviour                                  |
| ------------------------------ | ------------------------------------------ |
| Free-text diagnosis allowed?   | Yes for clinical note, but not claim-ready |
| ICD code required?             | Required for claims and reports            |
| One primary diagnosis          | Required when multiple diagnoses           |
| Secondary diagnoses allowed    | Yes                                        |
| Chronic diagnosis prompt       | For diabetes, hypertension, asthma, etc.   |
| Duplicate diagnosis warning    | Same visit, same code                      |
| Inactive code                  | Not selectable                             |
| Parent category selection      | Block if not billable/selectable           |
| Diagnosis change after signing | Addendum/correction workflow               |
| Diagnosis deletion             | Soft delete with audit, not hard delete    |

---

# 16. Security and access

Diagnosis data is health data, so access must be controlled.

| User           | Access                                                                    |
| -------------- | ------------------------------------------------------------------------- |
| Reception      | Usually no full diagnosis access unless required                          |
| Clinician      | Full diagnosis access                                                     |
| Pharmacist     | Relevant diagnosis for prescription safety and claim where needed         |
| Lab            | Limited diagnosis/clinical indication for ordered tests                   |
| Claims officer | Claim-relevant diagnosis                                                  |
| Accountant     | Diagnosis usually masked                                                  |
| Owner/manager  | Aggregated diagnosis reports, patient identifiers masked unless permitted |
| DPO/auditor    | Access logs and controlled investigation access                           |

---

# 17. Performance estimate

## ICD-10 data size

Full WHO ICD-10 is manageable for SQL Server. Even ICD-10-CM with tens of thousands of codes is not large compared to transactional tables. The performance risk is not storage; it is search UX and careless queries.

## Performance design

| Area                     | Requirement                     |
| ------------------------ | ------------------------------- |
| Initial common list load | < 1 second                      |
| Search result response   | < 300–500 ms target             |
| Result count             | Limit to 20–50                  |
| Full-text index          | Required                        |
| Synonym index            | Required                        |
| Usage ranking table      | Required                        |
| Caching                  | Common/favourites/recent cached |
| Mobile/tablet            | Autocomplete must work smoothly |

---

# 18. Sprint addition

Add a dedicated terminology sprint before EMR diagnosis implementation.

## New sprint: Terminology and ICD-10 Foundation

Place before existing EMR diagnosis sprint.

### Scope

| Workstream            | Deliverable                         |
| --------------------- | ----------------------------------- |
| ADR-022               | ICD-10 code system decision         |
| ICD import pipeline   | Load full WHO ICD-10                |
| Code-system tables    | `terminology.*` schema              |
| Diagnosis code table  | Full code hierarchy                 |
| Search index          | Full-text and synonym search        |
| Common diagnosis list | Kenya outpatient favourites         |
| Synonym table         | Local/common terms                  |
| Favourites            | User/branch/organisation favourites |
| Recent diagnosis      | Usage tracking                      |
| Frequency ranking     | Ranking service                     |
| Diagnosis picker UI   | Autocomplete and selection          |
| Claim-readiness rules | ICD required for claim              |
| Reporting groups      | Top diagnosis/reporting aggregation |
| Governance            | Versioning and update workflow      |

### Acceptance criteria

| Test                            | Expected result                         |
| ------------------------------- | --------------------------------------- |
| Full WHO ICD-10 imported        | Codes searchable and versioned          |
| Search `I10`                    | Essential hypertension appears first    |
| Search `BP`                     | Hypertension appears via synonym        |
| Search `UTI`                    | Urinary diagnosis options appear        |
| Clinician favourites diagnosis  | It appears higher next time             |
| Recent diagnosis                | Appears in recent tab                   |
| Branch common diagnosis         | Appears in common tab                   |
| Inactive code                   | Not selectable                          |
| Parent non-selectable category  | Cannot be used as final claim diagnosis |
| Claim visit without ICD code    | Claim not ready                         |
| Diagnosis changed after signing | Audit/addendum workflow triggered       |
| Report top diagnoses            | Uses ICD codes and groups               |

---

# 19. Updated Module 5 principle

Replace:

```text
Diagnosis should be ICD-10-ready.
```

With:

```text
Diagnosis must be stored as structured, versioned terminology: full WHO ICD-10 code set loaded, clinician-friendly autocomplete, favourites, recents, synonyms, frequency ranking, claim-readiness validation, and reporting mappings.
```

---

# 20. Final recommendation

For this project:

```text
Use WHO ICD-10 full code set as canonical.
Do not use ICD-10-CM as canonical unless a payer requires it.
Do not use a short list as the database source.
Do use a short/common diagnosis list as the clinician UX layer.
Build autocomplete with:
    exact code match
    title match
    synonym match
    abbreviation match
    favourites
    recent use
    branch frequency
    organisation frequency.
Version the code set.
Preserve code/version on every diagnosis record.
Map to claims, reporting, chronic care, and future FHIR Condition.
```

The important rule is:

**Clinicians should experience diagnosis entry as a fast common-diagnosis search, but the system must store a full, versioned, standard ICD-10 diagnosis code behind the visit, claim, report, and referral.**
