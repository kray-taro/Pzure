# Module 5: Clinic EMR Module

This module is the **clinical record and continuity-of-care engine** of the system.

Modules 1–4 answer:

```text
Module 1: Is the clinic/facility and clinician licensed?
Module 2: Was the visit billed, paid, invoiced, and receipted?
Module 3: Was the prescription dispensed safely?
Module 4: Was medicine/consumable stock controlled?
Module 5: Was the patient clinically assessed, documented, treated, followed up, referred, and summarized properly?
```

For a small Kenyan clinic, the EMR must be **fast enough for a busy outpatient clinician**, but structured enough to support:

```text
registration → queue → triage → consultation → diagnosis → orders → results → prescription → billing → claims → referral/follow-up → visit summary
```

Kenya’s Digital Health Act points toward integrated digital health systems with a national health data dictionary, client registry, facility registry, health worker registry, interoperability layer, shared health records, health management information systems, and finance/insurance services. That means the EMR should be simple for today’s clinic but designed for future interoperability. ([Kenya Law][1])

---

# 1. Purpose of the module

The Clinic EMR Module should:

| Purpose                  | Practical meaning                                                                                      |
| ------------------------ | ------------------------------------------------------------------------------------------------------ |
| Register patients        | Capture identity, demographics, contacts, next of kin                                                  |
| Manage patient flow      | Move patient from reception to triage to clinician to lab/pharmacy/billing                             |
| Record clinical care     | Complaint, history, exam, diagnosis, plan, orders, prescription                                        |
| Support safety           | Allergies, vitals, pregnancy, chronic conditions, medication history                                   |
| Support claims           | Structured diagnosis, services, orders, results, clinician identity, visit evidence                    |
| Support continuity       | Previous visits, chronic care, refills, referrals, visit summaries                                     |
| Support reporting        | Clinic activity, diagnoses, services, outcomes, chronic care, immunisation                             |
| Support referrals        | Generate referral notes and track receiving facility                                                   |
| Support privacy          | Role-based access, audit logs, consent, health-data protection                                         |
| Support interoperability | FHIR-ready patient, encounter, observation, diagnosis, medication, service request, document reference |

---

# 2. Kenya-specific design basis

## A. Facility licensing and professional accountability

A clinic EMR should not allow clinical work to run as though licensing does not matter. KMPDC’s health facility registration process includes county inspection, online registration, prescribed fees, committee approval, and issuance of a registration certificate. ([KMPDC][2])

Software implication:

| Requirement                | EMR behaviour                                                                                       |
| -------------------------- | --------------------------------------------------------------------------------------------------- |
| Active facility licence    | Required before enabling live clinical consultations                                                |
| Active clinician licence   | Required before signing clinical notes, prescriptions, certificates, referrals, and claim documents |
| Approved facility services | Facility should not bill/claim services outside its approved scope                                  |
| Facility identity          | Facility code, licence number, KMPDC/KMHFL mapping where available                                  |
| Clinical lead              | Link signed clinical records to responsible professional                                            |

---

## B. Health data and privacy

Kenya’s Data Protection Act defines health data as data related to a person’s physical or mental health, including data collected during registration for, or provision of, health services. It also classifies health status as sensitive personal data. ([Kenya Law][3])

Software implication:

| Requirement                          | EMR behaviour                                                    |
| ------------------------------------ | ---------------------------------------------------------------- |
| Patient data is sensitive            | Encrypt, restrict, audit                                         |
| Staff access must be role-based      | Reception should not see everything a clinician sees             |
| Consent must be captured             | Especially for SMS/WhatsApp, sharing, marketing, referrals       |
| Minor records need stricter handling | Guardian, consent, custody/access controls                       |
| Every access should be logged        | Who viewed, edited, printed, exported                            |
| Data export must be controlled       | Patient summaries, claim packs, referrals, reports               |
| DPO/data protection workflow         | Especially for clinics processing sensitive health data at scale |

---

## C. SHA/private insurance and claims

SHA regulations require contracted providers/facilities to maintain adequate systems for collecting, processing, maintaining, storing, retrieving, and distributing beneficiary records, and to retain beneficiary records in a readily accessible format. SHA also processes pre-authorizations and claims through a Centralized Digital Platform. ([Kenya Law][4])

Software implication:

| Claims requirement                   | EMR requirement                                                      |
| ------------------------------------ | -------------------------------------------------------------------- |
| Claims need clinical evidence        | Diagnosis, notes, orders, results, prescriptions, service timestamps |
| Services must be medically necessary | Link billed services to clinical indication                          |
| Claims may be returned for errors    | Structured fields reduce rejections                                  |
| Referrals matter                     | Referral source and destination should be captured                   |
| Benefit limits matter                | EMR should support payer rules through claims module                 |
| Fraud prevention                     | No billing for services not documented or not provided               |

---

## D. Diagnosis coding

The EMR should be **ICD-10-ready**. WHO’s ICD-10 browser is the International Statistical Classification of Diseases and Related Health Problems, 10th Revision, and supports browsing/searching the classification. ([ICD-11][5])

Software implication:

| Requirement                 | EMR behaviour                                                                               |
| --------------------------- | ------------------------------------------------------------------------------------------- |
| Diagnosis text              | Clinician-friendly free-text diagnosis                                                      |
| ICD-10 code                 | Structured code for claims/reporting                                                        |
| Provisional/final diagnosis | Distinguish working diagnosis from confirmed diagnosis                                      |
| Primary/secondary diagnosis | Claims and clinical clarity                                                                 |
| Common diagnosis shortcuts  | Malaria, URTI, gastroenteritis, hypertension, diabetes, asthma, UTI, ANC-related conditions |

---

## E. Public health reporting readiness

Kenya’s Ministry of Health lists KHIS as a key national portal, and the MOH Virtual Academy describes KHIS Aggregate as powered by DHIS2 for data entry, reporting, and visualization. ([Ministry of Health][6]) ([elearning.health.go.ke][7])

Software implication:

| Requirement        | EMR behaviour                                                                      |
| ------------------ | ---------------------------------------------------------------------------------- |
| Aggregate reports  | OPD visits, diagnoses, maternal/child health, immunisation, lab statistics         |
| Program flags      | HIV/TB referral, chronic disease, immunisation, antenatal/postnatal where relevant |
| Export-ready data  | CSV/API/manual summary for KHIS/DHIS2-style reporting                              |
| Avoid double entry | Facility reports should be generated from clinical records where possible          |

---

# 3. Core users

| User                            | Main actions                                                                         |
| ------------------------------- | ------------------------------------------------------------------------------------ |
| Receptionist                    | Register patient, book appointment, check queue, start visit, capture payment status |
| Triage nurse/clinical assistant | Capture vitals, reason for visit, allergies, pregnancy flag                          |
| Clinician                       | Document consultation, diagnosis, orders, prescription, referral, certificates       |
| Nurse                           | Immunisation, procedures, follow-up, chronic-care review                             |
| Lab user                        | Receive orders, enter results, attach reports                                        |
| Pharmacist                      | Receive prescription from EMR and dispense through Module 3                          |
| Billing officer                 | Bill consultation, lab, procedure, drugs, insurer/SHA split                          |
| Claims officer                  | Generate claim-ready records                                                         |
| Branch/facility manager         | Monitor visits, workload, reports, pending tasks                                     |
| Medical director/clinical lead  | Review clinical quality, sign off sensitive records                                  |
| Auditor/compliance officer      | Review clinical documentation, access logs, claims evidence                          |

---

# 4. Relationship with modules 1–4

## Module 1: Organisation and Licensing

| Data from Module 1          | EMR use                                             |
| --------------------------- | --------------------------------------------------- |
| Facility licence            | Enables clinical operations                         |
| Approved services           | Controls services/procedures available              |
| Clinician licence           | Controls who can sign notes, orders, certificates   |
| Branch/facility profile     | Appears on visit summaries, referrals, certificates |
| SHA/private contracts       | Enables claims workflow                             |
| ODPC/data protection record | Supports privacy compliance                         |

## Module 2: POS, Billing and Payments

| Billing event      | EMR link                                           |
| ------------------ | -------------------------------------------------- |
| Consultation bill  | Linked to visit                                    |
| Lab/procedure bill | Linked to clinical order                           |
| Prescription bill  | Linked to prescription                             |
| Insurer/SHA claim  | Linked to diagnosis and service evidence           |
| Receipt/invoice    | Linked to visit account                            |
| Credit note/refund | Linked to cancelled service/order where applicable |

## Module 3: Pharmacy Dispensing

| Pharmacy event         | EMR link                           |
| ---------------------- | ---------------------------------- |
| Prescription created   | Sent to pharmacy queue             |
| Prescription dispensed | Medication history updated         |
| Partial dispense       | EMR shows actual quantity supplied |
| Substitution           | EMR shows prescribed vs dispensed  |
| Refill                 | Chronic-care plan updated          |
| ADR report             | Patient safety record updated      |

## Module 4: Inventory

| Inventory event            | EMR link                                     |
| -------------------------- | -------------------------------------------- |
| Lab reagent/consumable use | Stock consumption                            |
| Procedure consumables      | Dressing, syringe, vaccine, nebulization kit |
| Vaccine stock              | Immunisation stock usage                     |
| Medicine issue             | Through pharmacy module                      |
| Cold-chain vaccine         | Vaccine batch/expiry traceability            |

---

# 5. Core clinical transaction types

| Transaction               | Description                                                  |
| ------------------------- | ------------------------------------------------------------ |
| New outpatient visit      | First-time patient consultation                              |
| Return outpatient visit   | Repeat/review visit                                          |
| Nurse/triage-only visit   | Vitals, screening, minor service                             |
| Chronic-care visit        | Diabetes, hypertension, asthma, epilepsy follow-up           |
| Lab-only visit            | Walk-in or clinician-ordered test                            |
| Procedure visit           | Dressing, injection, nebulization, wound care                |
| Immunisation visit        | Vaccine administration record                                |
| Referral visit            | Patient referred in or out                                   |
| Emergency stabilization   | Initial urgent care before referral                          |
| Teleconsultation          | If enabled and lawful                                        |
| Corporate/insurance visit | Employer/private insurer/SHA workflow                        |
| Certificate visit         | Sick-off, school/work note, medical certificate where lawful |

---

# 6. Feature-by-feature design

## A. Registration

Registration should be fast but strong enough to identify the patient correctly.

### Registration fields

| Field                                  |           Required? | Notes                                   |
| -------------------------------------- | ------------------: | --------------------------------------- |
| Patient number                         |                 Yes | Auto-generated                          |
| Full name                              |                 Yes | As per ID/guardian                      |
| Sex                                    |                 Yes | Male/female/other as configured         |
| Date of birth                          |         Recommended | If unknown, capture estimated age       |
| Age                                    |                 Yes | Auto from DOB or manual estimate        |
| Phone number                           |         Recommended | For follow-up, results, reminders       |
| Alternative phone                      |            Optional | Useful for chronic care                 |
| National ID/passport/birth certificate |         Recommended | Optional for minor/urgent cases         |
| SHA/member number                      |            Optional | If claims enabled                       |
| Private insurer details                |            Optional | Payer workflow                          |
| Next of kin                            |         Recommended | Emergency/contact                       |
| Next of kin phone                      |         Recommended |                                         |
| Guardian/caregiver                     | Required for minors |                                         |
| County/sub-county/ward                 |         Recommended | Reporting/public health                 |
| Physical address                       |            Optional |                                         |
| Occupation                             |            Optional | Clinical/social relevance               |
| Marital status                         |            Optional |                                         |
| Allergies                              |         Recommended | Safety                                  |
| Chronic conditions                     |         Recommended | Diabetes, hypertension, asthma, etc.    |
| Current medications                    |            Optional | Safety                                  |
| Consent preferences                    |                 Yes | SMS, WhatsApp, sharing, reminders       |
| Patient category                       |                 Yes | Walk-in, corporate, SHA, private, staff |
| Registration source                    |                 Yes | Walk-in, referral, outreach, online     |
| Status                                 |                 Yes | Active, deceased, duplicate, inactive   |

### Registration rules

| Rule                           | System behaviour                                               |
| ------------------------------ | -------------------------------------------------------------- |
| Duplicate phone/name/DOB match | Warn possible duplicate                                        |
| Minor patient                  | Require guardian/caregiver where possible                      |
| Emergency patient              | Allow minimal registration, complete later                     |
| Missing phone                  | Allow visit but disable SMS/WhatsApp                           |
| ID missing                     | Allow care, but flag for later completion if claims require it |
| SHA/private insurance selected | Require payer-specific membership fields                       |
| Consent not given              | Do not send non-essential messages                             |
| Duplicate patient confirmed    | Merge workflow, never delete clinical history silently         |

### Patient identifiers

The system should support multiple identifiers:

| Identifier                    | Example            |
| ----------------------------- | ------------------ |
| Internal patient number       | `PT-000123`        |
| National ID                   | Kenyan ID          |
| Passport                      | Foreign patient    |
| Birth certificate number      | Child              |
| SHA number                    | Claims             |
| Private insurer member number | Claims             |
| Corporate employee number     | Employer scheme    |
| Facility legacy number        | Migration          |
| National client registry ID   | Future integration |

---

## B. Appointment and queue

Small clinics need a queue more than a complex hospital scheduler. The system should support both walk-ins and booked visits.

### Appointment fields

| Field                 | Notes                                          |
| --------------------- | ---------------------------------------------- |
| Appointment number    | Auto                                           |
| Patient               | Link                                           |
| Appointment date/time |                                                |
| Visit reason          | Complaint/review/procedure/lab/immunisation    |
| Clinician/provider    | Optional                                       |
| Service type          | Consultation, review, ANC, chronic, etc.       |
| Payment/payer         | Cash, SHA, insurer, corporate                  |
| Status                | Booked, arrived, no-show, cancelled, completed |
| Reminder status       | SMS/WhatsApp if consent                        |
| Notes                 | Optional                                       |

### Queue stages

```text
Registered → Waiting payment/eligibility → Waiting triage → In triage → Waiting clinician → In consultation → Waiting lab/procedure → Waiting pharmacy → Waiting billing → Completed
```

### Queue fields

| Field                  |
| ---------------------- |
| Queue number           |
| Patient                |
| Visit type             |
| Priority               |
| Current station        |
| Assigned clinician     |
| Waiting time           |
| Payment status         |
| Triage status          |
| Lab status             |
| Pharmacy status        |
| Claim/insurance status |
| Alerts                 |

### Queue priority levels

| Priority           | Use                              |
| ------------------ | -------------------------------- |
| Routine            | Normal outpatient                |
| Review             | Follow-up                        |
| Child under 5      | Optional priority                |
| Elderly            | Optional priority                |
| Emergency          | Immediate attention              |
| Pregnant           | Priority depending clinic policy |
| Appointment        | Scheduled slot                   |
| Procedure/lab only | Direct to relevant station       |

### Queue rules

| Rule                               | System behaviour                                       |
| ---------------------------------- | ------------------------------------------------------ |
| Patient not registered             | Cannot enter queue except emergency quick registration |
| Clinician unavailable              | Reassign or hold                                       |
| Payment-before-consultation policy | Queue to cashier before consultation                   |
| Pay-after-consultation policy      | Allow clinician first                                  |
| Emergency                          | Bypass normal billing queue                            |
| Lab ordered                        | Patient moves to lab queue                             |
| Prescription created               | Patient moves to pharmacy queue                        |
| Visit completed                    | Lock visit except authorized addendum                  |

---

## C. Vitals

Vitals should be quick, structured, and trendable.

### Vitals fields

| Vital                 | Field notes                                  |
| --------------------- | -------------------------------------------- |
| Blood pressure        | Systolic/diastolic, position optional        |
| Pulse                 | Beats per minute                             |
| Temperature           | °C                                           |
| Weight                | kg                                           |
| Height                | cm                                           |
| BMI                   | Auto-calculated                              |
| SpO₂                  | Percentage                                   |
| Respiratory rate      | Recommended                                  |
| Random blood sugar    | Optional quick screen                        |
| Pain score            | Optional                                     |
| MUAC                  | Paediatric/nutrition clinics                 |
| Pregnancy status      | For women of reproductive age where relevant |
| Last menstrual period | Where relevant                               |
| Triage notes          | Short free text                              |

### Vitals rules

| Rule                         | System behaviour                                       |
| ---------------------------- | ------------------------------------------------------ |
| BP extreme                   | Alert clinician                                        |
| Fever                        | Flag high temperature                                  |
| Low SpO₂                     | Emergency warning                                      |
| Child visit                  | Show age-specific prompts                              |
| Pregnancy flag               | Show pregnancy-sensitive warnings                      |
| Chronic hypertension patient | Show BP trend                                          |
| Diabetes patient             | Show glucose trend                                     |
| Missing vitals               | Warn clinician; allow emergency/teleconsult exceptions |
| Weight missing for child     | Warn before paediatric prescription                    |

### Vitals display

Clinician should see:

```text
Today: BP 150/95, Pulse 88, Temp 37.2, Weight 82kg, SpO₂ 96%
Previous: BP 142/90, 138/88, 160/100
Trend: BP not controlled
```

---

## D. Clinical notes

The EMR should be structured but not painful. Use a simple SOAP-style layout.

```text
S - Subjective: complaint and history
O - Objective: examination and vitals
A - Assessment: diagnosis/impression
P - Plan: treatment, orders, advice, follow-up
```

### Clinical note fields

| Section                         | Fields                                            |
| ------------------------------- | ------------------------------------------------- |
| Chief complaint                 | Main reason for visit                             |
| History of presenting complaint | Free text/structured                              |
| Past medical history            | Conditions, surgeries, admissions                 |
| Drug history                    | Current medicines                                 |
| Allergy history                 | Allergies/reactions                               |
| Family/social history           | Optional                                          |
| Review of systems               | Optional checklist                                |
| Examination                     | General and system exam                           |
| Assessment                      | Clinical impression                               |
| Diagnosis                       | ICD-10-ready                                      |
| Plan                            | Treatment, investigations, prescription, referral |
| Follow-up                       | Review date/instructions                          |
| Counselling                     | Lifestyle, adherence, danger signs                |
| Clinician                       | Auto                                              |
| Signature/time                  | Auto                                              |
| Addendum                        | Late correction without overwriting original      |

### Note templates

Small clinics need templates for common visits:

| Template               | Use                                 |
| ---------------------- | ----------------------------------- |
| General outpatient     | Most visits                         |
| Paediatric visit       | Child complaints                    |
| ANC/PNC light template | Where facility offers maternal care |
| Chronic hypertension   | BP, meds, adherence                 |
| Diabetes               | Glucose, foot check, meds           |
| Asthma/COPD            | Symptoms, inhaler use               |
| Wound care/dressing    | Wound description and procedure     |
| UTI                    | Symptoms, urinalysis, treatment     |
| Malaria/fever          | Fever, RDT/lab, treatment           |
| Gastroenteritis        | Hydration, stool, danger signs      |
| Mental health screen   | Where appropriate                   |
| Immunisation visit     | Vaccine record                      |

### Clinical note rules

| Rule                           | System behaviour                                                                               |
| ------------------------------ | ---------------------------------------------------------------------------------------------- |
| Clinician licence inactive     | Cannot sign clinical note                                                                      |
| Unsigned note                  | Mark as draft, not claim-ready                                                                 |
| Addendum needed                | Create addendum; do not overwrite signed note                                                  |
| Diagnosis missing              | Warn before closing visit                                                                      |
| Prescription without diagnosis | Warn/require diagnosis depending policy                                                        |
| Referral without assessment    | Require reason and receiving facility                                                          |
| Claim visit                    | Diagnosis and signed note required                                                             |
| Sensitive note                 | Restrict access, especially mental health, HIV/TB, sexual/reproductive health where configured |

---

## E. Diagnosis

Diagnosis should be clinician-friendly first, claim/reporting-ready second.

### Diagnosis fields

| Field                   |                       Required? | Notes                            |
| ----------------------- | ------------------------------: | -------------------------------- |
| Diagnosis text          |                             Yes | Clinician-friendly               |
| ICD-10 code             | Recommended/required for claims |                                  |
| Diagnosis type          |                             Yes | Provisional, final, differential |
| Primary diagnosis       |                             Yes | One primary                      |
| Secondary diagnoses     |                        Optional | Multiple                         |
| Onset date              |                        Optional | Chronic care                     |
| Severity                |                        Optional | Mild/moderate/severe             |
| Status                  |                             Yes | Active, resolved, recurrent      |
| Linked visit            |                             Yes |                                  |
| Linked chronic registry |                      If chronic | Diabetes, hypertension, asthma   |
| Clinician               |                            Auto |                                  |
| Notes                   |                        Optional |                                  |

### Diagnosis rules

| Rule                            | System behaviour                                        |
| ------------------------------- | ------------------------------------------------------- |
| Multiple diagnoses              | Require one primary                                     |
| Claim visit                     | ICD-10 code required                                    |
| Chronic diagnosis               | Prompt chronic-care enrolment                           |
| HIV/TB diagnosis                | Use sensitive access controls and program/referral flag |
| Diagnosis changed after signing | Create correction/addendum                              |
| Diagnosis and service mismatch  | Warn claims officer                                     |
| Diagnosis not coded             | Allow clinical note but mark not claim-ready            |

### Common diagnosis favourites

The system should allow facility-specific shortcuts:

| Category       | Examples                                     |
| -------------- | -------------------------------------------- |
| Infectious     | Malaria, URTI, gastroenteritis, UTI          |
| Chronic        | Hypertension, diabetes, asthma               |
| Maternal/child | ANC visit, immunisation encounter, pneumonia |
| Injury         | Wound, sprain, burn                          |
| ENT/eye/skin   | Otitis media, conjunctivitis, dermatitis     |
| Mental health  | Anxiety, depression where appropriate        |
| Administrative | Medical exam, certificate visit              |

---

## F. Orders

Orders connect the clinician’s plan to lab, imaging, procedures, pharmacy, billing, and claims.

### Order types

| Order type    | Examples                                                  |
| ------------- | --------------------------------------------------------- |
| Lab           | Malaria RDT, CBC, urinalysis, pregnancy test, blood sugar |
| Imaging       | X-ray, ultrasound, external referral                      |
| Procedure     | Dressing, injection, nebulization, suturing               |
| Prescription  | Medicines to pharmacy                                     |
| Nursing order | Observation, wound care, injection                        |
| Referral      | Refer to hospital/specialist                              |
| Follow-up     | Review date                                               |
| Certificate   | Sick-off, school/work note where lawful                   |

### Order fields

| Field               | Notes                                                             |
| ------------------- | ----------------------------------------------------------------- |
| Order number        | Auto                                                              |
| Patient             | Link                                                              |
| Visit               | Link                                                              |
| Ordering clinician  | Auto                                                              |
| Order type          | Lab/imaging/procedure/prescription                                |
| Order item          | Test/procedure/medicine                                           |
| Clinical indication | Required for claims/high-risk orders                              |
| Priority            | Routine/urgent/stat                                               |
| Status              | Draft, ordered, billed, collected, resulted, completed, cancelled |
| Payment status      | From Module 2                                                     |
| Result status       | For lab/imaging                                                   |
| Assigned department | Lab, nursing, pharmacy                                            |
| Notes               | Optional                                                          |
| Created at          | Auto                                                              |

### Order rules

| Rule                         | System behaviour                                        |
| ---------------------------- | ------------------------------------------------------- |
| Clinician not licensed       | Cannot place signed clinical order                      |
| Order requires payment first | Route to billing before service                         |
| Order covered by insurer     | Route to claims/preauth where needed                    |
| Procedure needs consumables  | Trigger inventory consumption                           |
| Prescription item            | Route to pharmacy dispensing module                     |
| Lab order cancelled          | Update billing/credit note if already paid              |
| Result returned              | Notify clinician/patient where consent and policy allow |

---

## G. Results

Results should support numeric values, text, attachments, and result review.

### Result types

| Type            | Examples                                |
| --------------- | --------------------------------------- |
| Numeric         | Hb 12.5 g/dL, glucose 8.1 mmol/L        |
| Coded           | Positive/negative/reactive/non-reactive |
| Text            | Microscopy notes, imaging impression    |
| Attachment      | PDF, photo, scanned external result     |
| Panel           | CBC, urinalysis                         |
| External result | Referral lab report                     |

### Result fields

| Field              |                                       Required? |
| ------------------ | ----------------------------------------------: |
| Order ID           |                                             Yes |
| Patient            |                                            Auto |
| Visit              |                                            Auto |
| Test/procedure     |                                             Yes |
| Result value       |                                             Yes |
| Unit               |                                     For numeric |
| Reference range    |                                     Recommended |
| Abnormal flag      |                                     Auto/manual |
| Result notes       |                                        Optional |
| Attachment         |                                        Optional |
| Performed by       |                                       Lab/nurse |
| Verified by        |                If verification workflow enabled |
| Result date/time   |                                             Yes |
| Clinician reviewed |                                          Yes/no |
| Patient notified   |                                          Yes/no |
| Status             | Draft, resulted, verified, corrected, cancelled |

### Result rules

| Rule                         | System behaviour                                    |
| ---------------------------- | --------------------------------------------------- |
| Numeric result outside range | Flag abnormal                                       |
| Critical result              | Alert clinician                                     |
| Result correction            | Create corrected version; do not silently overwrite |
| External attachment          | Store source and upload user                        |
| Result not reviewed          | Show clinician pending task                         |
| Result sent to patient       | Log channel and user                                |
| Sensitive result             | Restrict visibility and notification content        |

---

## H. Referral

Referral must support both clinical continuity and claims.

### Referral types

| Type                 | Example                                          |
| -------------------- | ------------------------------------------------ |
| Outgoing referral    | Clinic refers to hospital/specialist             |
| Incoming referral    | Patient came from another facility               |
| Emergency referral   | Urgent transfer                                  |
| Lab/imaging referral | External diagnostic service                      |
| Program referral     | HIV/TB, mental health, specialist chronic care   |
| Reverse referral     | Higher facility sends patient back for follow-up |

### Referral fields

| Field                             |                                   Required? | Notes                    |
| --------------------------------- | ------------------------------------------: | ------------------------ |
| Referral number                   |                                         Yes | Auto                     |
| Patient                           |                                         Yes |                          |
| Visit                             |                                         Yes |                          |
| Referral type                     |                                         Yes | Out/in/emergency/program |
| Receiving facility                |                            Yes for outgoing |                          |
| Receiving clinician/department    |                                    Optional |                          |
| Reason for referral               |                                         Yes |                          |
| Diagnosis/impression              |                                         Yes |                          |
| Clinical summary                  |                                         Yes |                          |
| Treatment given                   |                                 Recommended |                          |
| Medicines prescribed/administered |                                 Recommended |                          |
| Results attached                  |                                    Optional |                          |
| Urgency                           |                                         Yes |                          |
| Transport/escort notes            |                                   Emergency |                          |
| Referring clinician               |                                         Yes |                          |
| Referral date/time                |                                         Yes |                          |
| Status                            | Draft, sent, accepted, completed, cancelled |                          |
| Feedback received                 |                                    Optional |                          |

### Referral letter contents

```text
Facility details
Patient details
Date/time
Reason for referral
Clinical history
Examination findings
Vitals
Diagnosis/impression
Investigations and results
Treatment given
Medicines prescribed/administered
Allergies
Urgency
Receiving facility/department
Referring clinician name, licence number, signature
```

### Referral rules

| Rule                       | System behaviour                                      |
| -------------------------- | ----------------------------------------------------- |
| Referral without reason    | Block                                                 |
| Emergency referral         | Require vitals and stabilization notes where possible |
| Claims referral required   | Route referral data to claims module                  |
| Program referral           | Mark sensitive where appropriate                      |
| Receiving facility unknown | Allow “external facility” but require name/contact    |
| Referral completed         | Record feedback/outcome if available                  |

---

## I. Certificates

Certificates should be controlled because they create legal and employment/school consequences.

### Certificate types

| Certificate                           | Notes                                                                      |
| ------------------------------------- | -------------------------------------------------------------------------- |
| Sick-off note                         | Time off work/school                                                       |
| Fit-to-return note                    | Return to work/school                                                      |
| School medical note                   | Child/school requirement                                                   |
| Procedure note                        | Wound care/injection/procedure proof                                       |
| Medical examination summary           | Where lawful and within facility scope                                     |
| Immunisation certificate/card extract | Where relevant                                                             |
| Death/birth-related certificates      | Avoid unless facility is licensed and legally authorized for that workflow |

### Certificate fields

| Field                    |                                Required? |
| ------------------------ | ---------------------------------------: |
| Certificate number       |                                      Yes |
| Patient                  |                                      Yes |
| Visit                    |                                      Yes |
| Certificate type         |                                      Yes |
| Diagnosis/reason         | Required or restricted based on template |
| Start date               |                              If sick-off |
| End date                 |                              If sick-off |
| Restrictions/advice      |                                 Optional |
| Issuing clinician        |                                      Yes |
| Clinician licence number |                                      Yes |
| Facility details         |                                      Yes |
| Issue date/time          |                                      Yes |
| QR/barcode verification  |                              Recommended |
| Status                   |                 Draft, issued, cancelled |
| Reprint count            |                                     Auto |
| Notes                    |                        Optional/internal |

### Certificate rules

| Rule                              | System behaviour                                       |
| --------------------------------- | ------------------------------------------------------ |
| Clinician licence inactive        | Cannot issue certificate                               |
| Certificate without visit         | Block except special authorized workflow               |
| Backdated certificate             | Requires senior approval/reason                        |
| Sick-off duration above threshold | Requires senior approval                               |
| Reprint                           | Require reason and log                                 |
| Cancel certificate                | Keep original record and cancellation reason           |
| Sensitive diagnosis               | Option to hide diagnosis on patient-facing certificate |

---

## J. Chronic care

Small clinics should support chronic-care tracking without becoming too complex.

### Chronic-care conditions

| Condition         | EMR support                                                          |
| ----------------- | -------------------------------------------------------------------- |
| Hypertension      | BP trend, medication history, follow-up, complications               |
| Diabetes          | Glucose/HbA1c where available, foot check, medication, refills       |
| Asthma/COPD       | Symptom control, inhaler use, exacerbations                          |
| Epilepsy          | Seizure frequency, medication adherence                              |
| HIV/TB            | Referral/program flag, privacy controls, do not expose unnecessarily |
| Mental health     | Sensitive notes, follow-up, medication monitoring                    |
| Pregnancy/ANC     | Basic tracking if facility offers maternal services                  |
| CKD/heart disease | Referral and monitoring fields                                       |

### Chronic registry fields

| Field                |
| -------------------- |
| Patient              |
| Condition            |
| Date diagnosed       |
| Diagnosis code       |
| Risk level           |
| Current medication   |
| Last visit date      |
| Next review date     |
| Last key measurement |
| Control status       |
| Complications        |
| Referrals            |
| Care plan            |
| Program flag         |
| Status               |

### Chronic-care visit fields

| Field              | Example                   |
| ------------------ | ------------------------- |
| Condition reviewed | Hypertension              |
| Symptoms           | Headache, dizziness, none |
| Adherence          | Good/poor/missed doses    |
| Side effects       | Yes/no                    |
| Vitals/trends      | BP, weight, glucose       |
| Medication changes | Continue/change/add       |
| Lifestyle advice   | Diet, exercise, smoking   |
| Follow-up date     | 1 month                   |
| Referral needed    | Yes/no                    |

### Chronic-care rules

| Rule                    | System behaviour                                          |
| ----------------------- | --------------------------------------------------------- |
| Chronic diagnosis added | Ask whether to enrol in chronic registry                  |
| Follow-up overdue       | Create recall task                                        |
| BP uncontrolled         | Alert clinician                                           |
| Diabetes visit          | Prompt glucose/foot review where configured               |
| Asthma frequent visits  | Flag poor control                                         |
| HIV/TB flag             | Restrict access and route to appropriate program/referral |
| Missed follow-up        | Send reminder only with consent                           |

---

## K. Immunisation

The immunisation feature should be optional and enabled only where the clinic actually provides vaccines.

Kenya’s Ministry of Health hosts national health portals including KHIS and other digital health systems, and its public communications emphasize routine childhood vaccination and keeping children up to date with scheduled doses. ([Ministry of Health][6]) ([Ministry of Health][8])

### Immunisation fields

| Field                    |                                Required? |
| ------------------------ | ---------------------------------------: |
| Patient                  |                                      Yes |
| Vaccine                  |                                      Yes |
| Dose number              |                                      Yes |
| Date administered        |                                      Yes |
| Age at administration    |                                     Auto |
| Batch/lot number         |    Recommended/required for traceability |
| Expiry date              |                     Recommended/required |
| Route/site               |                              Recommended |
| Administered by          |                                      Yes |
| Facility/branch          |                                      Yes |
| Next dose date           |                              Auto/manual |
| Contraindication checked |                              Recommended |
| Adverse event noted      |                                 Optional |
| Stock link               |                              Recommended |
| Card/registry reference  |                                 Optional |
| Status                   | Given, deferred, missed, contraindicated |

### Immunisation rules

| Rule                        | System behaviour                                 |
| --------------------------- | ------------------------------------------------ |
| Vaccine service not enabled | Hide immunisation workflow                       |
| Vaccine stock unavailable   | Warn/block administration                        |
| Vaccine expired             | Block                                            |
| Cold-chain issue            | Block/quarantine through inventory               |
| Next dose due               | Create reminder if consent                       |
| Missed dose                 | Flag catch-up                                    |
| AEFI/adverse event          | Create safety report workflow                    |
| Duplicate same dose         | Warn                                             |
| Child patient               | Show age-based schedule prompts where configured |

### Vaccine record output

The system should print or share:

```text
Patient name
Date of birth/age
Vaccine
Dose
Date administered
Batch/lot
Facility
Administering clinician/nurse
Next dose date
```

---

## L. Visit summary

The visit summary is the patient-facing and referral/claims-friendly output of the encounter.

### Visit summary contents

| Section             | Content                                    |
| ------------------- | ------------------------------------------ |
| Facility            | Name, branch, licence details where needed |
| Patient             | Name, age, sex, patient number             |
| Visit               | Date, clinician, visit type                |
| Complaint           | Main complaint                             |
| Vitals              | BP, pulse, temp, weight, height, SpO₂      |
| Diagnosis           | Primary and secondary diagnoses            |
| Investigations      | Ordered and resulted tests                 |
| Treatment           | Procedures, medicines, advice              |
| Prescription        | Medicines prescribed                       |
| Dispensed medicines | If pharmacy integrated                     |
| Referral            | Receiving facility and reason              |
| Follow-up           | Review date and instructions               |
| Warnings            | Danger signs, return instructions          |
| Clinician           | Name, cadre, licence number                |
| QR/barcode          | Optional verification                      |

### Visit summary formats

| Format               | Use                                      |
| -------------------- | ---------------------------------------- |
| Thermal summary      | Quick outpatient receipt-like note       |
| A4 PDF               | Formal referral/insurance/medical record |
| SMS/WhatsApp link    | Patient access, consent required         |
| Email PDF            | Corporate/insurance/patient copy         |
| FHIR document bundle | Future interoperability                  |
| Claim packet         | Billing/claims officer                   |

### Visit summary rules

| Rule                 | System behaviour                                        |
| -------------------- | ------------------------------------------------------- |
| Unsigned visit       | Watermark as draft                                      |
| Sensitive diagnosis  | Hide or restrict patient-facing output based on policy  |
| Claim-ready summary  | Requires diagnosis, clinician, services, orders/results |
| Referral summary     | Requires reason and receiving facility                  |
| Reprint              | Log user, time, reason                                  |
| Share electronically | Requires consent and secure access method               |

---

# 7. Required screens

## Screen 1: Patient registration

Sections:

| Section    | Contents                                          |
| ---------- | ------------------------------------------------- |
| Identity   | Name, DOB/age, sex, ID/passport/birth certificate |
| Contact    | Phone, address, next of kin                       |
| Payer      | Cash, SHA, insurer, corporate                     |
| Safety     | Allergies, chronic conditions, current meds       |
| Consent    | SMS, WhatsApp, sharing, reminders                 |
| Duplicates | Possible existing patients                        |
| Documents  | ID card, referral letter, prior reports           |

---

## Screen 2: Appointment and queue dashboard

Columns:

| Column              |
| ------------------- |
| Queue number        |
| Patient             |
| Age/sex             |
| Visit reason        |
| Payer               |
| Stage               |
| Waiting time        |
| Assigned clinician  |
| Priority            |
| Payment status      |
| Lab/pharmacy status |
| Alerts              |

Actions:

```text
Register
Book appointment
Check in
Send to triage
Send to consultation
Send to lab
Send to pharmacy
Send to billing
Complete visit
```

---

## Screen 3: Triage screen

Sections:

| Section            | Contents                                   |
| ------------------ | ------------------------------------------ |
| Visit reason       | Complaint/review                           |
| Vitals             | BP, pulse, temp, weight, height, BMI, SpO₂ |
| Risk flags         | Emergency, pregnancy, child, elderly       |
| Allergies          | Add/update                                 |
| Chronic conditions | Add/update                                 |
| Notes              | Short triage note                          |
| Routing            | Send to clinician/emergency/procedure      |

---

## Screen 4: Clinician consultation screen

Layout:

```text
LEFT: patient summary, previous visits, allergies, chronic conditions, current meds
CENTER: clinical note template
RIGHT: orders, diagnosis, prescription, results, follow-up
BOTTOM: sign note, print summary, send to billing/pharmacy/lab
```

Important tabs:

| Tab                | Use                  |
| ------------------ | -------------------- |
| Today’s visit      | Current note         |
| History            | Previous visits      |
| Vitals trend       | BP/weight/glucose    |
| Medication history | Prescribed/dispensed |
| Results            | Lab/imaging          |
| Documents          | Attachments          |
| Chronic care       | Condition dashboard  |
| Claims             | Claim readiness      |

---

## Screen 5: Diagnosis screen

Features:

| Feature                       |
| ----------------------------- |
| Search diagnosis text         |
| ICD-10 code lookup            |
| Common diagnosis favourites   |
| Primary/secondary diagnosis   |
| Provisional/final status      |
| Chronic-care enrolment prompt |
| Claims readiness warning      |

---

## Screen 6: Orders screen

Order panels:

| Panel          | Use                               |
| -------------- | --------------------------------- |
| Lab orders     | Test selection                    |
| Imaging orders | Internal/external                 |
| Procedures     | Dressing, injection, nebulization |
| Prescriptions  | Medicine orders                   |
| Referrals      | Outgoing referral                 |
| Certificates   | Sick-off/school/work note         |

---

## Screen 7: Results review

Features:

| Feature                         |
| ------------------------------- |
| Pending results                 |
| Abnormal/critical flags         |
| Numeric/text/attachment results |
| Previous result comparison      |
| Clinician review checkbox       |
| Patient notification log        |
| Result correction trail         |

---

## Screen 8: Referral screen

Features:

| Feature                     |
| --------------------------- |
| Receiving facility          |
| Referral reason             |
| Clinical summary            |
| Attached results            |
| Treatment already given     |
| Urgency                     |
| Print/share referral letter |
| Referral status tracking    |

---

## Screen 9: Chronic-care dashboard

Cards:

```text
Patients due for review
Missed follow-ups
Uncontrolled BP
Uncontrolled glucose
Asthma frequent exacerbations
Medication refill overdue
Program referrals
```

Patient view:

```text
Condition
Last visit
Last measurement
Current medicines
Next review
Control status
Complications
```

---

## Screen 10: Immunisation screen

Features:

| Feature                 |
| ----------------------- |
| Vaccine schedule view   |
| Vaccine administered    |
| Batch/expiry            |
| Next dose date          |
| Missed dose/catch-up    |
| Print vaccine record    |
| AEFI/adverse event note |
| Stock link              |

---

## Screen 11: Visit summary screen

Features:

| Feature                  |
| ------------------------ |
| Summary preview          |
| Include/exclude sections |
| Patient copy             |
| Referral copy            |
| Claim copy               |
| Print PDF                |
| Send link                |
| FHIR/export package      |
| Reprint log              |

---

# 8. Workflows

## A. New outpatient visit

```text
1. Reception registers patient
2. Patient is added to queue
3. Payment/eligibility is checked based on clinic policy
4. Triage captures vitals and safety flags
5. Clinician opens consultation
6. Clinician records complaint, history, exam, diagnosis, plan
7. Clinician orders labs/procedure/prescription/referral if needed
8. Billing module bills services and items
9. Lab/pharmacy/procedure workflows run
10. Clinician reviews results if needed
11. Visit summary is printed/shared
12. Visit is closed
```

---

## B. Returning patient visit

```text
1. Reception searches patient
2. System shows previous visits, chronic flags, allergies
3. Patient is checked into queue
4. Triage captures current vitals
5. Clinician reviews previous record
6. Clinician documents follow-up
7. Medication/refill/orders are updated
8. Visit summary and next review date are created
```

---

## C. Consultation with lab order

```text
1. Clinician creates lab order
2. Billing confirms payment or insurer authorization
3. Lab receives order
4. Sample is collected
5. Result is entered and verified
6. Clinician receives result alert
7. Clinician updates plan
8. Prescription/referral/follow-up is completed
```

---

## D. Consultation with prescription

```text
1. Clinician selects medicines and dosage instructions
2. EMR sends prescription to pharmacy queue
3. Pharmacist reviews through Module 3
4. POS bills through Module 2
5. Dispensed medicines return to EMR medication history
6. Visit summary shows prescribed and dispensed medicines
```

---

## E. Procedure visit

```text
1. Clinician/nurse orders procedure
2. Billing confirms payment/cover
3. Procedure is performed
4. Procedure note is captured
5. Consumables are deducted from inventory if configured
6. Visit summary includes procedure details
```

---

## F. Referral workflow

```text
1. Clinician decides patient needs higher/specialist care
2. Referral reason and receiving facility are captured
3. Key clinical notes, vitals, diagnosis, results, and treatment are pulled into letter
4. Referral letter is printed/shared
5. Patient is marked referred
6. Feedback/outcome can be recorded later
```

---

## G. Chronic-care follow-up

```text
1. Patient is flagged as chronic-care patient
2. Follow-up visit opens chronic template
3. System shows trends and medication history
4. Clinician records control status and adherence
5. Medicines/labs/referrals are updated
6. Next review date is set
7. Reminder task is created if consent exists
```

---

## H. Immunisation workflow

```text
1. Child/patient is registered
2. Immunisation screen shows due vaccine if configured
3. Nurse confirms vaccine, dose, batch, expiry
4. System checks stock and expiry
5. Vaccine is administered
6. Stock is decremented
7. Next dose date is calculated
8. Vaccine record is printed/shared
```

---

## I. Claim-ready visit workflow

```text
1. Patient/payer is selected
2. Eligibility/preauth is captured where required
3. Clinician documents visit
4. ICD-10-ready diagnosis is selected
5. Services, lab, procedure, and prescription are linked to visit
6. Results/attachments are added
7. Visit is signed
8. Claims module creates claim packet
9. Claim validation checks missing documentation
```

---

# 9. Rules engine

## Clinical consultation allowed

```text
RULE: Consultation signing
IF facility_licence.status = active
AND clinician.practising_licence.status = active
AND clinician.assigned_branch = current_branch
THEN allow clinician to sign note
ELSE block signing
```

## Queue movement

```text
RULE: Send to consultation
IF patient_registered = true
AND visit_open = true
AND queue_status in [registered, triaged, waiting_clinician]
THEN allow consultation
ELSE show blocker
```

## Vitals safety

```text
RULE: Critical vital alert
IF spo2 < configured_threshold
OR temperature > configured_high_fever
OR systolic_bp > configured_hypertensive_crisis
THEN mark visit high_priority
AND alert clinician
```

## Diagnosis requirement

```text
RULE: Close visit
IF visit.requires_claim = true
THEN primary_diagnosis and signed_note are required
ELSE allow closure with warning if diagnosis missing
```

## ICD-10 requirement

```text
RULE: Claim-ready diagnosis
IF payer_type in [SHA, private_insurer, corporate_claim]
THEN diagnosis.icd10_code is required
ELSE diagnosis text may be sufficient
```

## Lab order

```text
RULE: Lab order completion
IF lab_order.status = resulted
AND result.verified = true
THEN notify ordering clinician
AND mark result pending_review
```

## Prescription

```text
RULE: Send prescription to pharmacy
IF clinician_note.signed = true
OR facility_policy.allows_draft_prescriptions = true
THEN create pharmacy_queue_item
ELSE block prescription release
```

## Certificate

```text
RULE: Sick-off certificate
IF clinician.practising_licence.status = active
AND visit.exists = true
AND certificate.reason is provided
THEN allow issue
ELSE block
```

## Referral

```text
RULE: Referral letter
IF referral.reason exists
AND diagnosis_or_assessment exists
AND receiving_facility exists
AND clinician_signature exists
THEN allow referral generation
ELSE show missing fields
```

## Immunisation

```text
RULE: Administer vaccine
IF vaccine_stock.status = available
AND batch.expiry_date > today
AND cold_chain_status = valid
AND administering_user.authorized = true
THEN allow vaccine record
ELSE block
```

---

# 10. Data model

## Main tables

### `patients`

| Field                    |
| ------------------------ |
| id                       |
| patient_number           |
| full_name                |
| date_of_birth            |
| estimated_age            |
| sex                      |
| phone                    |
| alternative_phone        |
| national_id              |
| passport_number          |
| birth_certificate_number |
| county                   |
| sub_county               |
| ward                     |
| address                  |
| next_of_kin_name         |
| next_of_kin_phone        |
| guardian_name            |
| guardian_relationship    |
| sha_number               |
| status                   |
| created_at               |
| updated_at               |

### `patient_consents`

| Field         |
| ------------- |
| id            |
| patient_id    |
| consent_type  |
| consent_given |
| channel       |
| captured_by   |
| captured_at   |
| withdrawn_at  |
| notes         |

### `patient_allergies`

| Field         |
| ------------- |
| id            |
| patient_id    |
| allergen      |
| allergen_type |
| reaction      |
| severity      |
| recorded_by   |
| recorded_at   |
| status        |

### `appointments`

| Field                |
| -------------------- |
| id                   |
| appointment_number   |
| patient_id           |
| branch_id            |
| clinician_id         |
| service_type         |
| appointment_datetime |
| reason               |
| payer_type           |
| status               |
| reminder_status      |
| notes                |
| created_by           |
| created_at           |

### `visits`

| Field              |
| ------------------ |
| id                 |
| visit_number       |
| patient_id         |
| branch_id          |
| visit_type         |
| visit_date         |
| payer_type         |
| payer_contract_id  |
| priority           |
| status             |
| checked_in_by      |
| checked_in_at      |
| closed_by          |
| closed_at          |
| claim_ready_status |

### `queue_events`

| Field       |
| ----------- |
| id          |
| visit_id    |
| from_stage  |
| to_stage    |
| assigned_to |
| moved_by    |
| moved_at    |
| notes       |

### `vitals`

| Field                    |
| ------------------------ |
| id                       |
| visit_id                 |
| patient_id               |
| blood_pressure_systolic  |
| blood_pressure_diastolic |
| pulse                    |
| temperature              |
| weight                   |
| height                   |
| bmi                      |
| spo2                     |
| respiratory_rate         |
| pain_score               |
| pregnancy_status         |
| lmp                      |
| recorded_by              |
| recorded_at              |
| alert_status             |

### `clinical_notes`

| Field                        |
| ---------------------------- |
| id                           |
| visit_id                     |
| patient_id                   |
| clinician_id                 |
| chief_complaint              |
| history_presenting_complaint |
| past_medical_history         |
| drug_history                 |
| allergy_history              |
| examination                  |
| assessment                   |
| plan                         |
| counselling_notes            |
| follow_up_date               |
| note_status                  |
| signed_by                    |
| signed_at                    |
| addendum_to_note_id          |
| created_at                   |
| updated_at                   |

### `diagnoses`

| Field          |
| -------------- |
| id             |
| visit_id       |
| patient_id     |
| diagnosis_text |
| icd10_code     |
| diagnosis_type |
| primary_flag   |
| status         |
| onset_date     |
| severity       |
| clinician_id   |
| created_at     |

### `orders`

| Field                 |
| --------------------- |
| id                    |
| order_number          |
| visit_id              |
| patient_id            |
| ordering_clinician_id |
| order_type            |
| order_item_id         |
| clinical_indication   |
| priority              |
| payment_status        |
| status                |
| created_at            |
| cancelled_at          |
| cancellation_reason   |

### `results`

| Field                  |
| ---------------------- |
| id                     |
| order_id               |
| visit_id               |
| patient_id             |
| result_type            |
| result_value           |
| unit                   |
| reference_range        |
| abnormal_flag          |
| critical_flag          |
| result_text            |
| attachment_document_id |
| performed_by           |
| verified_by            |
| verified_at            |
| reviewed_by_clinician  |
| reviewed_at            |
| status                 |
| created_at             |

### `prescriptions`

| Field               |
| ------------------- |
| id                  |
| visit_id            |
| patient_id          |
| clinician_id        |
| prescription_number |
| diagnosis_id        |
| status              |
| sent_to_pharmacy_at |
| created_at          |

### `prescription_items`

| Field                |
| -------------------- |
| id                   |
| prescription_id      |
| medicine_id          |
| generic_name         |
| strength             |
| dosage_form          |
| dose                 |
| frequency            |
| duration             |
| route                |
| quantity             |
| instructions         |
| substitution_allowed |
| status               |

### `procedures`

| Field                 |
| --------------------- |
| id                    |
| visit_id              |
| patient_id            |
| procedure_code        |
| procedure_name        |
| indication            |
| performed_by          |
| performed_at          |
| notes                 |
| consumables_used_json |
| status                |

### `referrals`

| Field                   |
| ----------------------- |
| id                      |
| referral_number         |
| visit_id                |
| patient_id              |
| referral_type           |
| receiving_facility      |
| receiving_department    |
| receiving_clinician     |
| reason                  |
| urgency                 |
| diagnosis_summary       |
| clinical_summary        |
| treatment_given         |
| documents_attached_json |
| referred_by             |
| referred_at             |
| status                  |
| feedback_received       |
| feedback_notes          |

### `certificates`

| Field               |
| ------------------- |
| id                  |
| certificate_number  |
| visit_id            |
| patient_id          |
| certificate_type    |
| reason              |
| start_date          |
| end_date            |
| restrictions        |
| issued_by           |
| issued_at           |
| qr_code             |
| status              |
| cancelled_by        |
| cancelled_at        |
| cancellation_reason |

### `chronic_care_registry`

| Field                    |
| ------------------------ |
| id                       |
| patient_id               |
| condition                |
| diagnosis_id             |
| date_diagnosed           |
| risk_level               |
| current_medications_json |
| last_visit_date          |
| next_review_date         |
| control_status           |
| complications_json       |
| program_flag             |
| status                   |

### `immunisations`

| Field              |
| ------------------ |
| id                 |
| patient_id         |
| visit_id           |
| vaccine_id         |
| dose_number        |
| date_administered  |
| batch_id           |
| batch_number       |
| expiry_date        |
| route              |
| site               |
| administered_by    |
| next_dose_date     |
| adverse_event_flag |
| status             |

### `visit_summaries`

| Field               |
| ------------------- |
| id                  |
| visit_id            |
| patient_id          |
| summary_type        |
| summary_json        |
| document_id         |
| generated_by        |
| generated_at        |
| shared_with_patient |
| sharing_channel     |
| status              |

### `clinical_attachments`

| Field            |
| ---------------- |
| id               |
| patient_id       |
| visit_id         |
| document_type    |
| file_url         |
| file_hash        |
| uploaded_by      |
| uploaded_at      |
| visibility_level |
| notes            |

### `emr_audit_logs`

| Field          |
| -------------- |
| id             |
| entity_type    |
| entity_id      |
| patient_id     |
| visit_id       |
| action         |
| old_value_json |
| new_value_json |
| reason         |
| performed_by   |
| branch_id      |
| device_id      |
| created_at     |

---

# 11. API design

## Patient and registration endpoints

| Endpoint                          | Purpose                  |
| --------------------------------- | ------------------------ |
| `POST /patients`                  | Register patient         |
| `GET /patients/search`            | Search patients          |
| `GET /patients/{id}`              | View patient             |
| `PATCH /patients/{id}`            | Update patient           |
| `POST /patients/{id}/consents`    | Capture consent          |
| `POST /patients/{id}/merge`       | Merge duplicate patients |
| `POST /patients/{id}/attachments` | Upload document          |

## Appointment and queue endpoints

| Endpoint                           | Purpose                       |
| ---------------------------------- | ----------------------------- |
| `POST /appointments`               | Book appointment              |
| `POST /appointments/{id}/check-in` | Check in patient              |
| `POST /visits`                     | Start visit                   |
| `GET /queue`                       | View queue                    |
| `POST /queue/{visitId}/move`       | Move patient to another stage |
| `POST /visits/{id}/close`          | Close visit                   |

## Vitals endpoints

| Endpoint                          | Purpose                    |
| --------------------------------- | -------------------------- |
| `POST /visits/{id}/vitals`        | Record vitals              |
| `GET /patients/{id}/vitals-trend` | View trends                |
| `POST /vitals/{id}/review-alert`  | Acknowledge critical vital |

## Clinical note endpoints

| Endpoint                              | Purpose                 |
| ------------------------------------- | ----------------------- |
| `POST /visits/{id}/clinical-notes`    | Create note             |
| `PATCH /clinical-notes/{id}`          | Edit draft note         |
| `POST /clinical-notes/{id}/sign`      | Sign note               |
| `POST /clinical-notes/{id}/addendum`  | Add correction/addendum |
| `GET /patients/{id}/clinical-history` | Patient history         |

## Diagnosis endpoints

| Endpoint                       | Purpose                 |
| ------------------------------ | ----------------------- |
| `POST /visits/{id}/diagnoses`  | Add diagnosis           |
| `GET /diagnoses/search`        | Search diagnosis/ICD-10 |
| `PATCH /diagnoses/{id}`        | Update diagnosis        |
| `POST /diagnoses/{id}/resolve` | Mark resolved           |

## Orders and results endpoints

| Endpoint                     | Purpose                                         |
| ---------------------------- | ----------------------------------------------- |
| `POST /orders`               | Create lab/imaging/procedure/prescription order |
| `POST /orders/{id}/cancel`   | Cancel order                                    |
| `GET /orders/pending`        | Pending orders                                  |
| `POST /results`              | Add result                                      |
| `POST /results/{id}/verify`  | Verify result                                   |
| `POST /results/{id}/review`  | Clinician review                                |
| `POST /results/{id}/correct` | Correct result                                  |

## Referral and certificate endpoints

| Endpoint                         | Purpose            |
| -------------------------------- | ------------------ |
| `POST /referrals`                | Create referral    |
| `POST /referrals/{id}/send`      | Mark sent/share    |
| `POST /referrals/{id}/feedback`  | Record feedback    |
| `POST /certificates`             | Create certificate |
| `POST /certificates/{id}/issue`  | Issue certificate  |
| `POST /certificates/{id}/cancel` | Cancel certificate |
| `POST /certificates/{id}/print`  | Print/reprint      |

## Chronic care and immunisation endpoints

| Endpoint                           | Purpose                 |
| ---------------------------------- | ----------------------- |
| `POST /chronic-care/enrol`         | Enrol patient           |
| `GET /chronic-care/due`            | Patients due for review |
| `POST /chronic-care/{id}/review`   | Record chronic review   |
| `POST /immunisations`              | Record vaccine          |
| `GET /patients/{id}/immunisations` | Vaccine history         |
| `GET /immunisations/due`           | Due/missed vaccines     |

## Visit summary endpoints

| Endpoint                          | Purpose                     |
| --------------------------------- | --------------------------- |
| `POST /visits/{id}/summary`       | Generate summary            |
| `GET /visits/{id}/summary`        | View summary                |
| `POST /visits/{id}/summary/print` | Print                       |
| `POST /visits/{id}/summary/share` | Share securely              |
| `POST /visits/{id}/claim-pack`    | Generate claim-ready packet |

---

# 12. Integration points

| Integration            | Purpose                                                                                                            |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------ |
| Organisation/licensing | Facility and clinician permission checks                                                                           |
| POS/billing            | Consultation, lab, procedure, prescription billing                                                                 |
| Pharmacy dispensing    | Send prescriptions and receive dispense status                                                                     |
| Inventory              | Procedure consumables, vaccines, lab consumables                                                                   |
| Lab-lite module        | Orders and results                                                                                                 |
| Claims module          | Diagnosis, services, results, attachments, visit summary                                                           |
| SHA/private insurer    | Eligibility, preauth, claim evidence                                                                               |
| KHIS/DHIS2 reporting   | Aggregate facility reports                                                                                         |
| SMS/WhatsApp           | Appointment, refill, results, follow-up reminders with consent                                                     |
| FHIR API               | Patient, Encounter, Observation, Condition, ServiceRequest, DiagnosticReport, MedicationRequest, DocumentReference |
| Document storage       | Attachments, certificates, referral letters                                                                        |
| Audit/security         | Access logs and data protection                                                                                    |

---

# 13. Permissions

| Permission               |  Reception | Triage/Nurse |    Clinician |     Lab | Pharmacy |    Billing |      Manager | Auditor |
| ------------------------ | ---------: | -----------: | -----------: | ------: | -------: | ---------: | -----------: | ------: |
| Register patient         |        Yes |          Yes |          Yes |      No |  Limited |        Yes |          Yes |    View |
| Edit demographics        |        Yes |      Limited |      Limited |      No |       No |    Limited |          Yes |    View |
| View full clinical notes | No/limited |      Limited |          Yes | Limited |  Limited | No/limited | Configurable |     Yes |
| Record vitals            | No/limited |          Yes |          Yes |      No |       No |         No |          Yes |    View |
| Write clinical note      |         No |      Limited |          Yes |      No |       No |         No |           No |    View |
| Sign clinical note       |         No | Configurable |          Yes |      No |       No |         No |           No |    View |
| Add diagnosis            |         No |   No/limited |          Yes |      No |       No |         No |           No |    View |
| Create lab order         |         No |      Limited |          Yes |      No |       No |         No |           No |    View |
| Enter lab result         |         No |           No |           No |     Yes |       No |         No |           No |    View |
| Verify/review result     |         No |           No | Yes/Lab lead |     Yes |       No |         No |           No |    View |
| Create prescription      |         No |   No/limited |          Yes |      No |       No |         No |           No |    View |
| Dispense prescription    |         No |           No |           No |      No |      Yes |         No |           No |    View |
| Issue certificate        |         No |           No |          Yes |      No |       No |         No |           No |    View |
| Create referral          |         No |      Limited |          Yes |      No |       No |         No |           No |    View |
| View billing             |        Yes |      Limited |      Limited |      No |  Limited |        Yes |          Yes |    View |
| Export reports           |         No |           No |      Limited | Limited |       No |        Yes |          Yes |     Yes |
| View audit logs          |         No |           No |           No |      No |       No |         No |          Yes |     Yes |

---

# 14. Reports

## Clinical operations reports

| Report                  | Purpose                                       |
| ----------------------- | --------------------------------------------- |
| Daily visit report      | Visits by date, branch, clinician             |
| OPD attendance          | Outpatient volume                             |
| Queue waiting time      | Service efficiency                            |
| Clinician workload      | Consultations per clinician                   |
| Triage report           | Vitals and triage activity                    |
| Diagnosis report        | Common conditions                             |
| ICD-10 diagnosis report | Claims/public health readiness                |
| Lab order/result report | Pending and completed investigations          |
| Prescription report     | Medicines ordered from EMR                    |
| Referral report         | Outgoing/incoming referrals                   |
| Certificate report      | Sick-off/school/work notes issued             |
| Visit summary report    | Summaries generated/shared                    |
| Unsigned notes report   | Clinical documentation gaps                   |
| Incomplete visit report | Visits not closed properly                    |
| Critical result report  | Safety monitoring                             |
| Chronic-care due report | Follow-up management                          |
| Immunisation report     | Vaccines given/missed/due                     |
| Claims readiness report | Missing diagnosis, notes, results, signatures |
| Audit/access report     | Privacy and compliance                        |

## Owner/manager dashboard

```text
Patients seen today
Patients waiting
Average waiting time
Clinicians active
Visits by service
Revenue-linked visits
Claims-ready visits
Unsigned notes
Pending lab results
Pending prescriptions
Referrals today
Chronic patients due
Immunisations today
Certificates issued
```

---

# 15. Privacy and security controls

Because EMR data is sensitive health data, the module must have stronger controls than a normal POS.

| Control                | Requirement                                                                |
| ---------------------- | -------------------------------------------------------------------------- |
| Role-based access      | Different screens for reception, nurse, clinician, lab, billing            |
| Patient-level audit    | Every view/edit/export logged                                              |
| Sensitive-note marking | HIV/TB, mental health, reproductive health, minors, violence-related notes |
| Consent capture        | SMS, WhatsApp, sharing, reminders, referral exchange                       |
| Session timeout        | Especially shared clinic computers                                         |
| Device control         | Revoke lost/stolen tablets                                                 |
| Encryption             | At rest and in transit                                                     |
| Backup and restore     | Tested recovery                                                            |
| Addendum model         | Signed notes cannot be silently edited                                     |
| Break-glass access     | Emergency access with reason and audit                                     |
| Data export control    | Visit summaries, claim packs, referral letters                             |
| Minor/guardian rules   | Control who receives messages and summaries                                |
| Data retention         | Configurable policy                                                        |
| Breach log             | Incident recording and response workflow                                   |

---

# 16. Edge cases

| Edge case                                | Correct handling                                                     |
| ---------------------------------------- | -------------------------------------------------------------------- |
| Patient arrives unconscious/emergency    | Quick registration, complete demographics later                      |
| Patient has no ID                        | Allow care, flag ID as missing                                       |
| Duplicate patient record                 | Merge workflow with audit                                            |
| Wrong patient selected                   | Correction workflow; do not delete silently                          |
| Clinician forgets to sign note           | Visit remains not claim-ready                                        |
| Lab result entered for wrong patient     | Correction version and incident log                                  |
| Patient leaves before completion         | Visit marked incomplete/left before treatment                        |
| Prescription created before payment      | Facility policy decides: hold, bill first, or dispense after payment |
| Insurer/SHA rejects claim                | Claim module routes missing documentation back to EMR                |
| Referral facility unknown                | Allow free text but flag for cleanup                                 |
| Sick-off backdated                       | Senior approval and reason                                           |
| Sensitive diagnosis printed accidentally | Use summary templates and privacy filters                            |
| Minor patient notification               | Send to guardian only where appropriate                              |
| Internet outage                          | Continue local queue/notes if offline mode is enabled, sync later    |
| Clinician licence expired mid-day        | Block new signatures after status update                             |
| Patient requests record copy             | Generate controlled patient summary/export                           |
| Death or severe adverse event            | Incident/referral/clinical governance workflow                       |

---

# 17. MVP versus later versions

## MVP

Build these first:

| Feature                  | Reason                         |
| ------------------------ | ------------------------------ |
| Patient registration     | Foundation                     |
| Appointment/queue        | Clinic flow                    |
| Triage/vitals            | Clinical safety                |
| Clinical notes           | Core EMR                       |
| Diagnosis, ICD-10-ready  | Claims and reporting           |
| Orders                   | Lab, procedure, prescription   |
| Prescription to pharmacy | Clinic-pharmacy integration    |
| Results entry            | Basic lab/result workflow      |
| Referral letter          | Continuity and escalation      |
| Certificates             | Common clinic need             |
| Visit summary            | Patient/referral/claims output |
| Role-based access        | Privacy                        |
| Audit logs               | Compliance                     |
| Billing link             | Revenue and claims             |
| Basic reports            | Owner/manager visibility       |

## Version 2

Add:

| Feature                     | Reason                                   |
| --------------------------- | ---------------------------------------- |
| Chronic-care registry       | Diabetes, hypertension, asthma follow-up |
| Immunisation module         | Vaccine records where relevant           |
| Advanced templates          | Faster clinician documentation           |
| Results trend charts        | Chronic and lab monitoring               |
| Claims validation           | Reduce rejections                        |
| SMS/WhatsApp reminders      | Appointments, follow-ups, chronic care   |
| Patient portal              | Visit summaries and results              |
| Referral feedback tracking  | Continuity                               |
| Program flags               | HIV/TB/ANC/etc.                          |
| KHIS/DHIS2 aggregate export | Reporting support                        |
| FHIR API                    | Interoperability                         |

## Version 3

Add:

| Feature                              | Reason                              |
| ------------------------------------ | ----------------------------------- |
| National client registry integration | Future Digital Health Act readiness |
| Shared health record integration     | Continuity across facilities        |
| Clinical decision support            | Safety and quality                  |
| Telemedicine                         | Remote consultations                |
| AI documentation assistant           | Faster notes, with clinician review |
| Advanced chronic-care analytics      | Population management               |
| Immunisation registry integration    | National vaccine record support     |
| e-referral network                   | Referral tracking                   |
| Full insurer/SHA API integration     | Claims automation                   |
| Offline-first mobile EMR             | Rural/low-connectivity support      |

---

# 18. Acceptance criteria

The module is ready when it passes these tests:

| Test                 | Expected result                                                                         |
| -------------------- | --------------------------------------------------------------------------------------- |
| Register new patient | Patient number created with demographics, phone, ID/guardian/next of kin where captured |
| Duplicate check      | System warns on likely duplicate                                                        |
| Queue patient        | Patient moves from reception to triage to clinician                                     |
| Record vitals        | BP, pulse, temperature, weight, height/BMI, SpO₂ saved and visible to clinician         |
| Critical vital       | System alerts clinician                                                                 |
| Clinician note       | Complaint, history, exam, assessment, plan captured                                     |
| Diagnosis            | Primary diagnosis captured with ICD-10-ready field                                      |
| Lab order            | Order reaches lab/billing and result returns to clinician                               |
| Prescription         | Prescription reaches pharmacy dispensing module                                         |
| Procedure            | Procedure note links to billing and inventory where configured                          |
| Referral             | Referral letter generated with clinical summary                                         |
| Certificate          | Certificate issued only by authorized licensed clinician                                |
| Chronic care         | Patient enrolled and follow-up date generated                                           |
| Immunisation         | Vaccine record captures dose, batch, expiry, next dose                                  |
| Visit summary        | Printable/shareable visit summary generated                                             |
| Claim readiness      | Visit shows missing diagnosis/note/result/signature before claim                        |
| Privacy              | Reception cannot access restricted clinical details unless permitted                    |
| Audit                | Every view, edit, print, export, and signature is logged                                |

---

# 19. Final product behaviour

The Clinic EMR Module should behave like this:

| Situation              | Correct behaviour                                        |
| ---------------------- | -------------------------------------------------------- |
| New patient arrives    | Register, check duplicates, add to queue                 |
| Patient goes to triage | Capture vitals and safety flags                          |
| Clinician consults     | Document note, diagnosis, plan                           |
| Lab needed             | Order test, bill, result, clinician review               |
| Medicine needed        | Prescription flows to pharmacy                           |
| Procedure needed       | Procedure order, billing, note, consumables              |
| Patient needs referral | Generate referral letter and track destination           |
| Patient needs sick-off | Issue controlled certificate with clinician signature    |
| Chronic patient        | Show trends, medication history, follow-up plan          |
| Vaccine given          | Record vaccine, batch, dose, next due date               |
| Visit ends             | Generate visit summary and close visit                   |
| Claim needed           | Provide signed, structured, evidence-backed claim packet |
| Audit needed           | Show who did what, when, and why                         |

The key design principle is:

**A small-clinic EMR should be fast at the point of care, but every visit must leave behind a clear clinical story: who the patient is, what was found, what was diagnosed, what was ordered, what was done, what was prescribed, what was billed, and what should happen next.**

[1]: https://new.kenyalaw.org/akn/ke/act/2023/15 "
      Digital Health Act
    \- Kenya Law"
[2]: https://kmpdc.go.ke/registration-of-a-health-facility/ "Registration of a Health Facility – Kenya Medical Practitioners and Dentists Council"
[3]: https://new.kenyalaw.org/akn/ke/act/2019/24/eng%402022-12-31 "
      Data Protection Act
    \- Kenya Law"
[4]: https://new.kenyalaw.org/akn/ke/act/ln/2024/49/eng%402025-02-28 "
      The Social Health Insurance Regulations
    \- Kenya Law"
[5]: https://icd.who.int/browse10/ "ICD-10 Version:2019 "
[6]: https://www.health.go.ke/ "MoH | Ministry of Health"
[7]: https://elearning.health.go.ke/course/index.php?categoryid=5 "MOH-VA: All courses | MOH-VA"
[8]: https://health.go.ke/vaccines-administered-our-children-are-safe-ministry-health-clarifies-nairobi-kenya-9th-november "Vaccines Administered to Our Children Are Safe, Ministry of Health Clarifies Nairobi, Kenya - 9th November 2024 | Ministry of Health"
