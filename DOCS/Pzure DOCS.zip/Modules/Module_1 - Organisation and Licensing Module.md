# Module 1: Organisation and Licensing Module

This module is the **compliance backbone** of the whole system. It answers one basic question before the system allows pharmacy, clinic, claims, or branch operations:

**Is this business, branch, facility, and responsible professional legally allowed to perform this activity?**

In Kenya, this matters because a pharmacy/chemist, clinic, and claims-enabled health facility are not licensed in the same way. PPB regulates pharmacy premises and pharmaceutical practice; KMPDC handles health facility registration; SHA pays claims to empanelled/contracted healthcare providers and facilities; professional councils maintain practitioner registers; BRS maintains business registration records; and ODPC regulates data handlers processing personal and health data. PPB says a person cannot carry on a pharmacy business in Kenya unless the premises have current approval, and the pharmacy business must meet the Pharmacy and Poisons Act framework. KMPDC’s facility registration process includes county inspection, online registration, prescribed fees, committee approval, and issuance of a registration certificate. BRS describes itself as the custodian of business registration records in Kenya. ([web.pharmacyboardkenya.org][1])

---

## 1. Purpose of the module

The Organisation and Licensing Module should:

| Purpose                             | Practical meaning                                                                                      |
| ----------------------------------- | ------------------------------------------------------------------------------------------------------ |
| Confirm legal identity              | Know who owns the business and under what registration                                                 |
| Confirm branch/facility legality    | Know which branch is allowed to operate as a pharmacy, clinic, lab, or shop                            |
| Confirm professional accountability | Link each regulated activity to a licensed responsible person                                          |
| Prevent illegal workflows           | Do not allow pharmacy dispensing, clinical consultation, or claims unless required licences are active |
| Manage renewals                     | Warn before licences expire                                                                            |
| Support audits                      | Produce a compliance file for PPB, KMPDC, SHA, insurers, ODPC, owners, or auditors                     |
| Support multi-branch growth         | Manage chains/franchises where each branch has different licences and staff                            |
| Support claims                      | Ensure SHA/private insurer contracts are tied to the right facility and services                       |

---

## 2. Core users

| User role                              | What they do in this module                                                       |
| -------------------------------------- | --------------------------------------------------------------------------------- |
| Owner/director                         | Adds business registration, branches, ownership, documents                        |
| Compliance/admin officer               | Maintains licences, renewals, evidence, inspection records                        |
| Superintendent pharmacist/technologist | Confirms pharmacy responsibility for a branch                                     |
| Clinic manager                         | Maintains KMPDC/facility information                                              |
| HR/admin                               | Adds professional licences for clinicians, nurses, pharmacists, clinical officers |
| Claims officer                         | Maintains SHA/private insurer contracts                                           |
| Auditor                                | Reviews licence status, documents, expiry history, and user changes               |
| System admin                           | Configures licence types, alert rules, approval workflow                          |

---

# 3. Main data structure

The module should be built around these entities:

```text
Organisation / Legal Entity
    └── Branch / Facility / Outlet
            ├── Licences and permits
            ├── Responsible professionals
            ├── Services allowed
            ├── SHA/private insurer contracts
            ├── Documents
            ├── Renewal alerts
            └── Compliance status
```

A business may have one legal entity and many branches. Each branch may have different permissions:

| Branch example    | Required records                                                                                                              |
| ----------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| Retail-only shop  | Business registration, county permit, KRA PIN, eTIMS setup                                                                    |
| Chemist/pharmacy  | Business registration, PPB premise licence, superintendent, staff licences, county permit                                     |
| Clinic only       | Business registration, KMPDC facility licence, clinician licences, SHA/private contracts if applicable                        |
| Clinic + pharmacy | Business registration, KMPDC facility licence, PPB premise licence, superintendent, clinician licences, insurer/SHA contracts |
| Chain/franchise   | Parent organisation, branch-level licences, branch-level staff, branch-level contracts                                        |

---

# 4. Detailed data fields

## A. Business registration

BRS maintains business registration records and provides online business registration services; therefore, the system should treat the business registration as the parent legal identity for branches and licences. ([Business Registration Service][2])

| Field                                     |               Type |     Required? | Notes                                                                      |
| ----------------------------------------- | -----------------: | ------------: | -------------------------------------------------------------------------- |
| Legal entity name                         |               Text |           Yes | Name as registered                                                         |
| Trading name                              |               Text |           Yes | Name displayed to customers                                                |
| Entity type                               |           Dropdown |           Yes | Sole proprietor, partnership, limited company, NGO/FBO, SACCO, trust, etc. |
| Business registration number              |               Text |           Yes | BRS/eCitizen registration number                                           |
| Certificate of registration/incorporation |        File upload |           Yes | PDF/image                                                                  |
| CR12 / official company search            |        File upload | For companies | Useful for ownership verification                                          |
| KRA PIN                                   |               Text |           Yes | Needed for tax/eTIMS/accounting                                            |
| VAT status                                |           Dropdown |           Yes | VAT registered, non-VAT, exempt, unknown                                   |
| Postal address                            |               Text |      Optional | Formal documents                                                           |
| Physical head office address              | Structured address |           Yes | County, sub-county, ward, street/building                                  |
| Business phone                            |              Phone |           Yes | Official contact                                                           |
| Business email                            |              Email |           Yes | Official contact                                                           |
| Owner/director names                      |              Table |           Yes | Include ID/passport and role                                               |
| Beneficial owner details                  |              Table |   Recommended | Useful for compliance and insurer contracts                                |
| Bank account details                      |         Structured |      Optional | Claims and supplier payments                                               |
| M-Pesa Till/Paybill                       |         Structured |      Optional | Payment setup                                                              |
| Date registered                           |               Date |           Yes | Business age                                                               |
| Status                                    |           Dropdown |           Yes | Draft, active, suspended, closed                                           |
| Verification source                       |          Text/link |      Optional | BRS/eCitizen/manual                                                        |
| Last verified date                        |               Date |   Recommended | For compliance checks                                                      |

### Business rules

| Rule                                         | System behaviour                                    |
| -------------------------------------------- | --------------------------------------------------- |
| No active branch without active legal entity | Branch remains “setup incomplete”                   |
| Legal name change                            | Requires document upload and approval               |
| KRA PIN missing                              | Allow setup, but block eTIMS activation until added |
| Company ownership document expired/outdated  | Warn admin to refresh official search               |
| Duplicate business registration number       | Block duplicate legal entity                        |

---

## B. Branches / outlets / facilities

This is the most important operational entity. A branch is the physical place where sales, dispensing, consultation, billing, and claims happen.

| Field                         |         Type |   Required? | Notes                                                         |
| ----------------------------- | -----------: | ----------: | ------------------------------------------------------------- |
| Branch name                   |         Text |         Yes | Example: AfyaCare Pharmacy - Rongai                           |
| Branch code                   |  Auto/manual |         Yes | Internal unique code                                          |
| Branch type                   | Multi-select |         Yes | Retail, pharmacy, clinic, lab, clinic+pharmacy, warehouse     |
| Ownership model               |     Dropdown |         Yes | Owned branch, franchise, partner, managed outlet              |
| Physical address              |   Structured |         Yes | County, sub-county, ward, town, estate, building              |
| GPS coordinates               |          Geo | Recommended | Helps with inspections, deliveries, branch maps               |
| Phone                         |        Phone |         Yes | Branch contact                                                |
| Email                         |        Email |    Optional | Branch contact                                                |
| Operating hours               |     Schedule |         Yes | Used for online orders/appointments                           |
| Branch manager                |   Staff link |         Yes | Accountable admin                                             |
| Services offered              | Multi-select |         Yes | Consultation, pharmacy, lab, immunisation, chronic care, etc. |
| KEPH/facility level           |     Dropdown | For clinics | Useful for SHA/KMPDC alignment                                |
| Tax invoice unit              |     Dropdown |         Yes | Which eTIMS setup applies                                     |
| Cash drawers/payment accounts |        Table |    Optional | Till/paybill/cash drawer assignment                           |
| Status                        |     Dropdown |         Yes | Setup, pending inspection, active, suspended, closed          |
| Opening date                  |         Date |    Optional | Business reporting                                            |
| Closure date                  |         Date |   If closed | Historical audit                                              |

### Branch service flags

The branch should have controlled service flags:

| Flag                                  | Meaning                              |
| ------------------------------------- | ------------------------------------ |
| `can_sell_retail_goods`               | Normal POS allowed                   |
| `can_sell_otc_medicines`              | OTC medicine sales allowed           |
| `can_dispense_prescription_medicines` | Prescription dispensing allowed      |
| `can_run_clinic_consultations`        | EMR consultations allowed            |
| `can_run_lab_tests`                   | Lab-lite/LIS workflow allowed        |
| `can_submit_claims`                   | SHA/private insurer claims allowed   |
| `can_sell_online`                     | Internet pharmacy/e-commerce enabled |
| `can_transfer_stock`                  | Branch-to-branch transfer allowed    |

These flags should not be turned on casually. They should depend on licence records.

---

## C. PPB premise licence

PPB’s portal supports new facility/premise licence applications, renewals, variation of issued licences, and download/printing of approved licences. The portal instructions also show that for a hospital premise, a current medical council licence may be attached; after approval, PPB inspection and final review occur before the licence is downloaded and displayed. ([practice.pharmacyboardkenya.org][3])

| Field                            |                    Type |        Required? | Notes                                                           |
| -------------------------------- | ----------------------: | ---------------: | --------------------------------------------------------------- |
| PPB premise licence number       |                    Text | Yes for pharmacy | Main identifier                                                 |
| PPB application/reference number |                    Text |      Recommended | Tracks pending application                                      |
| Premise category                 |                Dropdown |              Yes | Retail pharmacy, wholesale, hospital pharmacy, warehouse, etc.  |
| Premise name on licence          |                    Text |              Yes | Must match document                                             |
| Branch linked                    |             Branch link |              Yes | Licence is branch-specific                                      |
| Licence issue date               |                    Date |              Yes |                                                                 |
| Licence expiry date              |                    Date |              Yes |                                                                 |
| Licence status                   |                Dropdown |              Yes | Pending, active, renewal submitted, expired, suspended, revoked |
| Superintendent                   | Staff/professional link |              Yes | Responsible pharmacist/technologist                             |
| Regional PPB office              |           Dropdown/text |         Optional | Useful for follow-up                                            |
| Inspection date                  |                    Date |         Optional |                                                                 |
| Inspection outcome               |                Dropdown |         Optional | Passed, failed, conditional, pending                            |
| Conditions from PPB              |                    Text |         Optional | Any restrictions or notes                                       |
| Licence document                 |             File upload |              Yes | Certificate                                                     |
| Payment receipt                  |             File upload |         Optional | Renewal evidence                                                |
| Last verification date           |                    Date |      Recommended |                                                                 |
| Verification method              |                Dropdown |      Recommended | PPB portal/manual/document                                      |
| Display confirmed                |                Checkbox |      Recommended | Confirms branch printed/displayed certificate                   |
| Renewal submitted date           |                    Date |         Optional |                                                                 |
| Renewal approved date            |                    Date |         Optional |                                                                 |

### PPB business rules

| Rule                                         | System behaviour                                                                           |
| -------------------------------------------- | ------------------------------------------------------------------------------------------ |
| Branch marked as pharmacy but no PPB licence | Show “non-compliant setup”                                                                 |
| PPB licence expired                          | Block prescription dispensing or require emergency override with owner/compliance approval |
| No superintendent linked                     | Block pharmacy activation                                                                  |
| Superintendent licence expired               | Warn and optionally block dispensing                                                       |
| Licence pending inspection                   | Allow setup, block live dispensing unless admin override                                   |
| PPB variation required                       | Trigger workflow when branch address, business name, ownership, or superintendent changes  |
| Hospital pharmacy                            | Require linked clinic/facility licence record where applicable                             |

---

## D. KMPDC facility licence

KMPDC states that health facility registration involves inspection by the County Health Management Team, online registration, prescribed fees, approval by the relevant committee, and issuance of a registration certificate. KMPDC also provides quick links to search registered practitioners and registered health facilities. ([kmpdc.go.ke][4])

| Field                              |         Type |      Required? | Notes                                                 |
| ---------------------------------- | -----------: | -------------: | ----------------------------------------------------- |
| KMPDC facility registration number |         Text | Yes for clinic |                                                       |
| Facility name on certificate       |         Text |            Yes |                                                       |
| Facility type                      |     Dropdown |            Yes | Clinic, medical centre, hospital, dental clinic, etc. |
| KEPH level                         |     Dropdown |    Recommended | Important for claims and service limits               |
| Branch linked                      |  Branch link |            Yes |                                                       |
| Ownership type                     |     Dropdown |            Yes | Private, public, faith-based, NGO, company-owned      |
| County inspection date             |         Date |       Optional |                                                       |
| Inspection team/office             |         Text |       Optional |                                                       |
| Inspection result                  |     Dropdown |       Optional | Passed, failed, conditional, pending                  |
| Licence/certificate issue date     |         Date |            Yes |                                                       |
| Licence/certificate expiry date    |         Date |            Yes |                                                       |
| Services approved                  | Multi-select |            Yes | Consultation, lab, maternity, dental, imaging, etc.   |
| Beds/capacity                      |       Number |  If applicable |                                                       |
| Facility administrator             |   Staff link |            Yes |                                                       |
| Medical director/clinical lead     |   Staff link |    Recommended |                                                       |
| Certificate document               |  File upload |            Yes |                                                       |
| Payment receipt                    |  File upload |       Optional |                                                       |
| Licence status                     |     Dropdown |            Yes | Pending, active, expired, suspended, revoked          |
| Last verified date                 |         Date |    Recommended |                                                       |
| Verification method                |     Dropdown |    Recommended | KMPDC portal/manual/document                          |

### KMPDC business rules

| Rule                                         | System behaviour                                         |
| -------------------------------------------- | -------------------------------------------------------- |
| Branch marked as clinic but no KMPDC licence | Block clinical activation                                |
| Facility licence expired                     | Block new clinical visits or require compliance override |
| Service not approved                         | Prevent billing/claiming for that service                |
| KEPH level missing                           | Warn claims officer before SHA/private insurer setup     |
| Inspection failed                            | Keep facility status as “not approved”                   |
| Certificate missing                          | Compliance dashboard shows incomplete file               |

---

## E. Superintendent pharmacist / pharmaceutical technologist

PPB’s practice portal uses registration/enrolment credentials and supports premise and practice licence processes. It also indicates that a superintendent’s renewal/approval comes before non-superintendent approvals for a premise. ([practice.pharmacyboardkenya.org][3])

| Field                             |        Type |   Required? | Notes                                       |
| --------------------------------- | ----------: | ----------: | ------------------------------------------- |
| Full name                         |        Text |         Yes |                                             |
| Professional category             |    Dropdown |         Yes | Pharmacist, pharmaceutical technologist     |
| PPB registration/enrolment number |        Text |         Yes |                                             |
| National ID/passport              |        Text |         Yes |                                             |
| Phone                             |       Phone |         Yes |                                             |
| Email                             |       Email | Recommended |                                             |
| Practising licence number         |        Text |         Yes |                                             |
| Practising licence issue date     |        Date |         Yes |                                             |
| Practising licence expiry date    |        Date |         Yes |                                             |
| Licence status                    |    Dropdown |         Yes | Active, expired, suspended, pending renewal |
| Superintendent flag               |     Boolean |         Yes |                                             |
| Branch assigned                   | Branch link |         Yes |                                             |
| Appointment date                  |        Date |         Yes |                                             |
| End date                          |        Date |    Optional |                                             |
| Appointment letter                | File upload | Recommended |                                             |
| PPB licence document              | File upload |         Yes |                                             |
| Last verified date                |        Date | Recommended |                                             |
| Verification method               |    Dropdown | Recommended |                                             |

### Superintendent rules

| Rule                                                | System behaviour                                                                  |
| --------------------------------------------------- | --------------------------------------------------------------------------------- |
| No active superintendent                            | Branch pharmacy compliance status becomes red                                     |
| Superintendent licence expiring                     | Alert owner/admin and superintendent                                              |
| Superintendent removed                              | Branch pharmacy module becomes pending until replacement approved                 |
| New superintendent assigned                         | Require appointment evidence and PPB variation/approval workflow where applicable |
| User is cashier only                                | Cannot approve prescription dispensing                                            |
| User is pharmacist/technologist but licence expired | Cannot perform regulated approval unless override is configured                   |

---

## F. Clinician professional licence

For clinics, professional staff may include doctors, dentists, clinical officers, nurses, pharmacists, lab personnel, radiographers, nutritionists, counsellors, and others. The module should not assume every clinician is licensed by KMPDC. Clinical officers and nurses have their own registers. The Clinical Officers Council licence-status page states that all clinical officers practising in Kenya must be on the COC Retention Register. The Nursing Council of Kenya licence-status page states that all nurses practising in Kenya must be on the NCK Retention Register and provides licence verification. ([portal.clinicalofficerscouncil.org][5])

| Field                        |              Type |                                       Required? | Notes                                                                        |
| ---------------------------- | ----------------: | ----------------------------------------------: | ---------------------------------------------------------------------------- |
| Full name                    |              Text |                                             Yes |                                                                              |
| Staff number                 |              Text |                                             Yes |                                                                              |
| Cadre                        |          Dropdown |                                             Yes | Doctor, dentist, clinical officer, nurse, pharmacist, lab technologist, etc. |
| Regulatory council           |          Dropdown |                                             Yes | KMPDC, COC, NCK, PPB, KMLTTB, etc.                                           |
| Registration number          |              Text |                                             Yes |                                                                              |
| Practising licence number    |              Text |                                             Yes |                                                                              |
| Licence issue date           |              Date |                                             Yes |                                                                              |
| Licence expiry date          |              Date |                                             Yes |                                                                              |
| Scope/specialty              | Text/multi-select |                                     Recommended |                                                                              |
| Facility/branch assigned     |        Multi-link |                                             Yes |                                                                              |
| Employment/engagement type   |          Dropdown |                                             Yes | Full-time, part-time, visiting, locum                                        |
| Professional indemnity cover |         File/date | Recommended, required for some cadres/contracts |                                                                              |
| Licence document             |       File upload |                                             Yes |                                                                              |
| ID/passport                  |  File upload/text |                                     Recommended |                                                                              |
| Last verified date           |              Date |                                     Recommended |                                                                              |
| Verification source          |     Dropdown/link |                                     Recommended |                                                                              |
| Status                       |          Dropdown |                                             Yes | Active, expired, suspended, resigned, blocked                                |

### Clinician licence rules

| Rule                          | System behaviour                                                  |
| ----------------------------- | ----------------------------------------------------------------- |
| Licence expired               | Clinician cannot sign notes, prescriptions, lab orders, or claims |
| Cadre not allowed for service | Block activity or require senior approval                         |
| Missing professional council  | Staff cannot be activated as clinician                            |
| Visiting consultant           | Must have valid licence and approved branch assignment            |
| Staff leaves                  | Disable login, preserve historical records                        |
| Licence pending renewal       | Warn but allow only if business policy permits                    |

---

## G. SHA and private insurer contracts

SHA regulations state that the Authority pays claims to empanelled and contracted healthcare providers or facilities, continuously empanels licensed and certified providers/facilities, and onboards contracted providers into the Centralized Digital Platform. They also require contracted providers to maintain beneficiary records in accessible format and have equipment such as computers/mobile phones with working internet connection for beneficiary verification. ([Kenya Law][6])

| Field                       |             Type |               Required? | Notes                                                            |
| --------------------------- | ---------------: | ----------------------: | ---------------------------------------------------------------- |
| Payer type                  |         Dropdown |                     Yes | SHA, private insurer, employer, corporate scheme                 |
| Payer name                  |             Text |                     Yes |                                                                  |
| Contract number             |             Text |                     Yes |                                                                  |
| Provider/facility code      |             Text |                     Yes |                                                                  |
| Branch/facility linked      |      Branch link |                     Yes |                                                                  |
| KMPDC facility linked       |     Licence link | Yes for clinical claims |                                                                  |
| Contract start date         |             Date |                     Yes |                                                                  |
| Contract end date           |             Date |                     Yes |                                                                  |
| Contract status             |         Dropdown |                     Yes | Draft, active, suspended, terminated, expired                    |
| Approved benefit packages   |     Multi-select |                     Yes | Outpatient, inpatient, maternity, dental, optical, chronic, etc. |
| Service limits              | Structured table |             Recommended | By service/category                                              |
| Tariff schedule             |       File/table |                     Yes |                                                                  |
| Pre-authorisation required  |      Rules table |                     Yes |                                                                  |
| Claim submission method     |         Dropdown |                     Yes | Portal, API, email, manual                                       |
| Claim deadline rules        |      Rules table |             Recommended |                                                                  |
| Payment bank account        |       Structured |                     Yes |                                                                  |
| Contact person              |             Text |             Recommended |                                                                  |
| Contract document           |      File upload |                     Yes |                                                                  |
| Empanelment/approval letter |      File upload |             Yes for SHA |                                                                  |
| Last verification date      |             Date |             Recommended |                                                                  |

### Contract rules

| Rule                           | System behaviour                             |
| ------------------------------ | -------------------------------------------- |
| No active SHA/private contract | Cannot submit claims to that payer           |
| Contract expired               | Block claim submission                       |
| Service outside contract       | Warn or block claim                          |
| Facility licence expired       | Block claim submission                       |
| Professional licence expired   | Block provider-signed claim                  |
| Tariff missing                 | Claim cannot be priced automatically         |
| Pre-authorisation required     | Claim cannot proceed without approval number |
| Contract terminated/suspended  | Stop eligibility checks and claims           |

---

## H. ODPC / data protection registration

Health facilities and pharmacies process sensitive personal and health data. ODPC defines a data controller as an entity that collects and determines how personal data is used, and a data processor as an entity processing data on behalf of a controller. Kenya’s Data Protection registration regulations list “health administration and provision of patient care” among processing purposes requiring registration as a data controller or processor. ([ODPC][7])

Even though ODPC is not in your original table, it should be included in this module for any clinic/pharmacy system handling patient data.

| Field                           |          Type |                             Required? | Notes                                               |
| ------------------------------- | ------------: | ------------------------------------: | --------------------------------------------------- |
| ODPC registration type          |      Dropdown | Recommended/required where applicable | Controller, processor, both                         |
| ODPC certificate number         |          Text |                           Recommended |                                                     |
| Registration issue date         |          Date |                           Recommended |                                                     |
| Registration expiry date        |          Date |                           Recommended |                                                     |
| Data protection officer/contact | Staff/contact |                           Recommended |                                                     |
| Privacy notice document         |     File/link |                           Recommended |                                                     |
| Data processing purposes        |  Multi-select |                                   Yes | Patient care, billing, claims, marketing, analytics |
| Sensitive data processed        |  Multi-select |                                   Yes | Health, biometrics, ID, financial, insurance        |
| Third-party processors          |         Table |                           Recommended | Cloud host, SMS provider, claims processor          |
| Cross-border transfer           |        Yes/no |                           Recommended | Where cloud/SMS/payment providers are outside Kenya |
| Certificate document            |   File upload |                           Recommended |                                                     |
| Breach contact workflow         |        Config |                           Recommended |                                                     |

---

# 5. Recommended extra compliance records

The user table is correct, but the system should also support configurable extra permits because counties and facility types differ.

| Record                        | Applies to                        | Why useful                            |
| ----------------------------- | --------------------------------- | ------------------------------------- |
| County single business permit | Most businesses                   | Local business operation              |
| Public health permit          | Clinics/food-adjacent premises    | County public health compliance       |
| Fire safety certificate       | Clinics, larger facilities, malls | Inspection/compliance                 |
| Waste management contract     | Clinics, labs, pharmacies         | Medical/pharmaceutical waste handling |
| Radiation licence             | Imaging facilities                | X-ray/CT/radiology                    |
| Lab licence/accreditation     | Labs                              | Lab service legitimacy                |
| Signage permit                | Some counties                     | Outdoor branding                      |
| Lease agreement               | All branches                      | Proof of premises                     |
| Professional indemnity cover  | Clinicians/facilities             | Claims and liability                  |
| Insurance cover               | Facility                          | Public/professional liability         |

These should be stored using a generic **Licence/Permit Type** configuration so the product can adapt to Nairobi, Mombasa, Kisumu, Nakuru, Eldoret, county governments, chains, and different facility levels without rewriting code.

---

# 6. Screens required

## Screen 1: Organisation profile

Shows the parent legal entity.

Sections:

1. Legal identity
2. Owners/directors
3. Tax/KRA/eTIMS readiness
4. Bank and payment accounts
5. Documents
6. Branches
7. Compliance score

Key actions:

| Button/action             | Result                              |
| ------------------------- | ----------------------------------- |
| Add business registration | Opens legal entity form             |
| Upload certificate        | Adds document to compliance file    |
| Add owner/director        | Adds accountable person             |
| Add branch                | Creates outlet/facility             |
| Verify details            | Adds verification log               |
| Generate compliance pack  | Exports documents and status report |

---

## Screen 2: Branch/facility profile

This is the operational compliance screen.

Sections:

1. Branch identity
2. Location
3. Services enabled
4. Licences
5. Responsible professionals
6. SHA/private contracts
7. Operating hours
8. Devices/payment/tax setup
9. Compliance status

The top of the screen should show:

```text
Branch: AfyaCare Rongai
Status: Active
Compliance: 86%
Pharmacy: Active
Clinic: Active
Claims: Warning - SHA contract expires in 27 days
Next action: Renew SHA contract
```

---

## Screen 3: Licence register

A searchable list of all licences.

Filters:

| Filter             | Examples                               |
| ------------------ | -------------------------------------- |
| Licence type       | PPB, KMPDC, ODPC, SHA, county permit   |
| Status             | Active, expiring, expired, suspended   |
| Branch             | Rongai, Kitengela, CBD                 |
| Expiry window      | 7, 14, 30, 60, 90 days                 |
| Responsible person | Superintendent, facility administrator |
| Document missing   | Yes/no                                 |

Columns:

| Column             |
| ------------------ |
| Licence type       |
| Licence number     |
| Branch             |
| Responsible person |
| Issue date         |
| Expiry date        |
| Days to expiry     |
| Status             |
| Last verified      |
| Next action        |

---

## Screen 4: Professional register

A searchable list of all regulated staff.

Columns:

| Column                    |
| ------------------------- |
| Name                      |
| Cadre                     |
| Council                   |
| Registration number       |
| Practising licence number |
| Branch                    |
| Role                      |
| Expiry date               |
| Status                    |
| Last verified             |
| Actions                   |

Actions:

| Action                    | Result                                    |
| ------------------------- | ----------------------------------------- |
| Assign to branch          | Links professional to branch              |
| Mark as superintendent    | Starts superintendent assignment workflow |
| Upload renewed licence    | Updates document and expiry               |
| Suspend system privileges | Disables clinical/pharmacy permissions    |
| Verify licence            | Records verification source and date      |

---

## Screen 5: Payer/contract register

For SHA and private insurers.

Columns:

| Column           |
| ---------------- |
| Payer            |
| Contract number  |
| Branch/facility  |
| Provider code    |
| Start date       |
| End date         |
| Services covered |
| Claim method     |
| Status           |
| Expiry alert     |

---

## Screen 6: Compliance dashboard

This should be the owner’s main view.

Widgets:

| Widget                    | Shows                                           |
| ------------------------- | ----------------------------------------------- |
| Branch compliance summary | Green/yellow/red status per branch              |
| Expiring licences         | Next 90 days                                    |
| Missing documents         | Missing certificates/receipts/contracts         |
| Expired professionals     | Staff who should not practise                   |
| Claim blockers            | Missing SHA/private contract requirements       |
| Pharmacy blockers         | Missing PPB/superintendent requirements         |
| Clinic blockers           | Missing KMPDC/professional licence requirements |
| Verification overdue      | Records not verified recently                   |

---

# 7. Licence status model

Every licence, permit, contract, or professional credential should use a common lifecycle.

```text
Draft
Pending submission
Submitted
Pending inspection
Approved / Active
Renewal due soon
Renewal submitted
Expired
Suspended
Revoked
Archived
```

## Status logic

| Status             | Meaning                             |
| ------------------ | ----------------------------------- |
| Draft              | Record being prepared               |
| Pending submission | Ready but not yet submitted         |
| Submitted          | Submitted to regulator/payer        |
| Pending inspection | Awaiting physical/remote inspection |
| Active             | Valid and usable                    |
| Renewal due soon   | Still valid but nearing expiry      |
| Renewal submitted  | Renewal in progress                 |
| Expired            | Validity date passed                |
| Suspended          | Temporarily not usable              |
| Revoked            | Cancelled by authority              |
| Archived           | Historical, not active              |

---

# 8. Alerts and reminders

## Alert schedule

Default alert windows:

| Time before expiry | Alert target                                    |
| ------------------ | ----------------------------------------------- |
| 90 days            | Owner, compliance officer                       |
| 60 days            | Owner, compliance officer, branch manager       |
| 30 days            | Owner, branch manager, responsible professional |
| 14 days            | Escalate to senior admin                        |
| 7 days             | Daily reminders                                 |
| Expiry day         | Critical alert                                  |
| After expiry       | Block or restrict affected workflow             |

## Alert channels

| Channel             | Use                    |
| ------------------- | ---------------------- |
| In-app notification | All users              |
| Email               | Owners/admins          |
| SMS/WhatsApp        | Critical expiry alerts |
| Dashboard badge     | Compliance dashboard   |
| Task assignment     | Renewal workflow       |

## Example alerts

```text
PPB premise licence for AfyaCare Rongai expires in 30 days.
Affected workflows: prescription dispensing, internet pharmacy orders.
Required action: upload renewal receipt or updated licence.
```

```text
Dr. Jane Mwangi’s practising licence expires in 14 days.
Affected workflows: consultation notes, prescriptions, SHA/private claims.
```

```text
SHA contract for AfyaCare Kitengela expires in 7 days.
Affected workflows: SHA eligibility checks, pre-authorisations, claim submission.
```

---

# 9. Workflow: setting up a new pharmacy branch

```text
1. Create legal entity
2. Add branch
3. Mark branch type as pharmacy
4. Upload business registration and KRA PIN
5. Add PPB premise application/licence
6. Add superintendent pharmacist/technologist
7. Upload superintendent practising licence
8. Add county/local permits
9. Record inspection status
10. Approve branch as pharmacy-active
11. Enable pharmacy POS and dispensing workflows
```

## Workflow controls

| Step                    | System control                                             |
| ----------------------- | ---------------------------------------------------------- |
| Branch marked pharmacy  | Requires PPB licence workflow                              |
| Superintendent added    | Requires PPB registration/enrolment and practising licence |
| Licence active          | Enables pharmacy stock and dispensing                      |
| Licence expired         | Blocks/restricts regulated dispensing                      |
| New superintendent      | Triggers variation/approval task                           |
| Online pharmacy enabled | Requires internet pharmacy compliance checklist            |

---

# 10. Workflow: setting up a new clinic

```text
1. Create legal entity
2. Add branch/facility
3. Mark branch type as clinic
4. Add KMPDC facility registration
5. Add facility type and KEPH level
6. Add facility administrator/clinical lead
7. Add licensed clinicians
8. Upload professional licences
9. Add approved services
10. Add SHA/private contracts if needed
11. Activate clinic workflows
```

## Workflow controls

| Step                         | System control                                  |
| ---------------------------- | ----------------------------------------------- |
| Branch marked clinic         | Requires KMPDC licence                          |
| Consultation service enabled | Requires at least one active licensed clinician |
| Lab service enabled          | Requires lab licence/config where applicable    |
| Claim submission enabled     | Requires active payer contract                  |
| Facility licence expired     | Blocks/restricts clinical and claims workflows  |

---

# 11. Workflow: setting up SHA/private insurer claims

```text
1. Confirm branch has active facility licence
2. Add payer
3. Add contract number/provider code
4. Upload contract/empanelment letter
5. Add tariff schedule
6. Configure benefit packages
7. Configure pre-authorisation rules
8. Configure claim submission method
9. Map services and drugs to payer tariffs
10. Activate claims for that branch
```

## Claim blockers

| Blocker                        | Reason                              |
| ------------------------------ | ----------------------------------- |
| No active facility licence     | Facility may not be claim-eligible  |
| No active contract             | Payer should not receive claim      |
| No provider code               | Claim cannot be identified          |
| No tariff table                | System cannot price claim correctly |
| Clinician licence expired      | Claim may be rejected               |
| Service outside approved scope | Claim may be fraudulent or invalid  |
| Pre-authorisation missing      | Claim may be rejected               |

---

# 12. Permissions and access control

## Recommended permissions

| Permission                | Owner |        Admin | Branch manager |            Pharmacist |             Clinician |     Claims officer | Auditor |
| ------------------------- | ----: | -----------: | -------------: | --------------------: | --------------------: | -----------------: | ------: |
| View organisation         |   Yes |          Yes |        Limited |               Limited |               Limited |            Limited |     Yes |
| Edit organisation         |   Yes |          Yes |             No |                    No |                    No |                 No |      No |
| Add branch                |   Yes |          Yes |             No |                    No |                    No |                 No |      No |
| Edit branch               |   Yes |          Yes |        Limited |                    No |                    No |                 No |      No |
| Upload licence            |   Yes |          Yes |            Yes | Own/professional only | Own/professional only | Contract docs only |      No |
| Approve licence record    |   Yes |          Yes |             No |                    No |                    No |                 No |      No |
| Assign superintendent     |   Yes |          Yes |             No |                    No |                    No |                 No |      No |
| Assign clinician          |   Yes |          Yes |        Limited |                    No |                    No |                 No |      No |
| Add payer contract        |   Yes |          Yes |             No |                    No |                    No |                Yes |      No |
| View audit log            |   Yes |          Yes |             No |                    No |                    No |                 No |     Yes |
| Override compliance block |   Yes | Configurable |             No |                    No |                    No |                 No |      No |

## Important security rule

No user should be able to both:

1. Upload a licence document, and
2. Approve the same licence as verified,

unless they are a high-trust owner/admin and the action is clearly logged.

---

# 13. Document management

Each uploaded document should store:

| Metadata            | Why                                                |
| ------------------- | -------------------------------------------------- |
| Document type       | PPB licence, KMPDC certificate, SHA contract, etc. |
| Linked record       | Branch, licence, professional, contract            |
| File name           | Basic reference                                    |
| File hash           | Detect tampering/replacement                       |
| Uploaded by         | Audit                                              |
| Uploaded date       | Audit                                              |
| Version number      | Renewal history                                    |
| Issue date          | Compliance                                         |
| Expiry date         | Alerts                                             |
| Verification status | Draft, verified, rejected                          |
| Verified by         | Accountability                                     |
| Verification date   | Audit                                              |
| Notes               | Inspection comments, conditions                    |
| Visibility level    | Sensitive/non-sensitive                            |

Documents should never be overwritten silently. A renewed licence should create a new version.

---

# 14. Compliance scoring

The dashboard can calculate compliance percentage per branch.

## Example scoring model

| Requirement                                     | Weight |
| ----------------------------------------------- | -----: |
| Business registration present                   |    10% |
| Branch profile complete                         |    10% |
| KRA PIN/eTIMS setup present                     |    10% |
| PPB licence active, if pharmacy                 |    20% |
| Superintendent active, if pharmacy              |    15% |
| KMPDC licence active, if clinic                 |    20% |
| Professional licences active                    |    10% |
| SHA/private contracts active, if claims enabled |    10% |
| ODPC/data protection record present             |     5% |
| No expired critical documents                   |    10% |

Because requirements differ by business type, the denominator should change by branch type. A retail-only shop should not be penalized for missing a PPB licence unless it is configured to sell/dispense medicines.

---

# 15. Rules engine

The module should expose compliance rules to other modules.

## Example rules

```text
RULE: Pharmacy dispensing allowed
IF branch.can_dispense_prescription_medicines = true
AND branch.PPB_premise_licence.status = active
AND branch.superintendent.status = active
AND superintendent.practising_licence.status = active
THEN allow prescription dispensing
ELSE block or require approved override
```

```text
RULE: Clinic consultation allowed
IF branch.can_run_clinic_consultations = true
AND branch.KMPDC_facility_licence.status = active
AND clinician.practising_licence.status = active
THEN allow clinician to sign consultation
ELSE block signing
```

```text
RULE: Claim submission allowed
IF payer_contract.status = active
AND facility_licence.status = active
AND service is covered
AND provider_code exists
AND required pre_authorisation exists where applicable
THEN allow claim submission
ELSE return claim blocker list
```

```text
RULE: Online pharmacy allowed
IF branch.PPB_premise_licence.status = active
AND superintendent.status = active
AND internet_pharmacy_compliance_checklist = complete
THEN allow online medicine orders
ELSE online pharmacy disabled
```

---

# 16. Reports

## Compliance reports

| Report                           | Purpose                                   |
| -------------------------------- | ----------------------------------------- |
| Organisation compliance summary  | Owner overview                            |
| Branch compliance status         | See which outlets are safe to operate     |
| Expiring licences report         | Renewal planning                          |
| Expired licences report          | Risk management                           |
| Missing documents report         | File completion                           |
| Professional licence status      | HR/clinical/pharmacy compliance           |
| Superintendent assignment report | Pharmacy accountability                   |
| Facility licence report          | Clinic compliance                         |
| SHA/private contract report      | Claims readiness                          |
| Verification log report          | Audit evidence                            |
| Licence renewal history          | Shows previous certificates and timelines |
| Compliance override report       | Shows every time a block was bypassed     |

## Example branch compliance report

| Branch    | Type              | PPB    | KMPDC   | Superintendent | Clinicians | SHA      | Status  |
| --------- | ----------------- | ------ | ------- | -------------- | ---------- | -------- | ------- |
| Rongai    | Clinic + pharmacy | Active | Active  | Active         | 3 active   | Expiring | Warning |
| Kitengela | Pharmacy          | Active | N/A     | Expiring       | N/A        | N/A      | Warning |
| CBD       | Retail            | N/A    | N/A     | N/A            | N/A        | N/A      | Active  |
| Thika     | Clinic            | N/A    | Expired | N/A            | 2 active   | Active   | Blocked |

---

# 17. Database design

## Main tables

### `organisations`

| Field               |
| ------------------- |
| id                  |
| legal_name          |
| trading_name        |
| entity_type         |
| registration_number |
| kra_pin             |
| vat_status          |
| physical_address_id |
| postal_address      |
| phone               |
| email               |
| status              |
| created_at          |
| updated_at          |

### `organisation_owners`

| Field                |
| -------------------- |
| id                   |
| organisation_id      |
| full_name            |
| id_number            |
| role                 |
| ownership_percentage |
| phone                |
| email                |
| start_date           |
| end_date             |

### `branches`

| Field                  |
| ---------------------- |
| id                     |
| organisation_id        |
| branch_code            |
| branch_name            |
| branch_type            |
| ownership_model        |
| address_id             |
| gps_lat                |
| gps_lng                |
| phone                  |
| email                  |
| operating_hours_json   |
| branch_manager_user_id |
| status                 |
| opening_date           |
| closure_date           |

### `licence_types`

| Field                   |
| ----------------------- |
| id                      |
| name                    |
| regulator               |
| applies_to              |
| required_for_service    |
| default_validity_months |
| renewal_alert_days      |
| blocks_workflow         |
| configurable_rules_json |

### `licences`

| Field                 |
| --------------------- |
| id                    |
| organisation_id       |
| branch_id             |
| licence_type_id       |
| licence_number        |
| application_reference |
| issue_date            |
| expiry_date           |
| status                |
| regulator_status      |
| inspection_date       |
| inspection_result     |
| conditions            |
| verified_by           |
| verified_at           |
| verification_method   |
| notes                 |

### `professionals`

| Field                     |
| ------------------------- |
| id                        |
| full_name                 |
| cadre                     |
| council                   |
| registration_number       |
| practising_licence_number |
| licence_issue_date        |
| licence_expiry_date       |
| status                    |
| phone                     |
| email                     |
| id_number                 |
| last_verified_at          |

### `branch_professionals`

| Field                   |
| ----------------------- |
| id                      |
| branch_id               |
| professional_id         |
| role_at_branch          |
| is_superintendent       |
| is_clinical_lead        |
| start_date              |
| end_date                |
| appointment_document_id |
| status                  |

### `payer_contracts`

| Field                   |
| ----------------------- |
| id                      |
| branch_id               |
| payer_type              |
| payer_name              |
| contract_number         |
| provider_code           |
| start_date              |
| end_date                |
| status                  |
| covered_services_json   |
| tariff_schedule_id      |
| claim_submission_method |
| preauth_rules_json      |
| payment_account_id      |

### `documents`

| Field              |
| ------------------ |
| id                 |
| linked_entity_type |
| linked_entity_id   |
| document_type      |
| file_url           |
| file_hash          |
| version            |
| issue_date         |
| expiry_date        |
| uploaded_by        |
| uploaded_at        |
| verified_by        |
| verified_at        |
| status             |
| notes              |

### `compliance_alerts`

| Field              |
| ------------------ |
| id                 |
| linked_entity_type |
| linked_entity_id   |
| branch_id          |
| alert_type         |
| severity           |
| message            |
| due_date           |
| status             |
| assigned_to        |
| escalated_to       |
| created_at         |
| resolved_at        |

### `verification_logs`

| Field                |
| -------------------- |
| id                   |
| entity_type          |
| entity_id            |
| verification_source  |
| verification_result  |
| verified_by          |
| verified_at          |
| notes                |
| evidence_document_id |

---

# 18. API design

## Internal API endpoints

| Endpoint                                  | Purpose                          |
| ----------------------------------------- | -------------------------------- |
| `POST /organisations`                     | Create legal entity              |
| `GET /organisations/{id}`                 | View organisation                |
| `POST /organisations/{id}/branches`       | Add branch                       |
| `POST /branches/{id}/licences`            | Add licence                      |
| `POST /branches/{id}/professionals`       | Assign professional              |
| `POST /licences/{id}/verify`              | Mark licence verified            |
| `POST /licences/{id}/renewal`             | Start renewal                    |
| `POST /payer-contracts`                   | Add SHA/private insurer contract |
| `GET /branches/{id}/compliance-status`    | Return compliance state          |
| `GET /branches/{id}/workflow-permissions` | Return allowed/blocked workflows |
| `GET /compliance/alerts`                  | List alerts                      |
| `POST /documents`                         | Upload document                  |

## Compliance response example

```json
{
  "branch_id": "BR-001",
  "branch_name": "AfyaCare Rongai",
  "overall_status": "warning",
  "services": {
    "retail_sales": "allowed",
    "otc_sales": "allowed",
    "prescription_dispensing": "allowed",
    "clinic_consultation": "allowed",
    "sha_claims": "warning"
  },
  "blockers": [],
  "warnings": [
    {
      "type": "contract_expiry",
      "message": "SHA contract expires in 27 days",
      "action_required": "Upload renewed contract or renewal evidence"
    }
  ]
}
```

---

# 19. Integration points

## Current/practical integrations

| System            | Integration approach                                                |
| ----------------- | ------------------------------------------------------------------- |
| BRS/eCitizen      | Manual upload and verification log unless official API is available |
| PPB portal        | Manual upload/verification log unless official API is available     |
| KMPDC portal      | Manual lookup/verification log unless official API is available     |
| COC/NCK registers | Manual lookup/verification log                                      |
| SHA portal        | Contract/provider code storage; future API adapter                  |
| ODPC portal       | Registration certificate storage                                    |
| eTIMS             | Uses organisation KRA PIN and branch invoice configuration          |
| M-Pesa            | Uses branch Till/Paybill/payment account                            |
| Private insurers  | Contract/tariff/preauth/claim configuration                         |

## Design principle

Do not build the system assuming every regulator has a clean public API. Build with:

1. Manual document upload
2. Verification log
3. Source URL/reference
4. Last verified date
5. API adapter later

This makes the system usable immediately and future-proof.

---

# 20. Acceptance criteria

The module is usable when it passes these tests:

| Test                                | Expected result                                                                            |
| ----------------------------------- | ------------------------------------------------------------------------------------------ |
| Add a registered business           | Organisation profile created with registration, KRA PIN, owners, and documents             |
| Add a pharmacy branch               | System requires PPB licence and superintendent before pharmacy activation                  |
| Add a clinic branch                 | System requires KMPDC licence before clinic activation                                     |
| Add a clinician                     | System requires professional council, registration number, licence number, and expiry date |
| Add SHA contract                    | System links contract to facility, provider code, tariffs, and approved services           |
| Licence expiring                    | System sends alerts at configured intervals                                                |
| Licence expired                     | System blocks or restricts affected workflows                                              |
| Upload renewed licence              | System keeps old document, adds new version, updates expiry                                |
| Remove superintendent               | Pharmacy branch becomes non-compliant until replacement is added                           |
| Attempt claim with expired contract | Claim submission is blocked                                                                |
| Auditor opens branch file           | Auditor can see licence documents, verification logs, expiry history, and overrides        |
| Owner views dashboard               | Owner sees all branches and compliance status at a glance                                  |

---

# 21. MVP versus later versions

## MVP

Build these first:

| Feature                       | Reason                          |
| ----------------------------- | ------------------------------- |
| Organisation profile          | Foundation                      |
| Branch profile                | Multi-outlet support            |
| Business registration storage | Owner accountability            |
| PPB licence storage           | Pharmacy compliance             |
| KMPDC licence storage         | Clinic compliance               |
| Professional licence storage  | Staff accountability            |
| Superintendent assignment     | Pharmacy control                |
| SHA/private contract storage  | Claims eligibility              |
| Document uploads              | Evidence                        |
| Expiry alerts                 | Avoid accidental non-compliance |
| Compliance dashboard          | Owner visibility                |
| Workflow blocking rules       | Prevent illegal use             |

## Version 2

Add:

| Feature                           | Reason                             |
| --------------------------------- | ---------------------------------- |
| Regulator verification links      | Faster validation                  |
| Automated licence renewal tasks   | Better compliance workflow         |
| Digital signatures/approval chain | Stronger audit                     |
| Compliance score                  | Better owner dashboard             |
| Branch opening checklist          | Faster expansion                   |
| Inspection management             | Track regulator/county inspections |
| Contract/tariff versioning        | Better claims accuracy             |
| ODPC/data protection workflow     | Stronger privacy governance        |

## Version 3

Add:

| Feature                                 | Reason                              |
| --------------------------------------- | ----------------------------------- |
| Regulator API integrations              | Reduce manual work                  |
| Automated professional register checks  | Reduce expired-practitioner risk    |
| Multi-country licence framework         | Useful for expansion beyond Kenya   |
| AI compliance assistant                 | Suggest missing documents and risks |
| Franchise compliance portal             | Head office can monitor franchisees |
| Digital regulator-ready compliance pack | One-click audit export              |

---

# 22. Final product behaviour

The module should quietly control the rest of the software:

| Other module    | What Organisation & Licensing controls                                    |
| --------------- | ------------------------------------------------------------------------- |
| POS             | Whether branch can sell retail goods, OTC medicines, or pharmacy products |
| Pharmacy        | Whether prescription dispensing is allowed                                |
| EMR             | Whether clinic consultations are allowed                                  |
| Lab             | Whether lab services are allowed                                          |
| Claims          | Whether SHA/private insurer claims are allowed                            |
| eTIMS           | Which legal entity/KRA PIN/branch issues invoices                         |
| M-Pesa          | Which branch Till/Paybill receives money                                  |
| Online pharmacy | Whether internet medicine orders are allowed                              |
| Reporting       | Which branch/legal entity owns revenue and compliance risk                |
| User management | Which professionals can perform regulated actions                         |

The correct design is not simply “store licence files.” The module must **actively enforce licensing rules** so that the business cannot accidentally operate a pharmacy, clinic, claims process, or online medicine workflow without the required legal and professional foundation.

[1]: https://web.pharmacyboardkenya.org/download/guidelines-for-registration-and-licensing-of-premises/ "Guidelines for Registration and Licensing of premises - Pharmacy and Poisons Board"
[2]: https://brs.go.ke/ "Business Registration Service | Doing Business Made Easier"
[3]: https://practice.pharmacyboardkenya.org/ "PPB - Online Services Portal"
[4]: https://kmpdc.go.ke/registration-of-a-health-facility/ "Registration of a Health Facility – Kenya Medical Practitioners and Dentists Council"
[5]: https://portal.clinicalofficerscouncil.org/LicenseStatus "COC - Online Services Portal"
[6]: https://new.kenyalaw.org/akn/ke/act/ln/2024/49/eng%402024-03-08 "
      The Social Health Insurance Regulations
    \- Kenya Law"
[7]: https://www.odpc.go.ke/ "Office of the Data Protection Commissioner (ODPC)"
