# Module 3: Pharmacy Dispensing Module

This module is the **clinical and compliance heart** of the pharmacy/chemist system.

Modules 1 and 2 answer:

```text
Module 1: Is this branch and professional legally allowed to dispense?
Module 2: How is the sale billed, paid, invoiced, receipted, and reconciled?
Module 3: Was the medicine dispensed safely, legally, traceably, and by the right person?
```

For Kenya, this module must be designed around four realities:

1. **Pharmacy is regulated professional practice**, not ordinary retail. PPB regulates pharmacy personnel, premises, practices, sale, distribution, post-market surveillance, pharmacovigilance, and licit use of narcotic and psychotropic substances. The Pharmacy and Poisons Act requires practising pharmacists and pharmaceutical technologists to hold valid practising licences when engaging in dispensing, compounding, pharmaceutical care, or pharmaceutical services in Kenya. ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/1956/17/eng%402023-12-11))
2. **Prescription-only medicines must not be sold like normal retail goods.** The system must force prescription capture, prescriber details, patient details, pharmacist approval, and dispensing audit.
3. **Batch, expiry, traceability, and recalls are critical.** PPB’s authentication and traceability standards emphasize supply-chain integrity, patient safety, and traceability technologies to monitor health products across the supply chain. ([web.pharmacyboardkenya.org](https://web.pharmacyboardkenya.org/download/standards-for-authentication-and-traceability-of-health-products-and-technologies/))
4. **Controlled medicines require stricter handling.** Kenya’s Narcotic Drugs and Psychotropic Substances framework allows regulation of prescription, dispensing, supplying, sale, records, and conditions for narcotic and psychotropic substances. ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/1994/4/eng%402022-12-31))

---

# 1. Purpose of the module

The Pharmacy Dispensing Module should:

| Purpose                              | Practical meaning                                                            |
| ------------------------------------ | ---------------------------------------------------------------------------- |
| Validate prescriptions               | Ensure prescription-only medicines are linked to valid prescription evidence |
| Capture patient safety data          | Allergies, age, pregnancy, chronic disease, weight where needed              |
| Support pharmacist review            | Prevent cashier-only dispensing of restricted medicines                      |
| Control batch and expiry             | Ensure correct batch, expiry, recall readiness                               |
| Support partial dispensing           | Handle real Kenyan affordability and stock-availability realities            |
| Record substitutions                 | Brand/generic changes must be documented                                     |
| Track refills/repeats                | Chronic-care continuity                                                      |
| Print medicine labels                | Reduce medication-use errors                                                 |
| Support controlled medicine register | High-risk medicines require stricter accountability                          |
| Support pharmacovigilance            | Capture adverse drug reaction and poor-quality medicine reports              |
| Feed POS and inventory               | Dispensing creates billable stock movement                                   |
| Preserve audit trail                 | Who prescribed, reviewed, dispensed, sold, and from which batch              |

---

# 2. Core users

| User                        | Main actions                                                                        |
| --------------------------- | ----------------------------------------------------------------------------------- |
| Pharmacist                  | Reviews prescription, approves dispensing, substitutes, counsels, signs off         |
| Pharmaceutical technologist | Dispensing workflow depending on scope and branch policy                            |
| Cashier                     | Bills approved medicine items, receives payment                                     |
| Pharmacy assistant          | May prepare items but cannot approve restricted dispensing unless legally permitted |
| Superintendent              | Oversees branch pharmacy compliance and controlled registers                        |
| Clinician                   | Sends internal prescription from clinic EMR                                         |
| Patient/customer            | Provides prescription, receives medicine and label                                  |
| Branch manager              | Reviews stock, expiry, returns, discounts, operational issues                       |
| Auditor/compliance officer  | Reviews dispensing logs, controlled medicines, expiry, substitutions                |
| Owner                       | Views business and compliance reports                                               |

---

# 3. Relationship with modules 1 and 2

## Module 1 dependency: organisation and licensing

Before dispensing is allowed, the Pharmacy Dispensing Module should check:

| Required from Module 1                              | Why                                                      |
| --------------------------------------------------- | -------------------------------------------------------- |
| Active PPB premise licence                          | Branch must be licensed for pharmacy activity            |
| Active superintendent pharmacist/technologist       | Pharmacy supervision                                     |
| Active professional licence                         | Dispensing approval must be tied to a valid professional |
| Branch service permissions                          | Branch must be configured to dispense medicines          |
| Controlled medicine authorization, where applicable | Required for high-risk medicine categories               |
| ODPC/privacy setup                                  | Patient health data is sensitive                         |

## Module 2 dependency: POS and billing

After dispensing is approved, Module 2 handles:

| POS/billing function             | Pharmacy link                               |
| -------------------------------- | ------------------------------------------- |
| Sale line creation               | Dispensed medicine becomes billable item    |
| Price list                       | Retail, insurer, branch, chronic-care price |
| eTIMS invoice                    | Medicine sale is invoiced                   |
| M-Pesa/cash/card/insurer payment | Payment captured                            |
| Credit note/return               | Medicine return rules applied               |
| Shift close                      | Cashier accountability                      |
| Discount approval                | Prevent margin leakage on medicines         |

## Module 4 dependency: inventory

The dispensing module must depend heavily on stock data:

| Inventory data    | Why                                       |
| ----------------- | ----------------------------------------- |
| Batch number      | Recall and traceability                   |
| Expiry date       | Patient safety                            |
| Supplier          | Quality and accountability                |
| Quantity on hand  | Prevent false dispensing                  |
| Cost price        | Margin and replacement planning           |
| Storage condition | Cold-chain/high-risk handling             |
| Quarantine status | Prevent dispensing recalled/damaged stock |

---

# 4. Core pharmacy transaction types

| Transaction                  | Description                                     | POS involved? | Stock involved? | Patient involved? |
| ---------------------------- | ----------------------------------------------- | ------------: | --------------: | ----------------: |
| OTC sale                     | Non-prescription medicine sale                  |           Yes |             Yes |          Optional |
| Prescription dispense        | Prescription medicine dispensed                 |           Yes |             Yes |               Yes |
| Internal clinic prescription | Prescription from clinic EMR                    |           Yes |             Yes |               Yes |
| External prescription        | Patient uploads/brings prescription             |           Yes |             Yes |               Yes |
| Partial dispense             | Only part of prescribed quantity supplied       |           Yes |             Yes |               Yes |
| Refill/repeat dispense       | Repeat supply for chronic prescription          |           Yes |             Yes |               Yes |
| Substitution                 | Dispensed product differs from prescribed brand |           Yes |             Yes |               Yes |
| Controlled medicine dispense | Narcotic/psychotropic/high-risk item            |           Yes |             Yes |               Yes |
| Emergency supply/exception   | Limited exceptional dispense by policy          |           Yes |             Yes |               Yes |
| Return/reversal              | Dispense reversed or returned                   |           Yes |  Yes/quarantine |               Yes |
| Adverse event report         | Safety report after medicine use                |   No/optional |              No |               Yes |

---

# 5. Feature-by-feature design

## A. Prescription entry/upload

Prescription entry is required for prescription-only medicines. PPB’s pharmacy-practice guidance framework includes pharmacy practice, premises licensing, practice licences, pharmaceutical services, internet pharmacy services, and CPD; the Good Pharmacy Practice guideline page states that the guideline was developed to promote quality pharmaceutical care and is used by pharmacists, pharmaceutical technologists, pharmacy specialists, and other healthcare professionals providing pharmaceutical services. ([web.pharmacyboardkenya.org](https://web.pharmacyboardkenya.org/pharmacy-practice-guidelines/))

### Prescription sources

| Source                          | Example                                                  |
| ------------------------------- | -------------------------------------------------------- |
| Internal clinic EMR             | Doctor in same clinic prescribes digitally               |
| External paper prescription     | Patient brings handwritten/printed prescription          |
| External digital prescription   | WhatsApp/PDF/photo/email                                 |
| Refill prescription             | Previous prescription reused within allowed repeat rules |
| Telemedicine prescription       | From approved clinician/platform                         |
| Hospital discharge prescription | Patient discharged from hospital                         |
| Chronic-care prescription       | Hypertension, diabetes, asthma, epilepsy, etc.           |

### Prescription entry fields

| Field                                |                                   Required? | Notes                                                                      |
| ------------------------------------ | ------------------------------------------: | -------------------------------------------------------------------------- |
| Prescription number/reference        |                                         Yes | Internal or external                                                       |
| Prescription source                  |                                         Yes | Internal, external, telemedicine, refill                                   |
| Prescription date                    |                                         Yes | Prevent outdated prescriptions                                             |
| Prescription expiry/valid-until date |                                 Recommended | Especially for repeats                                                     |
| Patient                              |                                         Yes | Link to patient profile                                                    |
| Prescriber                           |                                         Yes | Name and professional details                                              |
| Facility/clinic                      |                                 Recommended | External prescription source                                               |
| Diagnosis/indication                 |                        Optional/recommended | Useful for safety checks                                                   |
| Uploaded document/photo              |          Required for external prescription | Image/PDF                                                                  |
| Prescription status                  |                                         Yes | Draft, pending review, approved, dispensed, partially dispensed, cancelled |
| Entered by                           |                                        Auto | Audit                                                                      |
| Reviewed by pharmacist               | Required before dispensing restricted items |                                                                            |
| Review notes                         |            Optional/required if issue found |                                                                            |
| Original retained?                   |                                    Optional | For paper prescription policy                                              |
| Repeat/refill allowed                |                                      Yes/no | Chronic care                                                               |
| Number of repeats                    |                                      Number | If applicable                                                              |

### Prescription item fields

| Field                   |      Required? | Notes                                  |
| ----------------------- | -------------: | -------------------------------------- |
| Medicine prescribed     |            Yes | Brand or generic                       |
| Strength                |            Yes | Example: 500 mg                        |
| Dosage form             |            Yes | Tablet, capsule, syrup, injection      |
| Dose                    |            Yes | Example: 1 tablet                      |
| Frequency               |            Yes | Example: twice daily                   |
| Duration                |            Yes | Example: 5 days                        |
| Quantity prescribed     |            Yes | Example: 10 tablets                    |
| Route                   |    Recommended | Oral, topical, IM, IV                  |
| Instructions            |            Yes | Before food, after food, etc.          |
| Refill quantity         |      If repeat | Chronic care                           |
| Substitution allowed    | Yes/no/unknown | Where captured                         |
| Priority                |       Optional | Urgent, routine                        |
| Clinical warning status |           Auto | Allergy/interactions/duplicate therapy |
| Dispensed item          |          Later | Actual product supplied                |
| Quantity dispensed      |          Later | May differ from prescribed             |
| Batch selected          |          Later | From stock                             |
| Pharmacist decision     |          Later | Approved, changed, rejected            |

---

## B. Prescriber details

Prescriber details provide audit and professional accountability.

### Prescriber fields

| Field                       |                      Required? | Notes                                   |
| --------------------------- | -----------------------------: | --------------------------------------- |
| Prescriber full name        |                            Yes | As written or selected                  |
| Professional cadre          |                            Yes | Doctor, dentist, clinical officer, etc. |
| Registration/licence number | Recommended/required by policy | Important for audit                     |
| Prescriber facility         |                    Recommended | Hospital/clinic name                    |
| Facility address/contact    |                       Optional | Useful for verification                 |
| Phone/email                 |                       Optional | For clarification                       |
| Signature/stamp present     |                         Yes/no | For scanned prescriptions               |
| Prescriber verified?        |                         Yes/no | Manual or registry lookup               |
| Verification date           |                       Optional | Audit                                   |
| Verification notes          |                       Optional | Example: called clinic                  |
| Internal prescriber user ID |                    If internal | Links to EMR clinician                  |

### Prescriber validation rules

| Rule                                          | System behaviour                                                |
| --------------------------------------------- | --------------------------------------------------------------- |
| Internal prescription                         | Prescriber must be active clinician in Module 1                 |
| External prescription missing prescriber name | Block until captured                                            |
| High-risk medicine                            | Require prescriber licence number or pharmacist override reason |
| Suspicious prescription                       | Mark as “requires verification”                                 |
| Repeat prescription                           | Ensure repeat period and remaining refills are valid            |
| Prescriber not verified                       | Allow or block depending on medicine risk category              |

---

## C. Patient profile

The patient profile is not only for marketing or receipts. It supports safe dispensing.

### Patient safety fields

| Field                      | Why it matters                                                         |
| -------------------------- | ---------------------------------------------------------------------- |
| Full name                  | Label and audit                                                        |
| Date of birth/age          | Paediatric/elderly dosing                                              |
| Sex                        | Clinical relevance                                                     |
| Weight                     | Paediatric and dose-sensitive medicines                                |
| Pregnancy status           | Pregnancy contraindications                                            |
| Breastfeeding status       | Medicine safety                                                        |
| Allergies                  | Prevent allergic reactions                                             |
| Chronic conditions         | Diabetes, hypertension, asthma, epilepsy, renal disease, liver disease |
| Current medicines          | Interaction and duplicate therapy checks                               |
| Previous adverse reactions | Safety                                                                 |
| Phone                      | Refill reminders and follow-up                                         |
| Guardian/caregiver         | Children/elderly                                                       |
| SHA/private insurer        | Billing/claims                                                         |
| Consent preferences        | SMS/WhatsApp/refill reminders                                          |
| Patient notes              | Special instructions                                                   |

### Patient profile rules

| Rule                                      | System behaviour                      |
| ----------------------------------------- | ------------------------------------- |
| Paediatric patient                        | Require age and preferably weight     |
| Pregnancy flag                            | Trigger pregnancy safety warnings     |
| Allergy recorded                          | Warn or block matching medicine/class |
| Chronic patient                           | Enable refill/repeat tracking         |
| Missing patient for prescription medicine | Block dispensing                      |
| Anonymous sale                            | Allowed only for configured OTC items |
| Consent missing                           | Do not send refill/marketing messages |

---

## D. Dosage instructions

Dosage instructions are central to patient safety and label printing.

### Dosage fields

| Field                   | Example                                           |
| ----------------------- | ------------------------------------------------- |
| Dose                    | 1 tablet                                          |
| Frequency               | Twice daily                                       |
| Duration                | 5 days                                            |
| Route                   | Oral                                              |
| Timing                  | After meals                                       |
| Quantity                | 10 tablets                                        |
| Special instructions    | Complete the course                               |
| Language                | English/Kiswahili/custom                          |
| Warning stickers        | May cause drowsiness, keep refrigerated           |
| Counselling notes       | Avoid alcohol, take with water                    |
| Missed dose instruction | Optional                                          |
| Storage instruction     | Store below 25°C, refrigerate, protect from light |

### Standard sig builder

The system should support a structured “sig” builder:

```text
Take [dose] by [route] [frequency] for [duration] [timing] [special instruction].
```

Example:

```text
Take 1 tablet by mouth twice daily for 5 days after meals. Complete the full course.
```

### Dosage rules

| Rule                          | System behaviour                          |
| ----------------------------- | ----------------------------------------- |
| Dose missing                  | Block label printing and dispensing       |
| Frequency missing             | Block pharmacist approval                 |
| Duration missing              | Warn/block depending on item              |
| Paediatric medicine           | Ask for weight if dose depends on weight  |
| Antibiotic                    | Prompt “complete full course” counselling |
| Sedating medicine             | Add drowsiness warning where configured   |
| Refrigerated medicine         | Add storage warning                       |
| External prescription unclear | Pharmacist marks “clarified” or rejects   |

---

## E. Partial dispensing

Partial dispensing is common where the patient cannot afford the full quantity, the pharmacy has limited stock, or the patient wants a few days’ supply.

### Partial dispense reasons

| Reason                    | Example                               |
| ------------------------- | ------------------------------------- |
| Patient affordability     | Patient buys 3 days instead of 7 days |
| Stock shortage            | Pharmacy has only 10 tablets          |
| Clinical decision         | Trial supply                          |
| Insurance limit           | Payer covers only part                |
| Controlled medicine limit | Restricted quantity                   |
| Patient preference        | Patient wants smaller quantity        |

### Partial dispensing fields

| Field                         | Notes                       |
| ----------------------------- | --------------------------- |
| Quantity prescribed           | From prescription           |
| Quantity dispensed now        | Actual supply               |
| Balance remaining             | Auto-calculated             |
| Reason for partial dispensing | Mandatory                   |
| Patient informed?             | Yes/no                      |
| Next expected refill date     | Optional                    |
| Balance expiry                | Date                        |
| Pharmacist approval           | Required                    |
| Label adjusted?               | Yes                         |
| Payment amount                | Based on quantity dispensed |
| Prescription status           | Partially dispensed         |

### Partial dispensing rules

| Rule                                    | System behaviour                                              |
| --------------------------------------- | ------------------------------------------------------------- |
| Dispensed quantity less than prescribed | Require reason                                                |
| Balance remaining                       | Create refill/balance record                                  |
| Antibiotic partial supply               | Warn strongly due to adherence risk                           |
| Controlled medicine partial             | Record in controlled register                                 |
| Patient returns for balance             | System retrieves original prescription and remaining quantity |
| Balance expired                         | Block or require pharmacist review                            |
| Stock arrives later                     | Notify patient if consent exists                              |

---

## F. Substitution

Substitution happens when the prescribed brand is unavailable, too expensive, or a generic equivalent is preferred.

### Substitution types

| Type                     | Example                                                   |
| ------------------------ | --------------------------------------------------------- |
| Brand to generic         | Branded amoxicillin to generic amoxicillin                |
| Generic to brand         | Generic prescribed, brand dispensed                       |
| Brand to brand           | Brand A replaced with Brand B                             |
| Strength substitution    | 500 mg x 1 replaced with 250 mg x 2                       |
| Dosage form substitution | Tablet to capsule, if appropriate                         |
| Therapeutic substitution | Different active ingredient; should be tightly controlled |

### Substitution fields

| Field                         |                              Required? |
| ----------------------------- | -------------------------------------: |
| Prescribed item               |                                    Yes |
| Dispensed item                |                                    Yes |
| Substitution type             |                                    Yes |
| Reason                        |                                    Yes |
| Equivalent strength confirmed |                                    Yes |
| Patient informed              |                                    Yes |
| Prescriber contacted          | For high-risk/therapeutic substitution |
| Pharmacist approval           |                                    Yes |
| Price difference              |                                   Auto |
| Notes                         |                            Recommended |

### Substitution reasons

| Reason                        |
| ----------------------------- |
| Prescribed brand out of stock |
| Generic equivalent available  |
| Patient affordability         |
| Insurance formulary           |
| Prescriber approved           |
| Medicine recalled/unavailable |
| Better pack size              |
| Clinical safety concern       |

### Substitution rules

| Rule                                | System behaviour                                                  |
| ----------------------------------- | ----------------------------------------------------------------- |
| Same active ingredient and strength | Allow pharmacist approval                                         |
| Different strength                  | Require dose equivalence check                                    |
| Different active ingredient         | Require prescriber approval or strict override                    |
| Controlled medicine                 | Restrict substitution                                             |
| Patient not informed                | Block final approval                                              |
| Substitution changes price          | Update POS before payment                                         |
| Substitution after payment          | Requires invoice correction/credit note if sale already finalized |

---

## G. Refill and repeat tracking

Refill tracking is essential for chronic care and repeat prescriptions.

### Refill fields

| Field                    | Notes                                 |
| ------------------------ | ------------------------------------- |
| Original prescription ID | Link                                  |
| Medicine                 | Chronic item                          |
| Total repeats allowed    | From prescription/policy              |
| Repeats used             | Auto                                  |
| Remaining repeats        | Auto                                  |
| Last dispensed date      | Auto                                  |
| Next refill date         | Auto                                  |
| Days supplied            | Auto/manual                           |
| Early refill reason      | Required if early                     |
| Late refill flag         | Useful for adherence                  |
| Patient contacted        | Optional                              |
| Refill reminder consent  | Required for SMS/WhatsApp             |
| Refill status            | Active, completed, expired, cancelled |

### Refill rules

| Rule                  | System behaviour                         |
| --------------------- | ---------------------------------------- |
| No repeat allowed     | Block repeat dispense                    |
| Repeat exhausted      | Require new prescription                 |
| Refill too early      | Warn/block unless pharmacist approves    |
| Prescription expired  | Block or require new prescription        |
| Chronic care patient  | Show adherence/refill timeline           |
| Medicine changed      | Close old refill plan and create new one |
| Patient missed refill | Generate reminder task if consent exists |

### Chronic care use cases

| Condition     | Useful features                                                                                                     |
| ------------- | ------------------------------------------------------------------------------------------------------------------- |
| Hypertension  | Monthly refill reminders, adherence history                                                                         |
| Diabetes      | Medicine and test strip refill tracking                                                                             |
| Asthma        | Inhaler refill monitoring                                                                                           |
| Epilepsy      | Missed refill alerts                                                                                                |
| HIV/TB        | Usually program-specific; system should support referral/program flags rather than mishandling restricted workflows |
| Mental health | Controlled/psychotropic caution                                                                                     |

---

## H. Controlled medicine register

Controlled medicines need special treatment because they carry higher diversion, abuse, dependency, and regulatory risk. Kenya’s narcotic and psychotropic framework allows regulation of prescribing, dispensing, supplying, quantities, conditions, records, and persons authorized to deal with such substances. ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/1994/4/eng%402022-12-31))

### Controlled medicine register fields

| Field                          |                        Required? |
| ------------------------------ | -------------------------------: |
| Register entry number          |                              Yes |
| Date/time                      |                              Yes |
| Branch                         |                              Yes |
| Medicine                       |                              Yes |
| Strength/form                  |                              Yes |
| Batch number                   |                              Yes |
| Opening balance                |                              Yes |
| Quantity received              |                       If receipt |
| Quantity dispensed             |                      If dispense |
| Quantity returned              |                        If return |
| Quantity destroyed/quarantined |                    If applicable |
| Closing balance                |                              Yes |
| Prescription reference         |                 Yes for dispense |
| Patient name/ID                |                              Yes |
| Prescriber details             |                              Yes |
| Pharmacist approving           |                              Yes |
| Witness/counter-signature      | Configurable for high-risk items |
| Reason/notes                   |                              Yes |
| Stock location                 |                              Yes |
| Adjustment reason              |                        Mandatory |
| Audit status                   |          Open/reconciled/flagged |

### Controlled medicine workflows

| Workflow             | Control                                             |
| -------------------- | --------------------------------------------------- |
| Receive stock        | Superintendent/pharmacist approval                  |
| Dispense             | Prescription + pharmacist approval + register entry |
| Return               | Quarantine or controlled return workflow            |
| Stock count          | Frequent reconciliation                             |
| Adjustment           | Requires reason and senior approval                 |
| Destruction/disposal | Requires formal record and witness                  |
| Transfer             | Requires origin and destination authorization       |
| Report               | Exportable controlled register                      |

### Controlled register rules

| Rule                          | System behaviour                               |
| ----------------------------- | ---------------------------------------------- |
| Controlled item scanned       | Trigger controlled workflow                    |
| No prescription               | Block                                          |
| No patient                    | Block                                          |
| No prescriber                 | Block                                          |
| No pharmacist approval        | Block                                          |
| Quantity exceeds prescription | Block                                          |
| Balance mismatch              | Flag discrepancy                               |
| Manual adjustment             | Require two-level approval                     |
| Register entry edit           | Do not overwrite; create correction entry      |
| Return                        | Do not return to normal stock without approval |
| Expired controlled stock      | Move to controlled quarantine                  |

---

## I. Batch and expiry selection

Batch and expiry selection supports recall, patient safety, and product quality.

### Batch selection fields

| Field              | Notes                       |
| ------------------ | --------------------------- |
| Product            | Medicine                    |
| Batch/lot number   | Supplier/manufacturer batch |
| Expiry date        | Mandatory                   |
| Supplier           | From GRN                    |
| Quantity available | Current stock               |
| Storage location   | Shelf/fridge/cabinet        |
| Cost price         | Margin                      |
| Selling price      | POS                         |
| Recall status      | Clear, recalled, suspended  |
| Quarantine status  | Sellable/quarantined        |
| GTIN/serial        | Traceability-ready          |
| Received date      | Stock age                   |
| FEFO rank          | First-expiry-first-out      |

### Batch selection rules

| Rule                           | System behaviour                             |
| ------------------------------ | -------------------------------------------- |
| Expired batch                  | Block dispensing                             |
| Recalled batch                 | Block dispensing                             |
| Quarantined batch              | Block dispensing                             |
| Near-expiry batch              | Warn and require patient-safety policy       |
| Multiple batches               | Recommend FEFO                               |
| Cashier selects non-FEFO batch | Require reason/permission                    |
| Batch missing for medicine     | Block if item is batch-controlled            |
| Stock insufficient             | Offer partial dispensing or alternate branch |
| Cold-chain item                | Require storage-status confirmation          |

### Recall use case

If PPB or supplier recalls batch `ABC123`, the system should answer:

```text
How many units are still in stock?
Which branches have them?
Which patients received them?
Who dispensed them?
When were they dispensed?
How do we contact affected patients?
Were any adverse reactions reported?
```

This is why batch is not optional for a serious pharmacy system.

---

## J. Label printing

Label printing reduces medication errors and improves patient understanding.

### Label types

| Label                     | Use                                        |
| ------------------------- | ------------------------------------------ |
| Medicine label            | Attached to medicine pack                  |
| Auxiliary warning label   | Drowsiness, refrigeration, complete course |
| Reconstitution label      | Syrups requiring water                     |
| Cold-chain label          | Keep refrigerated                          |
| Controlled medicine label | High-risk internal handling                |
| Patient bag label         | Multiple medicines in one bag              |
| Refill label              | Next refill date                           |
| Barcode label             | Internal stock/prescription tracking       |

### Medicine label fields

| Field                         |                                     Required? |
| ----------------------------- | --------------------------------------------: |
| Pharmacy name                 |                                           Yes |
| Branch contact                |                                           Yes |
| Patient name                  |                                           Yes |
| Medicine name                 |                                           Yes |
| Strength/form                 |                                           Yes |
| Dose                          |                                           Yes |
| Frequency                     |                                           Yes |
| Duration                      |                                           Yes |
| Route                         |                                   Recommended |
| Quantity dispensed            |                                           Yes |
| Date dispensed                |                                           Yes |
| Pharmacist/dispenser initials |                                   Recommended |
| Prescription reference        |                                   Recommended |
| Batch/expiry                  | Optional on patient label, mandatory in audit |
| Storage instruction           |                                   If relevant |
| Warning text                  |                                   If relevant |
| Refill date                   |                                   If relevant |

### Label printing rules

| Rule                                  | System behaviour                                      |
| ------------------------------------- | ----------------------------------------------------- |
| Missing dosage                        | Block label printing                                  |
| Missing patient for prescription item | Block                                                 |
| Paediatric patient                    | Print age/weight where configured                     |
| Multiple medicines                    | Print separate label per medicine                     |
| Partial dispense                      | Label quantity actually dispensed                     |
| Substitution                          | Label actual dispensed medicine, not prescribed brand |
| Language preference                   | Print English/Kiswahili/custom text                   |
| Reprint label                         | Log reprint reason and user                           |

---

## K. Clinical warnings

Clinical warnings improve safety but must be practical. A small Kenyan chemist may not afford advanced drug database licensing at first, so the system should support levels.

### Warning levels

| Level                 | Capability                                                                   |
| --------------------- | ---------------------------------------------------------------------------- |
| Level 1: Basic        | Allergy, age, pregnancy, duplicate medicine, expiry                          |
| Level 2: Intermediate | Drug class allergy, chronic disease warnings, therapeutic duplication        |
| Level 3: Advanced     | Drug-drug interactions, renal/hepatic dose warnings, paediatric dose checks  |
| Level 4: Integrated   | EMR/lab-linked warnings, eGFR-based dosing, pharmacogenomics where available |

### Warning categories

| Warning             | Example                           |
| ------------------- | --------------------------------- |
| Allergy             | Penicillin allergy + amoxicillin  |
| Age                 | Adult-only medicine for child     |
| Pregnancy           | Contraindicated medicine          |
| Breastfeeding       | Medicine caution                  |
| Duplicate therapy   | Two NSAIDs                        |
| Interaction         | Warfarin + interacting antibiotic |
| Dose range          | Paediatric dose too high          |
| Chronic disease     | NSAID caution in renal disease    |
| Route mismatch      | Injectable billed as oral         |
| Duration mismatch   | Antibiotic duration unusual       |
| Stock issue         | Expired/recalled batch            |
| Controlled medicine | High-risk approval required       |
| Refill too early    | Possible misuse/diversion         |
| Refill too late     | Poor adherence                    |

PPB’s pharmacovigilance page describes pharmacovigilance as detection, assessment, understanding, and prevention of adverse effects and drug-related problems; it also lists goals including rational and safe use of medicines and educating/informing patients. ([web.pharmacyboardkenya.org](https://web.pharmacyboardkenya.org/pharmacovigilance/))

### Warning actions

| Severity   | Behaviour                           |
| ---------- | ----------------------------------- |
| Info       | Show message                        |
| Warning    | Pharmacist must acknowledge         |
| High       | Requires pharmacist override reason |
| Critical   | Block unless senior override        |
| Regulatory | Block completely                    |

### Warning override fields

| Field                 |   Required? |
| --------------------- | ----------: |
| Warning type          |        Auto |
| Severity              |        Auto |
| User decision         |         Yes |
| Override reason       |         Yes |
| Pharmacist            |         Yes |
| Date/time             |         Yes |
| Patient counselled?   |      Yes/no |
| Prescriber contacted? | If required |
| Follow-up needed?     |    Optional |

---

## L. Pharmacist approval

Pharmacist approval prevents cashier-only dispensing.

### Approval triggers

| Trigger                              | Approval required                      |
| ------------------------------------ | -------------------------------------- |
| Prescription-only medicine           | Yes                                    |
| Controlled medicine                  | Yes, stricter                          |
| Substitution                         | Yes                                    |
| Partial dispensing                   | Yes                                    |
| Clinical warning                     | Yes                                    |
| Early refill                         | Yes                                    |
| Expired/near-expiry policy exception | Yes                                    |
| High discount on medicine            | Manager/pharmacist depending on policy |
| External prescription unclear        | Yes                                    |
| Telemedicine prescription            | Yes                                    |
| Patient allergy warning              | Yes                                    |
| Manual batch override                | Yes                                    |

### Approval states

| State                 | Meaning                                   |
| --------------------- | ----------------------------------------- |
| Pending review        | Pharmacist has not reviewed               |
| Needs clarification   | Prescription/patient issue                |
| Approved              | Ready for billing/dispensing              |
| Approved with changes | Substitution/partial/dosage clarification |
| Rejected              | Cannot dispense                           |
| Cancelled             | Prescription withdrawn                    |
| Dispensed             | Medicine supplied                         |
| Partially dispensed   | Balance remains                           |
| Reversed              | Dispense corrected/reversed               |

### Approval data captured

| Field                        | Notes                            |
| ---------------------------- | -------------------------------- |
| Pharmacist/professional ID   | From Module 1                    |
| Approval date/time           | Audit                            |
| Approval decision            | Approved/rejected/changed        |
| Reason                       | Mandatory for changes/rejections |
| Warnings reviewed            | Link                             |
| Patient counselled           | Yes/no                           |
| Prescriber contacted         | Yes/no                           |
| Prescription document viewed | Yes/no                           |
| Digital signature/PIN        | Recommended                      |
| Device/terminal              | Audit                            |
| Branch                       | Audit                            |

---

## M. Dispense audit

The audit trail must show exactly what happened.

### Dispense audit questions

The system must answer:

| Question                          | Why                         |
| --------------------------------- | --------------------------- |
| Who entered the prescription?     | Data-entry accountability   |
| Who reviewed it?                  | Professional accountability |
| Who approved it?                  | Compliance                  |
| Who billed it?                    | Financial audit             |
| Who received payment?             | Cash control                |
| Who handed over the medicine?     | Dispensing accountability   |
| What medicine was prescribed?     | Clinical audit              |
| What medicine was dispensed?      | Substitution audit          |
| Which batch and expiry?           | Recall                      |
| What quantity was dispensed?      | Stock and patient safety    |
| Was it partial?                   | Refill/balance              |
| Were warnings shown?              | Clinical safety             |
| Were warnings overridden?         | Risk management             |
| Was the patient counselled?       | Professional care           |
| Was label printed?                | Safety                      |
| Was receipt/eTIMS invoice issued? | Tax/commercial audit        |

### Audit events

| Event                   | Logged                    |
| ----------------------- | ------------------------- |
| Prescription created    | User, time, source        |
| Prescription uploaded   | File hash, user           |
| Prescription edited     | Old/new values            |
| Prescriber changed      | Old/new values and reason |
| Patient allergy updated | User/time                 |
| Warning generated       | Warning details           |
| Warning overridden      | Reason and pharmacist     |
| Substitution made       | From/to item and reason   |
| Partial dispense        | Quantity and reason       |
| Batch selected          | Batch/expiry/user         |
| Pharmacist approved     | Decision/time             |
| POS bill created        | Sale reference            |
| Payment completed       | Payment reference         |
| Label printed/reprinted | User/reason               |
| Dispense completed      | Final stock movement      |
| Return/reversal         | Reason and approver       |

---

# 6. Required screens

## Screen 1: Prescription intake

Used when receiving external prescriptions.

Sections:

| Section             | Contents                              |
| ------------------- | ------------------------------------- |
| Patient             | Search/create patient                 |
| Prescription source | External/internal/telemedicine/refill |
| Upload              | Photo/PDF/scanned document            |
| Prescriber          | Name, cadre, facility, licence number |
| Medicine entry      | Prescribed items                      |
| Notes               | Clarification, special instructions   |
| Status              | Pending pharmacist review             |

Key buttons:

```text
Upload prescription
Add medicine
Send to pharmacist review
Mark needs clarification
Reject prescription
```

---

## Screen 2: Dispensing queue

This is the pharmacist’s worklist.

Filters:

| Filter                       |
| ---------------------------- |
| Pending review               |
| Approved but not billed      |
| Paid but not handed over     |
| Partially dispensed          |
| Controlled medicine          |
| Clinical warning             |
| External prescription        |
| Internal clinic prescription |
| Refill due                   |
| Rejected/cancelled           |

Columns:

| Column              |
| ------------------- |
| Queue number        |
| Patient             |
| Prescription source |
| Prescriber          |
| Items               |
| Risk level          |
| Payment status      |
| Dispense status     |
| Waiting time        |
| Assigned pharmacist |

---

## Screen 3: Patient medication profile

This is the safety screen.

Sections:

| Section            | Contents                      |
| ------------------ | ----------------------------- |
| Demographics       | Age, sex, weight              |
| Allergies          | Known allergies               |
| Conditions         | Chronic conditions            |
| Current medicines  | Active medicine list          |
| Previous dispenses | History                       |
| ADR history        | Reported reactions            |
| Refill plans       | Active repeats                |
| Warnings           | Current safety warnings       |
| Consent            | SMS/WhatsApp/refill reminders |

---

## Screen 4: Dispensing workstation

This is where the pharmacist reviews and approves.

Panels:

| Panel                   | Contents                                      |
| ----------------------- | --------------------------------------------- |
| Prescription image/text | Uploaded or internal prescription             |
| Prescriber details      | Name, facility, licence                       |
| Patient safety          | Allergies, age, pregnancy, chronic conditions |
| Prescribed items        | Medicine, dose, duration                      |
| Available stock         | Batch, expiry, quantity, price                |
| Warnings                | Allergy, interaction, duplicate, stock        |
| Decisions               | Approve, substitute, partial, reject          |
| Label preview           | Patient instructions                          |
| POS link                | Bill status and payment                       |

---

## Screen 5: Substitution and partial dispense dialog

Required fields:

| Field                             |
| --------------------------------- |
| Prescribed medicine               |
| Selected replacement              |
| Reason                            |
| Dose equivalence                  |
| Quantity prescribed               |
| Quantity dispensed                |
| Balance remaining                 |
| Patient informed                  |
| Prescriber contacted              |
| Pharmacist approval PIN/signature |

---

## Screen 6: Controlled medicine register

Sections:

| Section          | Contents                                    |
| ---------------- | ------------------------------------------- |
| Stock balance    | Opening, received, dispensed, closing       |
| Dispense entries | Patient, prescription, prescriber, quantity |
| Adjustments      | Corrections, losses, quarantine             |
| Reconciliation   | Physical vs system balance                  |
| Approvals        | Pharmacist/superintendent                   |
| Export           | PDF/Excel controlled register               |

---

## Screen 7: Label printing screen

Features:

| Feature             |
| ------------------- |
| Label preview       |
| Language selection  |
| Warning stickers    |
| Batch/expiry toggle |
| Reprint reason      |
| Printer selection   |
| Print history       |

---

## Screen 8: Recall and batch lookup

Search by:

| Search key            |
| --------------------- |
| Product               |
| Batch                 |
| Supplier              |
| Patient               |
| Prescription          |
| Sale/invoice          |
| Dispensing pharmacist |
| Date range            |
| Branch                |

Must show:

```text
Stock remaining
Patients supplied
Quantities dispensed
Invoice references
Contact details
Recall action status
```

---

## Screen 9: Dispense audit screen

Shows timeline:

```text
Prescription uploaded → pharmacist reviewed → substitution approved → batch selected → paid → label printed → medicine handed over
```

Each step should show:

| Field     |
| --------- |
| User      |
| Role      |
| Date/time |
| Device    |
| Branch    |
| Action    |
| Reason    |
| Approval  |

---

# 7. Workflows

## A. External prescription workflow

```text
1. Patient presents paper/photo/PDF prescription
2. Cashier/pharmacy assistant captures patient
3. Prescription is uploaded or entered
4. Prescriber details are captured
5. Prescription enters pharmacist review queue
6. Pharmacist checks patient profile, medicine, dose, warnings
7. Pharmacist selects available stock batch/expiry
8. Pharmacist approves, substitutes, partially dispenses, or rejects
9. Approved items are sent to POS
10. Patient pays
11. eTIMS invoice/receipt is generated in Module 2
12. Label is printed
13. Medicine is handed over
14. Dispense audit is completed
```

---

## B. Internal clinic prescription workflow

```text
1. Clinician prescribes in EMR
2. Prescription appears in pharmacy queue
3. Pharmacist reviews patient profile and warnings
4. Pharmacist selects actual medicine and batch
5. Substitution or partial dispense is recorded if needed
6. Prescription is sent to billing
7. Patient pays or insurer/SHA split is applied
8. Medicine label is printed
9. Dispense is completed
10. EMR medication history updates automatically
```

---

## C. Prescription-only medicine scanned at POS

```text
1. Cashier scans medicine
2. System detects prescription-only category
3. POS blocks direct sale
4. System asks for patient and prescription
5. Prescription is sent to pharmacist review
6. Only approved dispense returns to POS for payment
```

Correct behaviour:

```text
Cashier cannot bypass pharmacist approval for configured prescription-only medicines.
```

---

## D. Partial dispensing workflow

```text
1. Prescription requires 30 tablets
2. Patient can afford 10 or stock only has 10
3. Pharmacist chooses partial dispense
4. System records reason
5. Balance of 20 remains on prescription
6. Label prints for 10 tablets only
7. POS bills 10 tablets only
8. Patient can later return for remaining balance if prescription remains valid
```

---

## E. Substitution workflow

```text
1. Prescription says Brand A
2. Brand A is out of stock or too expensive
3. Pharmacist selects equivalent Brand B/generic
4. System records substitution reason
5. Patient is informed
6. Prescriber approval is captured if required
7. Label prints actual dispensed product
8. Audit shows prescribed vs dispensed medicine
```

---

## F. Refill workflow

```text
1. Patient has chronic prescription with 3 repeats
2. First dispense creates refill plan
3. System calculates next refill date
4. Reminder is sent only if patient consent exists
5. Patient returns
6. Pharmacist reviews remaining repeats
7. Refill is approved and dispensed
8. Repeats remaining reduce by 1
9. When repeats are exhausted, system requires new prescription
```

---

## G. Controlled medicine workflow

```text
1. Controlled medicine is prescribed
2. System requires patient, prescriber, prescription, and pharmacist approval
3. System checks controlled stock balance
4. Dispense creates controlled register entry
5. POS bills medicine
6. Stock balance updates
7. Register closing balance updates
8. Any correction requires formal adjustment and approval
```

---

## H. Adverse drug reaction workflow

PPB runs PvERS, the Pharmacovigilance Electronic Reporting System, and its guest/provider pages show reporting routes for suspected adverse drug reactions, poor-quality health products, medication errors, medical devices, and other safety issues. ([pv.pharmacyboardkenya.org](https://pv.pharmacyboardkenya.org/users/guest))

```text
1. Patient reports reaction or poor-quality medicine
2. Pharmacist opens ADR/PQMP record
3. System captures patient, medicine, batch, dates, symptoms
4. System links report to original dispense
5. Pharmacist submits through PvERS or exports required details
6. Follow-up is recorded
```

---

# 8. Rules engine

## Dispensing allowed

```text
RULE: Dispense prescription medicine
IF branch.PPB_licence = active
AND branch.superintendent = active
AND pharmacist.practising_licence = active
AND prescription.exists = true
AND patient.exists = true
AND medicine.prescription_required = true
AND pharmacist_approval = approved
AND batch.status = sellable
AND batch.expiry_date > today
THEN allow dispense
ELSE block and show missing requirements
```

## OTC medicine sale

```text
RULE: OTC sale
IF medicine.category = OTC
AND batch.status = sellable
AND batch.expiry_date > today
THEN allow POS sale
ELSE block or require pharmacist review
```

## Controlled medicine

```text
RULE: Controlled medicine dispense
IF medicine.controlled = true
AND prescription.exists = true
AND patient.exists = true
AND prescriber.details_complete = true
AND pharmacist_approval = approved
AND controlled_register_entry_created = true
THEN allow dispense
ELSE block
```

## Partial dispense

```text
RULE: Partial dispensing
IF quantity_dispensed < quantity_prescribed
THEN require reason
AND create balance record
AND pharmacist approval
```

## Substitution

```text
RULE: Substitution
IF dispensed_product != prescribed_product
THEN require substitution_type
AND reason
AND patient_informed = true
AND pharmacist approval
AND prescriber approval if configured
```

## Clinical warning

```text
RULE: Critical warning
IF warning.severity = critical
THEN block dispense
UNLESS senior pharmacist override is allowed
AND reason is captured
```

## Batch and expiry

```text
RULE: Batch selection
IF product.batch_controlled = true
THEN batch_number and expiry_date are mandatory
AND expired/recalled/quarantined batches are blocked
```

## Refill

```text
RULE: Refill dispense
IF prescription.repeat_allowed = true
AND repeats_remaining > 0
AND prescription.valid_until >= today
THEN allow pharmacist review
ELSE require new prescription
```

---

# 9. Data model

## Main tables

### `patients`

| Field                   |
| ----------------------- |
| id                      |
| patient_number          |
| full_name               |
| date_of_birth           |
| age_estimated           |
| sex                     |
| phone                   |
| guardian_name           |
| weight                  |
| pregnancy_status        |
| breastfeeding_status    |
| chronic_conditions_json |
| consent_sms             |
| consent_whatsapp        |
| status                  |
| created_at              |

### `patient_allergies`

| Field         |
| ------------- |
| id            |
| patient_id    |
| allergen      |
| allergen_type |
| reaction      |
| severity      |
| recorded_by   |
| recorded_at   |
| status        |

### `prescribers`

| Field               |
| ------------------- |
| id                  |
| full_name           |
| cadre               |
| registration_number |
| licence_number      |
| facility_name       |
| phone               |
| email               |
| verification_status |
| verified_at         |
| notes               |

### `prescriptions`

| Field                |
| -------------------- |
| id                   |
| prescription_number  |
| source               |
| patient_id           |
| prescriber_id        |
| internal_visit_id    |
| prescription_date    |
| valid_until          |
| uploaded_document_id |
| diagnosis_text       |
| status               |
| repeat_allowed       |
| total_repeats        |
| repeats_used         |
| entered_by           |
| reviewed_by          |
| reviewed_at          |
| review_notes         |
| created_at           |

### `prescription_items`

| Field                   |
| ----------------------- |
| id                      |
| prescription_id         |
| prescribed_product_id   |
| prescribed_generic_name |
| strength                |
| dosage_form             |
| dose                    |
| frequency               |
| duration                |
| route                   |
| quantity_prescribed     |
| instructions            |
| substitution_allowed    |
| status                  |
| warning_status          |

### `dispenses`

| Field             |
| ----------------- |
| id                |
| prescription_id   |
| patient_id        |
| branch_id         |
| dispense_number   |
| dispense_type     |
| status            |
| pharmacist_id     |
| approved_at       |
| handed_over_by    |
| handed_over_at    |
| sale_id           |
| invoice_id        |
| counselling_done  |
| counselling_notes |
| created_at        |

### `dispense_lines`

| Field                   |
| ----------------------- |
| id                      |
| dispense_id             |
| prescription_item_id    |
| prescribed_product_id   |
| dispensed_product_id    |
| quantity_prescribed     |
| quantity_dispensed      |
| balance_quantity        |
| batch_id                |
| expiry_date             |
| substitution_flag       |
| substitution_reason     |
| partial_dispense_flag   |
| partial_dispense_reason |
| label_printed           |
| label_printed_at        |
| status                  |

### `controlled_medicine_register`

| Field                 |
| --------------------- |
| id                    |
| branch_id             |
| register_entry_number |
| medicine_id           |
| batch_id              |
| transaction_type      |
| prescription_id       |
| dispense_id           |
| patient_id            |
| prescriber_id         |
| opening_balance       |
| quantity_in           |
| quantity_out          |
| quantity_adjusted     |
| closing_balance       |
| pharmacist_id         |
| witness_user_id       |
| reason                |
| entry_datetime        |
| status                |

### `clinical_warnings`

| Field               |
| ------------------- |
| id                  |
| patient_id          |
| prescription_id     |
| dispense_id         |
| warning_type        |
| severity            |
| message             |
| medicine_id         |
| related_medicine_id |
| status              |
| generated_at        |
| acknowledged_by     |
| overridden_by       |
| override_reason     |
| overridden_at       |

### `refill_plans`

| Field                |
| -------------------- |
| id                   |
| patient_id           |
| prescription_id      |
| prescription_item_id |
| medicine_id          |
| start_date           |
| next_refill_date     |
| last_refill_date     |
| days_supply          |
| total_repeats        |
| repeats_used         |
| repeats_remaining    |
| status               |

### `medicine_labels`

| Field               |
| ------------------- |
| id                  |
| dispense_line_id    |
| patient_id          |
| label_text          |
| language            |
| warning_labels_json |
| printed_by          |
| printed_at          |
| reprint_count       |
| last_reprint_reason |

### `dispense_audit_logs`

| Field          |
| -------------- |
| id             |
| dispense_id    |
| entity_type    |
| entity_id      |
| action         |
| old_value_json |
| new_value_json |
| reason         |
| performed_by   |
| approved_by    |
| branch_id      |
| device_id      |
| created_at     |

### `adr_reports`

| Field                |
| -------------------- |
| id                   |
| patient_id           |
| dispense_id          |
| medicine_id          |
| batch_id             |
| report_type          |
| reaction_description |
| onset_date           |
| seriousness          |
| outcome              |
| reporter_user_id     |
| pvers_reference      |
| submitted_at         |
| status               |

---

# 10. API design

## Prescription endpoints

| Endpoint                                 | Purpose                       |
| ---------------------------------------- | ----------------------------- |
| `POST /prescriptions`                    | Create prescription           |
| `POST /prescriptions/{id}/upload`        | Upload prescription image/PDF |
| `POST /prescriptions/{id}/items`         | Add prescribed medicine       |
| `POST /prescriptions/{id}/submit-review` | Send to pharmacist queue      |
| `POST /prescriptions/{id}/review`        | Pharmacist review             |
| `POST /prescriptions/{id}/reject`        | Reject prescription           |
| `GET /prescriptions/search`              | Search prescriptions          |

## Dispensing endpoints

| Endpoint                          | Purpose                 |
| --------------------------------- | ----------------------- |
| `GET /dispensing/queue`           | Pharmacist queue        |
| `POST /dispenses`                 | Create dispense record  |
| `POST /dispenses/{id}/approve`    | Pharmacist approval     |
| `POST /dispenses/{id}/substitute` | Record substitution     |
| `POST /dispenses/{id}/partial`    | Record partial dispense |
| `POST /dispenses/{id}/complete`   | Complete dispense       |
| `POST /dispenses/{id}/reverse`    | Reverse dispense        |
| `GET /dispenses/{id}/audit`       | View audit trail        |

## Warning endpoints

| Endpoint                                   | Purpose              |
| ------------------------------------------ | -------------------- |
| `POST /clinical-warnings/check`            | Run warning checks   |
| `POST /clinical-warnings/{id}/acknowledge` | Acknowledge warning  |
| `POST /clinical-warnings/{id}/override`    | Override with reason |

## Refill endpoints

| Endpoint                           | Purpose             |
| ---------------------------------- | ------------------- |
| `POST /refill-plans`               | Create refill plan  |
| `GET /patients/{id}/refills`       | View active refills |
| `POST /refill-plans/{id}/dispense` | Dispense refill     |
| `POST /refill-plans/{id}/cancel`   | Cancel refill plan  |

## Controlled register endpoints

| Endpoint                               | Purpose               |
| -------------------------------------- | --------------------- |
| `GET /controlled-register`             | View register         |
| `POST /controlled-register/entry`      | Create register entry |
| `POST /controlled-register/reconcile`  | Reconcile balance     |
| `POST /controlled-register/adjustment` | Controlled adjustment |
| `GET /controlled-register/export`      | Export report         |

## Label endpoints

| Endpoint               | Purpose                |
| ---------------------- | ---------------------- |
| `POST /labels/preview` | Generate label preview |
| `POST /labels/print`   | Print label            |
| `POST /labels/reprint` | Reprint with reason    |

## ADR/pharmacovigilance endpoints

| Endpoint                        | Purpose                 |
| ------------------------------- | ----------------------- |
| `POST /adr-reports`             | Create ADR/PQMP report  |
| `POST /adr-reports/{id}/submit` | Mark submitted/exported |
| `GET /adr-reports/search`       | Search reports          |

---

# 11. Integration points

| Integration             | Purpose                                                |
| ----------------------- | ------------------------------------------------------ |
| Organisation/licensing  | Verify PPB branch licence and professional licence     |
| POS/billing             | Bill approved medicines and handle payment/eTIMS       |
| Inventory               | Batch, expiry, stock, recalls, FEFO                    |
| Clinic EMR              | Receive internal prescriptions                         |
| Lab module              | Link medicine decisions to lab results where available |
| Claims module           | Price medicines under insurer/SHA benefit rules        |
| Notifications           | Refill reminders and follow-up                         |
| Pharmacovigilance/PvERS | ADR/PQMP reporting support                             |
| Traceability/GS1        | GTIN, batch, serial, scan events                       |
| Reporting               | Compliance, safety, revenue, margin, stock movement    |

---

# 12. Permissions

| Permission                    |            Cashier |          Assistant | Pharmacist/Technologist | Superintendent | Manager | Auditor |
| ----------------------------- | -----------------: | -----------------: | ----------------------: | -------------: | ------: | ------: |
| Create patient                |                Yes |                Yes |                     Yes |            Yes |     Yes |    View |
| Upload prescription           |                Yes |                Yes |                     Yes |            Yes |      No |    View |
| Enter prescription item       |            Limited |                Yes |                     Yes |            Yes |      No |    View |
| Approve prescription dispense |                 No |                 No |                     Yes |            Yes |      No |    View |
| Override clinical warning     |                 No |                 No |                     Yes |            Yes |      No |    View |
| Dispense controlled medicine  |                 No |                 No |            Configurable |            Yes |      No |    View |
| Substitute medicine           |                 No |                 No |                     Yes |            Yes |      No |    View |
| Partial dispense              |                 No |                 No |                     Yes |            Yes |      No |    View |
| Print label                   | Yes after approval | Yes after approval |                     Yes |            Yes |      No |    View |
| Reverse dispense              |                 No |                 No |                 Limited |            Yes |     Yes |    View |
| Adjust controlled register    |                 No |                 No |              No/limited |            Yes |      No |    View |
| View controlled register      |                 No |                 No |                     Yes |            Yes | Limited |     Yes |
| Export audit report           |                 No |                 No |                      No |            Yes |     Yes |     Yes |

---

# 13. Reports

## Operational reports

| Report                            | Purpose                           |
| --------------------------------- | --------------------------------- |
| Daily dispensing report           | All medicines dispensed           |
| Prescription-only dispense report | Compliance                        |
| Controlled medicine register      | High-risk medicine accountability |
| Partial dispense report           | Patient balances and stock issues |
| Substitution report               | Brand/generic changes             |
| Refill due report                 | Chronic care                      |
| Refill missed report              | Adherence follow-up               |
| Pharmacist activity report        | Professional accountability       |
| Dispense by batch report          | Recall readiness                  |
| Near-expiry dispensed report      | Safety and policy review          |
| Rejected prescription report      | Quality control                   |
| Clinical warning override report  | Risk management                   |
| Label reprint report              | Safety audit                      |
| ADR/PQMP report                   | Pharmacovigilance support         |

## Owner dashboard cards

```text
Prescriptions pending review
Prescriptions dispensed today
Prescription-only sales
Controlled medicine balance alerts
Partial dispenses pending balance
Substitutions today
Near-expiry medicine dispensed
Clinical warnings overridden
Top dispensed medicines
Gross margin on dispensed medicines
Rejected/unclear prescriptions
ADR/PQMP reports opened
```

---

# 14. Edge cases

| Edge case                                               | Correct handling                                                                               |
| ------------------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| Patient brings unclear prescription                     | Mark “needs clarification”; do not dispense until resolved                                     |
| Prescription photo is blurry                            | Require re-upload or pharmacist override                                                       |
| Patient cannot afford full prescription                 | Partial dispensing with reason and balance                                                     |
| Prescribed brand out of stock                           | Substitution workflow                                                                          |
| Medicine has no batch in stock                          | Block if batch-controlled                                                                      |
| Batch expired                                           | Block                                                                                          |
| Batch recalled                                          | Block and alert                                                                                |
| Patient has allergy                                     | Critical warning                                                                               |
| Patient pays before pharmacist approval                 | Configure either block payment or hold bill pending approval                                   |
| Pharmacist approves but patient does not pay            | Dispense remains approved-not-handed-over; stock not finalized or reserved depending on policy |
| Label printer fails                                     | Allow reprint; medicine should not be handed over without label unless override                |
| Prescription item already dispensed elsewhere in branch | Warn duplicate dispense                                                                        |
| Refill too early                                        | Require pharmacist review                                                                      |
| Controlled stock balance mismatch                       | Freeze controlled dispensing until reconciled or senior override                               |
| Return of medicine                                      | Quarantine by default unless policy and pharmacist allow resale                                |
| Wrong medicine dispensed                                | Incident workflow, reversal, patient contact, possible ADR/medication error report             |

---

# 15. MVP versus later versions

## MVP

Build these first:

| Feature                           | Reason                             |
| --------------------------------- | ---------------------------------- |
| Prescription entry/upload         | Core compliance                    |
| Patient profile                   | Safety and history                 |
| Prescriber details                | Accountability                     |
| Pharmacist approval               | Prevent cashier-only dispensing    |
| Batch/expiry selection            | Recall and quality                 |
| Dosage instructions               | Label and safety                   |
| Label printing                    | Patient safety                     |
| Partial dispensing                | Kenyan affordability reality       |
| Substitution logging              | Audit and stock reality            |
| Basic refill tracking             | Chronic-care support               |
| Dispense audit                    | Compliance                         |
| POS integration                   | Billing/payment                    |
| Inventory integration             | Stock decrement                    |
| Basic clinical warnings           | Allergy, duplicate, age, pregnancy |
| Controlled medicine flag/register | High-risk compliance               |

## Version 2

Add:

| Feature                                    | Reason                    |
| ------------------------------------------ | ------------------------- |
| Advanced drug interaction database         | Better clinical safety    |
| Prescriber verification workflow           | Reduce fake prescriptions |
| Patient medication history across branches | Continuity                |
| SMS/WhatsApp refill reminders              | Chronic-care adherence    |
| Medicine counselling checklist             | Professional quality      |
| ADR/PQMP export to PvERS                   | Pharmacovigilance support |
| Barcode/DataMatrix batch scanning          | Faster, safer dispensing  |
| Cold-chain checks                          | Vaccine/insulin safety    |
| Controlled register reconciliation         | Stronger compliance       |
| Insurance formulary rules                  | Claims accuracy           |

## Version 3

Add:

| Feature                                        | Reason                                  |
| ---------------------------------------------- | --------------------------------------- |
| National e-prescription integration            | Future Digital Health Agency readiness  |
| PPB/PRIMS product validation                   | Product authenticity                    |
| GS1 serialization                              | Full traceability                       |
| AI-assisted safety screening                   | Risk detection                          |
| Patient app medication wallet                  | Refills and instructions                |
| Remote pharmacist review                       | Chain/telepharmacy support where lawful |
| Advanced pharmacovigilance                     | Signal detection and follow-up          |
| FHIR MedicationRequest/MedicationDispense APIs | Interoperability                        |

---

# 16. Acceptance criteria

The module is ready when it passes these tests:

| Test                           | Expected result                                                                  |
| ------------------------------ | -------------------------------------------------------------------------------- |
| External prescription uploaded | Prescription enters pharmacist queue                                             |
| Prescription-only item scanned | POS blocks direct sale and requires prescription workflow                        |
| Pharmacist approval            | Only licensed pharmacy user can approve dispensing                               |
| Patient allergy warning        | System warns or blocks medicine                                                  |
| Partial dispensing             | System records reason, quantity supplied, and balance                            |
| Substitution                   | System records prescribed item, dispensed item, reason, and approver             |
| Refill                         | System tracks repeats used and remaining                                         |
| Controlled medicine            | Register entry is created with patient, prescriber, quantity, batch, and balance |
| Batch selection                | Expired/recalled/quarantined batch cannot be dispensed                           |
| Label printing                 | Label includes patient, medicine, dosage, date, and instructions                 |
| Dispense-to-POS                | Approved dispense creates billable POS line                                      |
| Payment complete               | Dispense links to sale/invoice/payment                                           |
| Recall lookup                  | System identifies all patients supplied from a batch                             |
| Audit                          | System shows who entered, approved, billed, dispensed, and handed over medicine  |
| ADR report                     | System can create report linked to patient, medicine, batch, and dispense        |

---

# 17. Final product behaviour

The Pharmacy Dispensing Module should behave like this:

| Situation                           | Correct behaviour                                   |
| ----------------------------------- | --------------------------------------------------- |
| OTC medicine                        | Allow fast sale with stock and expiry checks        |
| Prescription medicine               | Require patient, prescription, pharmacist approval  |
| Controlled medicine                 | Require stricter register and approval              |
| External prescription               | Upload, capture prescriber, pharmacist review       |
| Internal clinic prescription        | Flow directly from EMR to pharmacy queue            |
| Patient cannot afford full quantity | Partial dispense with balance tracking              |
| Brand unavailable                   | Substitution with reason and approval               |
| Chronic patient                     | Refill plan and medication history                  |
| Allergy or warning                  | Alert, block, or require override                   |
| Batch recalled                      | Block and find affected patients                    |
| Medicine handed over                | Label, audit, stock movement, POS invoice complete  |
| Patient reports reaction            | Create ADR/PQMP record linked to batch and dispense |

The key design principle is:

**No prescription medicine should leave the pharmacy without a patient, a prescription, a responsible professional, a batch, instructions, and an audit trail.**
