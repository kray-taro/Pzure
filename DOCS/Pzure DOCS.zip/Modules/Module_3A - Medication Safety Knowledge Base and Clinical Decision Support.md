You are exactly right. **Module 3 currently has a clinical-decision-support gap.** Allergy checks, drug–drug interactions, pregnancy warnings, duplicate therapy detection, antibiotic stewardship, and contraindication checks cannot be implemented safely from ordinary product-master data alone.

They require a **drug knowledge base**, terminology mapping, evidence governance, update cycles, pharmacist review, and alert-fatigue controls.

I would close this as a new architecture decision:

```text
ADR-021: Medication Safety Knowledge Base and Clinical Decision Support Strategy
```

---

# 1. Architecture decision

For this Kenyan 10-branch enterprise rollout, I recommend a **hybrid staged approach**, not a purely manual table and not an immediate fully commercial dependency.

## Recommended path

| Stage                           | Recommendation                                                                               | Why                                                   |
| ------------------------------- | -------------------------------------------------------------------------------------------- | ----------------------------------------------------- |
| MVP / Version 1                 | **Kenya KEML + local formulary + RxNorm/ATC mapping + curated safety tables**                | Kenya-local, controllable, affordable, auditable      |
| Version 2                       | **Add open knowledge sources and structured update process**                                 | Improves safety coverage without vendor lock-in       |
| Version 3 / Enterprise maturity | **Integrate commercial drug knowledge base such as FDB, Medi-Span, DrugBank, or equivalent** | Needed for robust enterprise-grade clinical screening |

The MVP should **not pretend to be a full clinical decision support engine**. It should clearly implement:

```text
Level 1 safety checks:
    allergy ingredient/class checks
    duplicate therapy by therapeutic class
    pregnancy/breastfeeding caution flags
    paediatric/age flags
    controlled medicine flags
    antibiotic AWaRe category flags
    selected high-risk drug-drug interactions
    local formulary/KEPH-level restrictions
```

Then Version 2/3 expands to deeper interaction, contraindication, dose, disease, renal, hepatic, pregnancy, and lactation intelligence.

---

# 2. Why KEML alone is not enough

KEML is essential but it is **not a drug interaction database**.

The Kenya Essential Medicines List 2023 is intended to guide access to essential medicines and lists medicines by therapeutic category, INN, dosage form, strength, and level of use; it also includes AWaRe classification for antibiotics. That makes it a strong local formulary base, but not sufficient for automated interaction, pregnancy, allergy, and duplicate-therapy screening by itself. ([kemsa.go.ke](https://www.kemsa.go.ke/download/file/8e7d9c438ecc1a468d9d7615a87688df.pdf))

So the knowledge architecture should separate:

| Knowledge area                   | Best source                                                 |
| -------------------------------- | ----------------------------------------------------------- |
| Kenya formulary and level-of-use | KEML                                                        |
| Local therapeutic categories     | KEML + local pharmacy formulary                             |
| Antibiotic stewardship           | KEML AWaRe + WHO AWaRe                                      |
| Ingredient terminology           | RxNorm/UMLS mapping                                         |
| Drug–drug interactions           | Curated local table initially; commercial/open source later |
| Allergy matching                 | Ingredient/class table                                      |
| Pregnancy/lactation warnings     | Curated local table initially; SPL/commercial later         |
| Duplicate therapy                | ATC/RxNorm ingredient/class grouping                        |
| Patient-friendly information     | MedlinePlus or curated local templates                      |
| Pharmacovigilance                | PPB PvERS workflow                                          |

WHO’s Model Lists of Essential Medicines are updated every two years, and the current versions were updated in September 2025; WHO’s AWaRe classification groups antibiotics into Access, Watch, and Reserve categories to support antibiotic stewardship and is also updated every two years. ([who.int](https://www.who.int/groups/expert-committee-on-selection-and-use-of-essential-medicines/essential-medicines-lists)) ([who.int](https://www.who.int/publications/i/item/B09489))

---

# 3. Corrected Module 3 design: Medication Safety Knowledge Base

Add this as a new submodule under Module 3:

```text
Module 3A: Medication Safety Knowledge Base and Clinical Decision Support
```

It serves:

```text
EMR prescription
Pharmacy dispensing
Online pharmacy prescription upload
Refill/repeat review
Controlled medicine review
Claims drug validation
Patient counselling
ADR/pharmacovigilance
```

---

# 4. Recommended MVP knowledge stack

## 4.1 Core local formulary

Use KEML 2023 as the Kenya-local starting point.

| Data                     | Source/use                                 |
| ------------------------ | ------------------------------------------ |
| INN/generic name         | KEML                                       |
| Dosage form              | KEML                                       |
| Strength                 | KEML                                       |
| Therapeutic category     | KEML                                       |
| KEPH/facility level      | KEML                                       |
| AWaRe classification     | KEML and WHO AWaRe                         |
| Local product mapping    | Internal product catalogue                 |
| Branch formulary         | Which branches stock/dispense what         |
| Prescription category    | Internal/PPB-aligned configuration         |
| Controlled medicine flag | Internal controlled register configuration |

---

## 4.2 Terminology backbone

Use RxNorm as the terminology bridge where possible.

RxNorm provides normalized names for clinical drugs and links names to many drug vocabularies used in pharmacy management and drug-interaction software; the National Library of Medicine provides RxNorm files and APIs for accessing RxNorm data. ([nlm.nih.gov](https://www.nlm.nih.gov/research/umls/rxnorm/index.html)) ([lhncbc.nlm.nih.gov](https://lhncbc.nlm.nih.gov/RxNav/APIs/RxNormAPIs.html))

| Terminology        | Use                                            |
| ------------------ | ---------------------------------------------- |
| RxNorm RxCUI       | Ingredient/clinical drug identity where mapped |
| ATC code           | Duplicate therapy and therapeutic class        |
| Local product code | POS/inventory/dispensing                       |
| INN/generic name   | Kenya formulary                                |
| Brand name         | Product master                                 |
| Strength/form      | Dispensing and equivalence                     |
| Route              | Clinical safety and label                      |
| Pack size          | Inventory/POS                                  |

MVP should not require every local brand to map perfectly to RxNorm. Instead, the **generic ingredient** should be the safety anchor.

Example:

```text
Local brand: Amoxil 500mg capsule
Generic ingredient: amoxicillin
RxNorm ingredient: amoxicillin
ATC: J01CA04
KEML category: anti-infective
AWaRe: Access
```

---

## 4.3 Safety rules table

Create curated local tables for the first version.

| Rule type              | MVP implementation                                                     |
| ---------------------- | ---------------------------------------------------------------------- |
| Allergy                | Ingredient and drug-class matching                                     |
| Duplicate therapy      | ATC/class matching                                                     |
| Pregnancy              | Contraindicated/caution/unknown flags                                  |
| Breastfeeding          | Caution/avoid/unknown flags                                            |
| Drug–drug interaction  | Curated high-risk list only                                            |
| Age restriction        | Paediatric/elderly warnings                                            |
| Antibiotic stewardship | AWaRe category display                                                 |
| Controlled medicines   | Controlled flag and approval workflow                                  |
| Refill risk            | Early refill/duplicate active therapy                                  |
| Disease caution        | Optional selected rules: asthma, hypertension, diabetes, renal disease |

---

# 5. Clinical decision support levels

## Level 1: MVP safety checks

This is what should ship first.

| Safety check             | MVP behaviour                                                          |
| ------------------------ | ---------------------------------------------------------------------- |
| Allergy ingredient match | Alert if prescribed/dispensed ingredient matches recorded allergy      |
| Allergy class match      | Alert if allergy class matches medicine class                          |
| Duplicate therapy        | Alert if patient already has active medicine in same therapeutic class |
| Pregnancy warning        | Alert if medicine is contraindicated/caution in pregnancy              |
| Breastfeeding warning    | Alert if medicine has breastfeeding caution                            |
| Paediatric warning       | Alert if age below configured minimum                                  |
| Elderly caution          | Alert for selected high-risk medicines                                 |
| Interaction check        | Alert for curated high-severity pairs                                  |
| Antibiotic AWaRe         | Show Access/Watch/Reserve category                                     |
| Controlled medicine      | Require controlled register workflow                                   |
| Refill too early         | Require pharmacist review                                              |
| Substitution risk        | Check ingredient equivalence and class                                 |

---

## Level 2: Enhanced open-source safety

Add after MVP.

| Capability                     | Source/approach                                  |
| ------------------------------ | ------------------------------------------------ |
| Broader RxNorm mapping         | RxNorm files/API                                 |
| Structured drug labeling       | DailyMed/FDA SPL                                 |
| Pregnancy/lactation expansion  | FDA SPL/PLLR-based structured mapping            |
| Patient education              | MedlinePlus-style patient-friendly content       |
| More interaction rules         | Curated open datasets plus pharmacist validation |
| ATC-based grouping             | WHO/ATC mapping where licensed/available         |
| Antibiotic stewardship reports | AWaRe analytics                                  |
| ADR reporting support          | PPB PvERS workflow                               |

FDA’s Structured Product Labeling is an HL7-approved document markup standard adopted by FDA for exchanging product and facility information, and DailyMed provides SPL label downloads including product and ingredient indexing resources. FDA’s pregnancy and lactation labeling resources describe PLLR content intended to help healthcare providers assess benefit versus risk and counsel pregnant or breastfeeding patients. ([fda.gov](https://www.fda.gov/industry/fda-data-standards-advisory-board/structured-product-labeling-resources)) ([dailymed.nlm.nih.gov](https://dailymed.nlm.nih.gov/dailymed/spl-resources.cfm)) ([fda.gov](https://www.fda.gov/drugs/labeling-information-drug-products/pregnancy-and-lactation-labeling-resources))

---

## Level 3: Commercial enterprise CDS

Use when the organisation is ready to pay for, govern, and clinically validate vendor-provided rules.

| Vendor type      | Value                                                                         |
| ---------------- | ----------------------------------------------------------------------------- |
| First Databank   | Deep medication screening and clinical rules                                  |
| Medi-Span        | Mature interaction, allergy, duplicate therapy and contraindication screening |
| DrugBank         | API-first structured drug knowledge                                           |
| Micromedex/other | Enterprise clinical pharmacy reference                                        |

For this project, I would not hard-code a commercial vendor into the base product. I would create a **Drug Knowledge Provider Interface** so the system can start with local tables and later switch to or augment with a vendor.

---

# 6. Proposed CDS architecture

## 6.1 High-level architecture

```text
Prescription / Dispense Request
        ↓
Medication Safety Service
        ↓
Patient context
    - age
    - sex
    - pregnancy/breastfeeding
    - allergies
    - active medicines
    - chronic conditions
        ↓
Drug knowledge base
    - local formulary
    - ingredients
    - ATC/classes
    - KEML/KEPH level
    - AWaRe
    - interaction rules
    - pregnancy rules
    - allergy class rules
        ↓
Rules engine
        ↓
Safety alerts
    - informational
    - warning
    - high
    - critical/blocking
        ↓
Pharmacist/clinician action
    - accept
    - change
    - override with reason
    - reject
    - contact prescriber
```

---

## 6.2 Service boundary

Add a dedicated service/module:

```text
medication-safety
```

Responsibilities:

| Responsibility                    |
| --------------------------------- |
| Drug normalization                |
| Ingredient mapping                |
| Allergy matching                  |
| Duplicate therapy screening       |
| DDI screening                     |
| Pregnancy/breastfeeding screening |
| AWaRe antibiotic flagging         |
| Controlled medicine flagging      |
| Safety alert generation           |
| Alert severity ranking            |
| Override capture                  |
| Knowledge-base versioning         |
| Safety-rule governance            |
| Audit and reporting               |

---

# 7. Data model additions

Add these tables to the SQL Server model.

## 7.1 Drug knowledge source tables

### `pharmacy.drug_knowledge_sources`

| Field            | Purpose                                     |
| ---------------- | ------------------------------------------- |
| id               | Source ID                                   |
| source_name      | KEML, WHO EML, RxNorm, Local, DrugBank, FDB |
| source_type      | formulary, terminology, safety, interaction |
| version          | Source version                              |
| effective_from   | Start date                                  |
| effective_to     | End date                                    |
| licence_type     | public, open, commercial, internal          |
| update_frequency | manual/monthly/quarterly/API                |
| status           | active/inactive                             |
| approved_by      | Governance                                  |
| approved_at      | Governance                                  |

---

### `pharmacy.drug_ingredients`

| Field                | Purpose                               |
| -------------------- | ------------------------------------- |
| id                   | Ingredient ID                         |
| ingredient_name      | Generic ingredient                    |
| normalized_name      | Search/mapping                        |
| rxnorm_rxcui         | RxNorm concept where available        |
| atc_code             | ATC where available                   |
| therapeutic_class_id | Local class                           |
| keml_flag            | In KEML yes/no                        |
| aware_category       | Access/Watch/Reserve where antibiotic |
| status               | Active/inactive                       |

---

### `pharmacy.product_ingredient_map`

| Field                  | Purpose                |
| ---------------------- | ---------------------- |
| id                     | Mapping ID             |
| product_id             | Local product          |
| ingredient_id          | Active ingredient      |
| strength_value         | Strength               |
| strength_unit          | mg, mL, %, etc.        |
| dosage_form            | Tablet/capsule/syrup   |
| route                  | Oral/topical/injection |
| mapping_confidence     | high/manual/unknown    |
| mapped_by              | User/source            |
| mapped_at              | Date                   |
| verified_by_pharmacist | Governance             |
| status                 | Active/inactive        |

This table is critical. Without it, brand-name products cannot be safely screened.

---

### `pharmacy.therapeutic_classes`

| Field                | Purpose                            |
| -------------------- | ---------------------------------- |
| id                   | Class ID                           |
| class_name           | NSAID, ACE inhibitor, beta blocker |
| parent_class_id      | Hierarchy                          |
| atc_prefix           | ATC grouping                       |
| duplicate_check_flag | Whether duplicate warning applies  |
| status               | Active/inactive                    |

---

## 7.2 Safety rule tables

### `pharmacy.drug_interaction_rules`

| Field                    | Purpose                                       |
| ------------------------ | --------------------------------------------- |
| id                       | Rule ID                                       |
| ingredient_a_id          | First ingredient/class                        |
| ingredient_b_id          | Second ingredient/class                       |
| class_a_id               | Optional class-level rule                     |
| class_b_id               | Optional class-level rule                     |
| severity                 | info, minor, moderate, major, contraindicated |
| clinical_effect          | What may happen                               |
| mechanism                | Optional                                      |
| recommendation           | Avoid, monitor, adjust, counsel               |
| evidence_source          | KEML/local/FDA/commercial/etc.                |
| source_version           | Rule version                                  |
| active_flag              | Active/inactive                               |
| requires_override_reason | Yes/no                                        |
| block_dispense           | Yes/no                                        |
| reviewed_by              | Pharmacist/clinical reviewer                  |
| reviewed_at              | Date                                          |

---

### `pharmacy.allergy_cross_sensitivity_rules`

| Field                   | Purpose                        |
| ----------------------- | ------------------------------ |
| id                      | Rule ID                        |
| allergy_term            | Penicillin, sulfonamide, NSAID |
| ingredient_id           | Specific ingredient            |
| therapeutic_class_id    | Class                          |
| cross_sensitivity_group | Beta-lactam, NSAID, etc.       |
| severity                | warning/high/critical          |
| recommendation          | Avoid/verify/counsel           |
| source                  | Evidence                       |
| status                  | Active/inactive                |

---

### `pharmacy.pregnancy_lactation_rules`

| Field                       | Purpose                                    |
| --------------------------- | ------------------------------------------ |
| id                          | Rule ID                                    |
| ingredient_id               | Medicine                                   |
| pregnancy_risk_level        | safe/caution/avoid/contraindicated/unknown |
| trimester_specific_flag     | Yes/no                                     |
| trimester_notes             | Optional                                   |
| breastfeeding_risk_level    | safe/caution/avoid/unknown                 |
| reproductive_potential_note | Optional                                   |
| recommendation              | Message                                    |
| source                      | Local/FDA/commercial                       |
| source_version              | Version                                    |
| reviewed_by                 | Clinical reviewer                          |
| reviewed_at                 | Date                                       |
| status                      | Active/inactive                            |

---

### `pharmacy.duplicate_therapy_rules`

| Field                          | Purpose                             |
| ------------------------------ | ----------------------------------- |
| id                             | Rule ID                             |
| therapeutic_class_id           | Class                               |
| duplicate_window_days          | Active medication window            |
| severity                       | info/warning/high                   |
| recommendation                 | Review therapy                      |
| exclude_same_prescription_flag | Whether combination therapy allowed |
| status                         | Active/inactive                     |

---

### `pharmacy.age_restriction_rules`

| Field          | Purpose               |
| -------------- | --------------------- |
| id             | Rule ID               |
| ingredient_id  | Medicine              |
| min_age_days   | Minimum age           |
| max_age_days   | Maximum age           |
| severity       | warning/high/critical |
| recommendation | Message               |
| source         | Evidence              |
| status         | Active/inactive       |

---

### `pharmacy.condition_caution_rules`

| Field          | Purpose                                       |
| -------------- | --------------------------------------------- |
| id             | Rule ID                                       |
| ingredient_id  | Medicine                                      |
| condition_code | Asthma, renal disease, hypertension, diabetes |
| severity       | info/warning/high/critical                    |
| recommendation | Message                                       |
| source         | Evidence                                      |
| status         | Active/inactive                               |

---

## 7.3 Alert and override tables

### `pharmacy.medication_safety_checks`

| Field                  | Purpose                                   |
| ---------------------- | ----------------------------------------- |
| id                     | Check ID                                  |
| patient_id             | Patient                                   |
| visit_id               | EMR visit                                 |
| prescription_id        | Prescription                              |
| dispense_id            | Dispense                                  |
| check_context          | prescribe, dispense, refill, online_order |
| knowledge_base_version | Version used                              |
| checked_by             | System/user                               |
| checked_at             | Time                                      |
| status                 | passed, warnings, blocked                 |

---

### `pharmacy.medication_safety_alerts`

| Field                 | Purpose                                            |
| --------------------- | -------------------------------------------------- |
| id                    | Alert ID                                           |
| safety_check_id       | Parent check                                       |
| alert_type            | allergy, ddi, pregnancy, duplicate, age, condition |
| severity              | info, warning, high, critical                      |
| ingredient_id         | Ingredient involved                                |
| related_ingredient_id | For DDI                                            |
| product_id            | Product involved                                   |
| message               | Display message                                    |
| recommendation        | What to do                                         |
| source                | Rule/source                                        |
| blocking_flag         | Blocks action                                      |
| acknowledged_by       | User                                               |
| acknowledged_at       | Time                                               |
| override_required     | Yes/no                                             |
| status                | open, acknowledged, overridden, resolved           |

---

### `pharmacy.medication_safety_overrides`

| Field                  | Purpose              |
| ---------------------- | -------------------- |
| id                     | Override ID          |
| alert_id               | Alert                |
| override_by            | Pharmacist/clinician |
| override_role          | Role                 |
| override_pin_verified  | Yes/no               |
| override_reason        | Required             |
| prescriber_contacted   | Yes/no               |
| patient_counselled     | Yes/no               |
| alternative_considered | Yes/no               |
| created_at             | Time                 |
| audit_event_id         | Link to audit        |

---

# 8. CDS provider abstraction

Build the rules engine so sources can change.

## Interface

```text
DrugKnowledgeProvider
    normalizeDrug(product)
    getIngredients(product)
    getTherapeuticClasses(ingredient)
    checkAllergy(patient, medication)
    checkInteractions(activeMedications, newMedication)
    checkPregnancy(patient, medication)
    checkDuplicateTherapy(activeMedications, newMedication)
    checkAge(patient, medication)
    checkConditionCautions(patient, medication)
```

## Providers

| Provider              | Use                                         |
| --------------------- | ------------------------------------------- |
| LocalKEMLProvider     | MVP formulary, local ingredient/class rules |
| RxNormProvider        | Ingredient and terminology mapping          |
| OpenLabelProvider     | SPL/pregnancy/label information later       |
| CommercialCDSProvider | FDB/Medi-Span/DrugBank later                |
| CompositeProvider     | Combines local and external sources         |

MVP uses:

```text
CompositeProvider
    ├── LocalKEMLProvider
    ├── LocalSafetyRulesProvider
    └── RxNormMappingProvider
```

Version 3 can add:

```text
CommercialCDSProvider
```

without rewriting pharmacy workflow.

---

# 9. Safety alert severity model

Alert severity must be strict enough for safety but not so noisy that pharmacists ignore it.

| Severity   | Meaning                         | Behaviour                                  |
| ---------- | ------------------------------- | ------------------------------------------ |
| Info       | Useful context                  | Show only                                  |
| Warning    | Review needed                   | Acknowledge                                |
| High       | Significant risk                | Pharmacist override reason                 |
| Critical   | Contraindicated/unsafe          | Block unless senior override is configured |
| Regulatory | Legally/procedurally prohibited | Hard block                                 |

Example:

| Alert                            | Severity                     | Behaviour                         |
| -------------------------------- | ---------------------------- | --------------------------------- |
| Duplicate NSAID                  | Warning/high                 | Pharmacist review                 |
| Penicillin allergy + amoxicillin | Critical                     | Block/override only by pharmacist |
| Pregnancy caution                | High                         | Pharmacist/clinician review       |
| Warfarin + NSAID                 | High/critical depending rule | Review/override                   |
| Reserve antibiotic               | Warning/high                 | Stewardship prompt                |
| Controlled medicine              | Regulatory workflow          | Controlled register               |

---

# 10. Alert-fatigue controls

This is important. A noisy CDS engine is unsafe.

| Control                 | Behaviour                                                              |
| ----------------------- | ---------------------------------------------------------------------- |
| Tiered severity         | Do not interrupt for low-value info                                    |
| Context-aware alerts    | Different behaviour for OTC, prescription, refill, chronic repeat      |
| Suppression rules       | Do not repeat same warning endlessly in same visit unless changed      |
| Override memory         | Store previous override but do not blindly suppress future risk        |
| Pharmacist dashboard    | Review override patterns                                               |
| Rule governance         | Disable/adjust noisy rules after review                                |
| High-risk always active | Allergy, critical DDI, controlled medicine, pregnancy contraindication |
| Audit override rates    | Detect unsafe bypassing                                                |

---

# 11. Kenya-localization rules

## 11.1 KEML and KEPH level check

The system should warn if a medicine is outside the configured branch/facility level or local formulary.

| Rule                                       | Behaviour                            |
| ------------------------------------------ | ------------------------------------ |
| Product not mapped to KEML/local formulary | Warn procurement/pharmacist          |
| Product not allowed at branch level        | Warn/block depending facility policy |
| Medicine not stocked at branch             | Suggest transfer/substitution        |
| Reserve antibiotic                         | Stewardship review                   |
| Non-formulary medicine                     | Pharmacist/manager approval          |

---

## 11.2 Antibiotic stewardship

Use AWaRe in MVP.

| AWaRe category | Behaviour                                                     |
| -------------- | ------------------------------------------------------------- |
| Access         | Normal antibiotic workflow                                    |
| Watch          | Stewardship warning and diagnosis required                    |
| Reserve        | Senior clinician/pharmacist approval and strict documentation |
| Unmapped       | Pharmacist review                                             |

WHO’s AWaRe classification was developed to support antibiotic stewardship and classifies antibiotics into Access, Watch, and Reserve groups based on resistance impact and appropriate use considerations. ([who.int](https://www.who.int/publications/i/item/B09489))

---

## 11.3 Local disease context

Add curated high-priority Kenya-relevant safety rules.

| Area         | Example controls                                     |
| ------------ | ---------------------------------------------------- |
| Malaria      | Antimalarial pregnancy/age cautions                  |
| HIV/TB       | Interaction caution and referral/program sensitivity |
| Hypertension | Duplicate antihypertensive class warnings            |
| Diabetes     | Hypoglycaemia risk and refill adherence              |
| Asthma       | NSAID/beta-blocker cautions where configured         |
| Pregnancy    | Reproductive health medicine warnings                |
| Antibiotics  | AWaRe and duplicate antibiotic therapy               |

This does not replace national treatment guidelines. It provides structured warning prompts and documentation.

---

# 12. Pharmacovigilance integration

The system should support ADR and medication-error capture linked to dispense, product, batch, and patient.

PPB’s PvERS allows reporting of suspected adverse drug reactions, poor-quality health products, medication errors, medical devices, and other safety issues; it indicates that healthcare providers and pharmaceutical companies can report medicine, product, and vaccine safety issues. ([pv.pharmacyboardkenya.org](https://pv.pharmacyboardkenya.org/users/guest))

## ADR workflow

```text
Patient reports reaction
    ↓
Pharmacist opens ADR record
    ↓
System pulls patient, medicine, batch, dispense, prescriber
    ↓
Reaction details captured
    ↓
Report exported/submitted through PPB PvERS workflow
    ↓
Follow-up task created
```

## ADR data fields

| Field                |
| -------------------- |
| Patient              |
| Medicine/product     |
| Ingredient           |
| Batch/expiry         |
| Dispense date        |
| Reaction date        |
| Reaction description |
| Seriousness          |
| Outcome              |
| Reporter             |
| Prescriber           |
| PvERS reference      |
| Follow-up action     |

---

# 13. Implementation plan addition

Add a new sprint before building full Module 3 pharmacy safety.

## New Sprint: Medication Knowledge Base and CDS Foundation

Place this before the existing pharmacy dispensing sprint.

```text
Insert after Product Master / before Module 3 advanced dispensing
```

## Sprint scope

| Workstream              | Deliverable                             |
| ----------------------- | --------------------------------------- |
| Knowledge architecture  | ADR-021 approved                        |
| KEML import             | KEML-based formulary table              |
| Ingredient mapping      | Product-to-ingredient table             |
| Therapeutic classes     | Local class/ATC grouping                |
| AWaRe mapping           | Antibiotic stewardship flags            |
| Allergy rules           | Ingredient/class allergy rules          |
| Duplicate therapy rules | Therapeutic class checks                |
| Pregnancy rules v1      | Curated high-risk medicine list         |
| DDI rules v1            | Curated high-severity interaction pairs |
| Safety service          | Medication Safety API                   |
| Alert UI                | Pharmacist/clinician warning display    |
| Override workflow       | PIN + reason + audit                    |
| Governance workflow     | Rule review and approval                |
| Reports                 | Safety alert and override reports       |

---

# 14. MVP acceptance criteria for medication safety

| Test                                                      | Expected result                                           |
| --------------------------------------------------------- | --------------------------------------------------------- |
| Product has no ingredient mapping                         | Prescription/dispense warns “safety screening incomplete” |
| Patient has penicillin allergy and amoxicillin prescribed | Critical allergy alert                                    |
| Patient has active ibuprofen and diclofenac is added      | Duplicate NSAID/therapy alert                             |
| Pregnant patient gets configured high-risk medicine       | Pregnancy warning                                         |
| Reserve antibiotic selected                               | AWaRe stewardship warning and approval                    |
| High-risk DDI pair prescribed                             | Interaction alert                                         |
| Pharmacist overrides warning                              | PIN and reason required                                   |
| Override report opened                                    | Shows user, alert, reason, patient, medicine              |
| ADR created from dispense                                 | Pulls patient, product, batch, dispense                   |
| Knowledge rule edited                                     | Versioned and approved before active                      |
| Unmapped brand product                                    | Cannot be considered fully screened                       |
| Alert generated                                           | Source/version of rule is stored                          |

---

# 15. Governance model

Medication safety content must be governed like clinical content.

## Medication Safety Committee

For a 10-branch system, create a small internal group:

| Role                          | Responsibility                        |
| ----------------------------- | ------------------------------------- |
| Superintendent pharmacist     | Owns pharmacy safety rules            |
| Clinician lead                | Owns clinical acceptability           |
| Lab/diagnostic representative | Advises lab-linked rules where needed |
| Claims/billing representative | Ensures payer/formulary alignment     |
| Data/IT lead                  | Owns implementation and versioning    |
| Compliance/DPO                | Ensures privacy and audit controls    |

## Rule lifecycle

```text
Draft rule
    ↓
Clinical/pharmacy review
    ↓
Test in staging
    ↓
Approve
    ↓
Activate with effective date
    ↓
Monitor overrides/noise
    ↓
Revise or retire
```

## Required governance fields

| Field               |
| ------------------- |
| Rule author         |
| Evidence/source     |
| Clinical reviewer   |
| Approval date       |
| Effective date      |
| Review date         |
| Severity            |
| Override policy     |
| Version             |
| Change reason       |
| Deactivation reason |

---

# 16. Data quality requirements

Medication safety only works if product data is clean.

## Mandatory product mapping before go-live

| Product type          | Required mapping                                    |
| --------------------- | --------------------------------------------------- |
| Prescription medicine | Ingredient, strength, form, route, class            |
| Controlled medicine   | Ingredient, controlled flag, register category      |
| Antibiotic            | Ingredient, class, AWaRe category                   |
| OTC medicine          | Ingredient and class where safety rules apply       |
| Combination product   | All active ingredients                              |
| Supplements           | Ingredient/category where interactions are relevant |
| Retail goods          | No CDS mapping required unless health product       |

## Blocking rule

```text
Prescription-only medicines should not be activated for dispensing until product-to-ingredient mapping is complete and pharmacist-verified.
```

---

# 17. Commercial vendor readiness

Even if you do not buy a commercial knowledge base immediately, design for it.

## Vendor evaluation criteria

| Criterion                            |
| ------------------------------------ |
| Kenya/Africa formulary relevance     |
| API availability                     |
| Ingredient and brand mapping support |
| DDI severity tiers                   |
| Allergy cross-reactivity             |
| Duplicate therapy support            |
| Pregnancy/lactation support          |
| Paediatric warnings                  |
| Renal/hepatic dosing support         |
| Update frequency                     |
| Licensing cost                       |
| Offline/local cache rights           |
| Auditability of rule source          |
| Integration support                  |
| Liability terms                      |

## Vendor integration architecture

```text
Prescription event
    ↓
MedicationSafetyService
    ↓
CommercialCDSProvider adapter
    ↓
Vendor API / local dataset
    ↓
Normalized safety alerts
    ↓
Same alert UI and override workflow
```

This prevents the UI and pharmacy workflow from being rewritten if the knowledge provider changes.

---

# 18. Update to the risk register

Add these risks.

| Risk                                  | Severity | Mitigation                                                                  |
| ------------------------------------- | -------- | --------------------------------------------------------------------------- |
| No drug knowledge base                | Critical | Add KEML + RxNorm + curated safety tables + vendor-ready provider interface |
| Product ingredient mapping incomplete | Critical | Block prescription medicine activation until verified                       |
| Manual rules clinically incomplete    | High     | Limit MVP claims: “basic safety screening,” governance review               |
| Alert fatigue                         | High     | Severity tiers, suppression, override analytics                             |
| Outdated safety rules                 | High     | Versioning and review cycle                                                 |
| Commercial vendor dependency later    | Medium   | Provider abstraction                                                        |
| False negative warning                | High     | Disclaimers, pharmacist responsibility, rule source display                 |
| False positive warning                | Medium   | Override with reason, noise monitoring                                      |
| Pregnancy data mismatch               | High     | Use caution flags; require clinician/pharmacist judgement                   |
| Local brand not mapped to ingredient  | High     | Mapping workflow and unmapped product report                                |

---

# 19. Corrected Module 3 principle

Replace the previous principle:

```text
No prescription medicine should leave the pharmacy without a patient, a prescription, a responsible professional, a batch, instructions, and an audit trail.
```

With the stronger version:

```text
No prescription medicine should leave the pharmacy without a patient, prescription evidence, responsible professional approval, batch/expiry traceability, label instructions, audit trail, and a documented medication-safety screen based on an approved drug knowledge base.
```

---

# 20. Final recommendation

For this project, implement:

```text
MVP:
    KEML 2023 formulary foundation
    product-to-ingredient mapping
    RxNorm-ready identifiers
    ATC/local therapeutic classes
    AWaRe antibiotic flags
    curated allergy rules
    curated duplicate therapy rules
    curated pregnancy/breastfeeding warnings
    curated high-risk DDI rules
    pharmacist override workflow
    ADR/PvERS support

Version 2:
    broader open knowledge imports
    structured SPL/label-based warnings
    richer patient education
    expanded DDI and contraindication tables
    advanced alert analytics

Version 3:
    commercial CDS provider integration
    full enterprise-grade interaction/allergy/pregnancy/duplicate therapy engine
```

The important architectural rule is:

**The pharmacy system must not claim to perform medication safety checks unless it stores the source, version, mapping, rule, severity, alert, override, and responsible clinician/pharmacist decision behind every warning.**
