# Module 6: Lab-lite Module

This module is the **basic diagnostic workflow engine** for small clinics.

Modules 1–5 answer:

```text
Module 1: Is the clinic/lab/professional licensed?
Module 2: Was the test billed, paid, invoiced, and receipted?
Module 3: Did the prescription flow safely to pharmacy?
Module 4: Were reagents, consumables, stock, batch, and expiry controlled?
Module 5: Was the clinical visit documented?
Module 6: Was the lab test ordered, paid for, collected, resulted, verified, reported, and linked back to the patient visit?
```

A small clinic may not need a full laboratory information system, but it still needs a controlled workflow for:

```text
test catalogue → order → billing → sample collection → result entry → verification → clinician review → print/share → claims/reporting
```

For Kenya, the module should respect the fact that medical laboratory practice is regulated. KMLTTB states that it has statutory mandate over the training, business, practice, and employment of medical laboratory technicians and technologists in Kenya, and its professional-registration page states that every Medical Laboratory Science professional practising in Kenya must be registered and licensed with KMLTTB. ([kmlttb.org](https://www.kmlttb.org/)) ([kmlttb.org](https://www.kmlttb.org/registration/))

---

# 1. Purpose of the module

The Lab-lite Module should:

| Purpose                 | Practical meaning                                                   |
| ----------------------- | ------------------------------------------------------------------- |
| Maintain test catalogue | CBC, malaria, urinalysis, glucose, pregnancy test, etc.             |
| Receive orders          | From clinician, reception, package, or walk-in workflow             |
| Link tests to billing   | Prevent unbilled tests and claim gaps                               |
| Track samples           | Ordered, paid, collected, rejected, in process, resulted, verified  |
| Capture results         | Numeric, text, coded, attachment, panel result                      |
| Support verification    | Lab professional reviews before release                             |
| Print/share results     | Patient copy, clinician copy, claim/referral copy                   |
| Support external labs   | Track send-outs to partner/reference labs                           |
| Link to EMR             | Results return to patient visit and clinician review                |
| Link to inventory       | Reagents, test kits, vacutainers, strips, swabs, consumables        |
| Support audit           | Who ordered, collected, tested, verified, corrected, printed        |
| Support claims          | Diagnosis, order, result, billing, clinician, and facility evidence |

---

# 2. Kenya-specific design basis

## A. Laboratory professional and facility control

The Medical Laboratory Technicians and Technologists Act provides for the training, registration, and licensing of medical laboratory technicians and technologists and establishes KMLTTB. The Act defines “medical laboratory” broadly to include any facility where medical laboratory analysis and investigations are carried out, including hospital laboratories. It also gives the Board power to licence and regulate the business and practice of registered laboratory technicians and technologists. ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/1999/10/eng@2022-12-31))

Software implication:

| Requirement                             | Lab-lite behaviour                                                                          |
| --------------------------------------- | ------------------------------------------------------------------------------------------- |
| Lab service enabled only where licensed | Module 1 should confirm facility/lab permission                                             |
| Lab professional must be valid          | Result entry/verification should require active KMLTTB professional record                  |
| Lab in-charge/superintendent            | Branch should have responsible laboratory professional                                      |
| Lab branch-specific control             | Each branch should have its own lab setup, users, services, and reports                     |
| Scope of tests                          | Clinic should only offer tests it is configured, equipped, staffed, and licensed to perform |

KMLTTB’s public/private laboratory application form states that all medical laboratory services must be supervised by persons holding a practising certificate and annual licence, and that medical laboratory branches must apply, be inspected, registered, licensed, and have a different medical laboratory superintendent. ([kmlttb.org](https://www.kmlttb.org/downloads/APPLICATION%20FORM%20FOR%20PUBLIC%20%26%20PRIVATE%20LABORATORIES%20KMLTTBLAB06.pdf))

---

## B. Digital health and interoperability

Kenya’s Digital Health Act establishes shared digital-health resources such as a national health data dictionary, client registry, facility registry, health worker registry, interoperability layer, shared health records, health management information systems, and finance/insurance services. Lab data should therefore be structured enough to plug into future national interoperability requirements. ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/2023/15))

The 2025 Digital Health Data Exchange Component Regulations state that the national and county health data banks comprise centralized information systems that collate client-level minimum datasets and aggregate data from certified digital health solutions, and that transmitted data must be stored, reviewed, audited, updated, and secured in accordance with the Act and regulations. ([new.kenyalaw.org](https://new.kenyalaw.org/akn/ke/act/ln/2025/77/eng@2025-04-11))

Software implication:

| Requirement           | Lab-lite behaviour                                                     |
| --------------------- | ---------------------------------------------------------------------- |
| Structured test names | Use standard test catalogue, local codes, and LOINC-ready mapping      |
| Structured results    | Numeric, coded, text, reference ranges, abnormal flags                 |
| Patient-level linkage | Every result should link to patient, visit, order, and facility        |
| Audit trail           | Every result entry, verification, correction, print, and export logged |
| Interoperability      | FHIR-ready ServiceRequest, Specimen, Observation, DiagnosticReport     |
| Data quality          | Required fields, validation, corrected-result workflow                 |

HL7 FHIR’s ServiceRequest is used for orders or requests for services such as diagnostic investigations, and DiagnosticReport is intended for laboratory reports and can reference Observations as atomic results. LOINC provides universal names and codes for identifying laboratory and clinical test results and supports interoperability between systems. ([hl7.org](https://fhir.hl7.org/fhir/servicerequest.html)) ([hl7.org](https://fhir.hl7.org/fhir/diagnosticreport.html)) ([regenstrief.org](https://www.regenstrief.org/real-world-solutions/loinc/))

---

# 3. What “Lab-lite” means

A Lab-lite module is not a full enterprise LIS. It should avoid unnecessary complexity, but still handle the core outpatient lab workflow.

## Lab-lite includes

| Included            | Example                                                       |
| ------------------- | ------------------------------------------------------------- |
| Test catalogue      | Malaria test, CBC, urinalysis, pregnancy test                 |
| Basic ordering      | Clinician or reception orders test                            |
| Billing link        | Test must be paid/covered before processing, depending policy |
| Sample tracking     | Ordered, collected, resulted, verified                        |
| Result entry        | Numeric, coded, text, attachments                             |
| Result verification | Lab in-charge or authorized staff release result              |
| Result printout     | Patient and clinician copy                                    |
| Send-out tracking   | External reference lab workflow                               |
| Basic QC flagging   | Control results, kit lot, abnormal/critical flag              |
| Inventory link      | Kits/reagents/consumables consumed                            |
| Claims support      | Attach result to visit/claim                                  |
| Audit trail         | All lab actions logged                                        |

## Lab-lite does not need, at MVP stage

| Not necessary at MVP                  | Reason                                |
| ------------------------------------- | ------------------------------------- |
| Full analyser integration             | Expensive and complex                 |
| Advanced middleware                   | Not needed for small clinics          |
| Full ISO 15189 document-control suite | Can come later                        |
| Complex microbiology workflow         | Usually not done in small clinics     |
| Histopathology/cytology workflow      | Usually external send-out             |
| Blood bank workflow                   | High-risk, requires separate controls |
| Advanced QC/statistics                | Add in later versions                 |
| Full HL7 v2 analyser interfaces       | Add when volumes justify it           |

---

# 4. Core users

| User                         | Main actions                                                      |
| ---------------------------- | ----------------------------------------------------------------- |
| Receptionist                 | Registers patient, bills lab test, sends to lab queue             |
| Clinician                    | Orders tests, reviews results, acts on result                     |
| Lab technician/technologist  | Collects sample, performs test, enters result                     |
| Lab in-charge/superintendent | Verifies results, manages catalogue, handles QC/send-outs         |
| Nurse/triage staff           | May collect simple samples where allowed by facility policy       |
| Billing officer              | Confirms payment, insurer/SHA cover, credit, package billing      |
| Claims officer               | Uses result as evidence for claim                                 |
| Branch manager               | Reviews lab revenue, pending tests, rejected samples              |
| Inventory/storekeeper        | Manages kits, reagents, tubes, strips                             |
| Auditor/compliance officer   | Reviews result changes, access logs, unbilled tests, verification |

---

# 5. Relationship with other modules

## Module 1: Organisation and Licensing

| Data from Module 1            | Lab-lite use                            |
| ----------------------------- | --------------------------------------- |
| KMPDC facility licence        | Confirms clinic facility status         |
| KMLTTB lab facility record    | Enables lab services                    |
| Lab in-charge/superintendent  | Required for lab governance             |
| Lab professional licences     | Controls result entry/verification      |
| Branch service permissions    | Determines which tests can be performed |
| SHA/private insurer contracts | Enables payer lab claims                |

## Module 2: POS and Billing

| Billing event         | Lab-lite effect                             |
| --------------------- | ------------------------------------------- |
| Lab test billed       | Order can proceed                           |
| Payment completed     | Sample collection/testing allowed           |
| Insurer authorization | Claim-linked order allowed                  |
| Credit customer bill  | Lab proceeds if credit policy allows        |
| Refund/credit note    | Lab order cancellation or correction        |
| eTIMS invoice         | Test sale recorded for tax/commercial audit |

## Module 4: Inventory

| Inventory item | Lab-lite use                                    |
| -------------- | ----------------------------------------------- |
| Test kits      | Malaria RDT, pregnancy kit                      |
| Reagents       | Chemistry/haematology/urinalysis                |
| Consumables    | Gloves, lancets, vacutainers, swabs, slides     |
| Batch/expiry   | Kit/reagent safety and traceability             |
| Cold-chain     | Temperature-sensitive reagents/kits             |
| Stockout       | Prevent ordering tests that cannot be performed |
| QC material    | Quality control tracking                        |

## Module 5: Clinic EMR

| EMR event                     | Lab-lite effect             |
| ----------------------------- | --------------------------- |
| Clinician orders test         | Lab order created           |
| Diagnosis/clinical indication | Linked to lab order         |
| Result released               | EMR receives result         |
| Critical result               | Clinician alerted           |
| Visit summary                 | Lab result included         |
| Claim packet                  | Result attached as evidence |

---

# 6. Core lab transaction types

| Transaction               | Description                                     |
| ------------------------- | ----------------------------------------------- |
| Clinician-ordered test    | Test ordered during consultation                |
| Reception-ordered test    | Walk-in or package test ordered at front desk   |
| Package/bundle test       | Consultation + lab package                      |
| Paid lab test             | Cash/M-Pesa/card paid test                      |
| Insurer/SHA lab test      | Payer-covered test                              |
| Credit/corporate lab test | Employer/company account                        |
| External send-out         | Sample sent to reference lab                    |
| Repeat/retest             | Result repeated due to error/QC/clinical reason |
| Cancelled test            | Test cancelled before completion                |
| Rejected sample           | Sample unsuitable for testing                   |
| Corrected result          | Result amended after release                    |
| Critical result           | Urgent abnormal result requiring escalation     |

---

# 7. Feature-by-feature design

## A. Test catalogue

The test catalogue is the foundation. It determines what can be ordered, billed, collected, resulted, printed, claimed, and reported.

### Common small-clinic test catalogue

| Category                     | Tests                                                                |
| ---------------------------- | -------------------------------------------------------------------- |
| Malaria/fever                | Malaria RDT, malaria microscopy where available                      |
| Haematology                  | CBC/FBC, haemoglobin, blood group if offered                         |
| Urine                        | Urinalysis, urine microscopy, pregnancy test                         |
| Glucose/diabetes             | Random blood sugar, fasting blood sugar, HbA1c if available/external |
| Infectious disease screening | HIV test, HBsAg, syphilis, COVID/flu where configured and compliant  |
| Stool                        | Stool microscopy, occult blood where available                       |
| Chemistry                    | Urea/creatinine, LFTs, lipids, electrolytes if available/external    |
| Reproductive health          | Pregnancy test, antenatal screening tests                            |
| External send-out            | Tests not performed in-house                                         |
| Procedure-linked tests       | Pre-op or certificate-related tests where lawful                     |

### Test catalogue fields

| Field                    |          Required? | Notes                                    |
| ------------------------ | -----------------: | ---------------------------------------- |
| Test code                |                Yes | Internal code                            |
| Test name                |                Yes | Example: Malaria RDT                     |
| Short name               |        Recommended | For receipts and screens                 |
| Test category            |                Yes | Haematology, chemistry, urine, etc.      |
| Local code               |                Yes | Facility code                            |
| LOINC code               | Optional/MVP-ready | For interoperability                     |
| Specimen type            |                Yes | Blood, urine, stool, swab, serum, plasma |
| Collection container     |        Recommended | EDTA tube, urine container, plain tube   |
| Sample volume            |           Optional | Useful for venous blood tests            |
| Method                   |           Optional | RDT, microscopy, analyser, manual        |
| Result type              |                Yes | Numeric, coded, text, panel, attachment  |
| Unit                     |         If numeric | mmol/L, g/dL, %, cells/µL                |
| Reference range          |        Recommended | Age/sex-specific where possible          |
| Critical limits          |           Optional | Triggers urgent alert                    |
| Turnaround time          |        Recommended | Example: 15 min, 2 hrs, 24 hrs           |
| In-house or external     |                Yes | Determines workflow                      |
| External lab partner     |        If send-out | Default reference lab                    |
| Price                    |                Yes | Linked to price list                     |
| Tax code                 |                Yes | For billing/eTIMS configuration          |
| Claim code/tariff        |         If insured | SHA/private insurer mapping              |
| Consumables used         |           Optional | Inventory deduction                      |
| Reagent/test-kit link    |           Optional | Stock control                            |
| Requires fasting         |             Yes/no | Patient instruction                      |
| Requires consent         |             Yes/no | Sensitive tests                          |
| Requires clinician order |             Yes/no | Prevent inappropriate walk-in tests      |
| Requires verification    |             Yes/no | Usually yes                              |
| Active status            |                Yes | Active/inactive/discontinued             |

### Test catalogue rules

| Rule                          | System behaviour                                    |
| ----------------------------- | --------------------------------------------------- |
| Test inactive                 | Cannot order                                        |
| Test external                 | Route to send-out workflow                          |
| Test requires payment         | Block collection/testing until billing status valid |
| Test requires clinician order | Reception cannot order without clinician            |
| Test requires consent         | Capture consent before collection                   |
| Test has no price             | Block billing                                       |
| Test has no result template   | Warn before activation                              |
| Test has consumables          | Check stock availability                            |
| Test has critical limits      | Auto-flag critical result                           |
| Insurer/SHA test              | Apply payer tariff and authorization rules          |

---

## B. Sample status

Sample tracking prevents lost samples, unpaid testing, duplicate results, and unclear accountability.

### Recommended sample/order lifecycle

```text
Ordered
Awaiting billing
Billed
Paid / Covered / Approved credit
Awaiting collection
Collected
Rejected
In process
Result entered
Pending verification
Verified
Released
Printed / Shared
Clinician reviewed
Completed
```

Exception statuses:

```text
Cancelled
Refund pending
Repeat requested
Corrected
Sent out
Received by external lab
External result received
Delayed
Lost
```

### Order-level status versus sample-level status

A single order may have multiple tests and samples. For example:

```text
Order: Fever workup
Tests: Malaria RDT, CBC, urinalysis
Samples: Finger-prick blood, EDTA blood, urine
```

Therefore, the system should track:

| Level           | Example                                      |
| --------------- | -------------------------------------------- |
| Lab order       | Whole order/request                          |
| Test line       | CBC, malaria, urinalysis                     |
| Specimen/sample | EDTA tube, urine container                   |
| Result          | Hb, WBC, platelet, malaria positive/negative |

### Sample fields

| Field                   |   Required? | Notes                                                  |
| ----------------------- | ----------: | ------------------------------------------------------ |
| Sample ID/barcode       |         Yes | Unique                                                 |
| Order ID                |         Yes | Link to order                                          |
| Patient                 |         Yes | Link                                                   |
| Visit                   | Recommended | Link to EMR                                            |
| Specimen type           |         Yes | Blood, urine, stool                                    |
| Collection container    | Recommended | EDTA/plain/urine container                             |
| Collected by            |         Yes | User                                                   |
| Collection date/time    |         Yes |                                                        |
| Collection location     |    Optional | Lab, ward, outreach                                    |
| Sample condition        |         Yes | Acceptable, clotted, haemolysed, insufficient, leaking |
| Sample status           |         Yes | Collected, rejected, sent out, processed               |
| Rejection reason        | If rejected | Mandatory                                              |
| Received by lab         |    Optional | For split collection/testing                           |
| Received date/time      |    Optional |                                                        |
| Storage condition       |    Optional | Room temp/fridge/frozen                                |
| Dispatch details        | If external | Courier/reference lab                                  |
| Chain-of-custody events | Recommended | Collection, dispatch, receipt                          |

### Sample status rules

| Rule                                  | System behaviour                                                  |
| ------------------------------------- | ----------------------------------------------------------------- |
| Order not billed/covered              | Block collection/testing unless emergency or credit policy allows |
| Sample not collected                  | Result entry blocked                                              |
| Sample rejected                       | Result entry blocked; recollection task created                   |
| Sample collected by unauthorized user | Block or require lab in-charge approval                           |
| External sample                       | Must have dispatch and receiving lab details                      |
| Critical test delayed                 | Alert lab and clinician                                           |
| Sample lost                           | Incident and recollection workflow                                |
| Duplicate sample ID                   | Block                                                             |
| Result entered before collection      | Block unless legacy/external upload workflow                      |

---

## C. Result entry

Result entry must handle simple rapid tests, numeric tests, panel tests, text reports, and uploaded external PDFs.

### Result types

| Result type       | Example                               |
| ----------------- | ------------------------------------- |
| Numeric           | Glucose 7.8 mmol/L                    |
| Coded             | Positive/negative                     |
| Semi-quantitative | Protein ++, ketones +                 |
| Text              | “No malaria parasites seen”           |
| Panel             | CBC with Hb, WBC, platelets           |
| Attachment        | External lab PDF                      |
| Image             | Microscopy image, scanned report      |
| Comment-only      | “Sample haemolysed; repeat requested” |

### Result fields

| Field                     |               Required? | Notes                                    |
| ------------------------- | ----------------------: | ---------------------------------------- |
| Result ID                 |                     Yes | Auto                                     |
| Order/test ID             |                     Yes |                                          |
| Sample ID                 |  Yes where sample-based |                                          |
| Patient                   |                    Auto |                                          |
| Visit                     |                    Auto |                                          |
| Test name                 |                    Auto |                                          |
| Result value              |                     Yes | Numeric/coded/text                       |
| Unit                      |              If numeric |                                          |
| Reference range           |             Recommended | Auto from catalogue                      |
| Abnormal flag             |             Auto/manual | Low, high, critical                      |
| Interpretation            |                Optional | Reactive/non-reactive, positive/negative |
| Result comment            |                Optional |                                          |
| Method                    |                Optional | RDT/analyser/manual                      |
| Kit/reagent lot           |             Recommended | Traceability                             |
| Kit/reagent expiry        |             Recommended |                                          |
| Result entered by         |                    Auto |                                          |
| Result entered at         |                    Auto |                                          |
| Verified by               | Required before release |                                          |
| Verified at               | Required before release |                                          |
| Corrected result flag     |              If amended |                                          |
| Previous result reference |            If corrected |                                          |
| Attachment                |                Optional | PDF/image                                |
| Clinician reviewed        |                  Yes/no |                                          |
| Patient notified          |                  Yes/no |                                          |

### Reference range configuration

Reference ranges should be configurable by:

| Factor    | Example                                    |
| --------- | ------------------------------------------ |
| Age       | Child versus adult                         |
| Sex       | Male/female Hb range                       |
| Pregnancy | Pregnancy-specific ranges where configured |
| Method    | Lab method/analyser differences            |
| Unit      | mmol/L versus mg/dL                        |
| Facility  | Different devices/reference materials      |

### Abnormal and critical flags

| Flag              | Behaviour                            |
| ----------------- | ------------------------------------ |
| Normal            | No special action                    |
| Low               | Mark low                             |
| High              | Mark high                            |
| Critical low      | Alert clinician/lab in-charge        |
| Critical high     | Alert clinician/lab in-charge        |
| Positive/reactive | Follow configured notification rules |
| Invalid           | Repeat/recollect                     |
| Indeterminate     | Require comment and possible repeat  |

### Result correction model

The system should not silently overwrite released results.

| Correction step           | System behaviour                      |
| ------------------------- | ------------------------------------- |
| User requests correction  | Reason required                       |
| Original result retained  | Historical record remains             |
| Corrected result created  | New version issued                    |
| Correction approved       | Lab in-charge verifies                |
| Clinician notified        | If result already released            |
| Printout marked corrected | Shows corrected report status         |
| Audit preserved           | Old and new values visible to auditor |

---

## D. Billing link

The lab module must prevent unbilled tests, while still allowing emergency or credit-policy exceptions.

### Billing states

| Billing state   | Meaning                             |
| --------------- | ----------------------------------- |
| Not billable    | Included in package/no charge/admin |
| Pending billing | Order created but not billed        |
| Billed unpaid   | Invoice created, payment pending    |
| Paid            | Patient paid                        |
| Covered         | Insurer/SHA/corporate approved      |
| Credit approved | Customer account allowed            |
| Waived          | Authorized waiver                   |
| Refunded        | Payment reversed                    |
| Cancelled       | Test cancelled                      |

### Billing rules

| Rule                             | System behaviour                                             |
| -------------------------------- | ------------------------------------------------------------ |
| Payment-before-test policy       | Block collection until paid/covered                          |
| Payment-after-consult policy     | Allow test but flag unpaid until billing                     |
| Emergency policy                 | Allow collection, require later billing reason               |
| Insurer/SHA test                 | Require eligibility/preauth where configured                 |
| Corporate credit                 | Check credit limit and active contract                       |
| Test not priced                  | Cannot bill/order live test                                  |
| Cancelled before collection      | Reverse/credit billing if paid                               |
| Cancelled after collection       | Manager decision: refund/no refund                           |
| Result cannot be released unpaid | Configurable; recommended for cash patients                  |
| Claim packet                     | Include order, result, clinician, diagnosis, tariff, invoice |

### Billing integration flow

```text
Clinician orders test
→ Lab order appears in billing
→ Billing confirms payment/cover
→ Lab sees test as collectable
→ Lab collects sample
→ Result is entered and verified
→ Result returns to EMR
→ Claim/receipt/visit summary updated
```

### No-unbilled-test control

The system should produce a daily report:

| Report column                       |
| ----------------------------------- |
| Order number                        |
| Patient                             |
| Test                                |
| Ordered by                          |
| Billing status                      |
| Sample status                       |
| Result status                       |
| Reason if test done without payment |
| Approved by                         |

---

## E. Result printout

The result printout must be professional, readable, and controlled.

### Result printout contents

| Section                | Contents                                                            |
| ---------------------- | ------------------------------------------------------------------- |
| Facility header        | Clinic/lab name, branch, contacts, licence details where configured |
| Patient details        | Name, age, sex, patient number                                      |
| Visit/order details    | Order number, sample number, request date                           |
| Clinician              | Ordering clinician                                                  |
| Test details           | Test name, specimen, method                                         |
| Result                 | Value, unit, reference range, abnormal flag                         |
| Interpretation/comment | Lab comment                                                         |
| Collection details     | Collection date/time                                                |
| Result date            | Resulted and verified date/time                                     |
| Verified by            | Lab professional name/signature/PIN where configured                |
| Report status          | Final, preliminary, corrected, amended                              |
| QR/barcode             | Optional verification                                               |
| Footer                 | Confidentiality note, page number                                   |

### Printout types

| Type                 | Use                               |
| -------------------- | --------------------------------- |
| Patient copy         | Given to patient                  |
| Clinician copy       | Internal EMR view/print           |
| Claim copy           | Payer documentation               |
| Referral copy        | Attached to referral letter       |
| External upload copy | Scanned/PDF partner lab result    |
| Corrected report     | Replaces previously issued result |

### Result release rules

| Rule                         | System behaviour                                       |
| ---------------------------- | ------------------------------------------------------ |
| Result not verified          | Print with “unverified/draft” watermark or block print |
| Result corrected             | Print corrected version with correction status         |
| Sensitive result             | Restrict print/share permissions                       |
| Result reprint               | Require reason and log user                            |
| Patient copy by WhatsApp/SMS | Use secure link or minimal content, consent required   |
| Result shared externally     | Log recipient and purpose                              |

---

## F. External lab send-out

Small clinics often outsource tests they cannot perform. The module should track the sample, external lab, cost, status, and returned result.

### Send-out use cases

| Use case                    | Example                                   |
| --------------------------- | ----------------------------------------- |
| Test not available in-house | HbA1c, LFT, renal profile                 |
| Equipment breakdown         | CBC analyser unavailable                  |
| Specialist test             | Hormones, cultures, histology             |
| Confirmatory test           | Positive screening requiring confirmation |
| Insurance/payer requirement | Approved reference lab                    |
| Quality assurance           | Repeat/confirmation externally            |

### External lab partner fields

| Field                         |       Required? |                                     |
| ----------------------------- | --------------: | ----------------------------------- |
| External lab name             |             Yes |                                     |
| Contact person                |     Recommended |                                     |
| Phone/email                   |     Recommended |                                     |
| Address                       |     Recommended |                                     |
| Licence/accreditation details |     Recommended |                                     |
| Contract status               |     Recommended |                                     |
| Price list                    |     Recommended |                                     |
| Turnaround time               |     Recommended |                                     |
| Sample requirements           |     Recommended |                                     |
| Courier/dispatch method       |     Recommended |                                     |
| Result delivery method        |             Yes | Portal, email, WhatsApp, paper, API |
| Payment terms                 |     Recommended |                                     |
| Status                        | Active/inactive |                                     |

### Send-out order fields

| Field                  |         Required? | Notes                                |
| ---------------------- | ----------------: | ------------------------------------ |
| Send-out number        |               Yes | Auto                                 |
| Patient                |               Yes |                                      |
| Visit/order            |               Yes |                                      |
| Test                   |               Yes |                                      |
| External lab           |               Yes |                                      |
| Sample ID              |               Yes |                                      |
| Sample type            |               Yes |                                      |
| Collection date/time   |               Yes |                                      |
| Dispatch date/time     |               Yes |                                      |
| Dispatched by          |               Yes |                                      |
| Courier/driver         |          Optional |                                      |
| Receiving lab contact  |          Optional |                                      |
| Received confirmation  |       Recommended |                                      |
| Expected result date   |       Recommended |                                      |
| External lab reference |       Recommended |                                      |
| External cost          |       Recommended | Margin                               |
| Patient charge         |               Yes | Billing                              |
| Status                 |               Yes | Sent, received, processing, resulted |
| Result attachment      | Yes when returned | PDF/image                            |
| Result values          |          Optional | Structured entry                     |
| Verified internally    |            Yes/no | Local review before release          |
| Delay reason           |        If delayed |                                      |

### Send-out status lifecycle

```text
Ordered
Billed/covered
Collected
Packed
Dispatched
Received by external lab
In process externally
External result received
Internal review pending
Verified/released
Completed
```

Exception statuses:

```text
Rejected by external lab
Lost in transit
Delayed
Cancelled
Recollection required
Corrected by external lab
```

### Send-out rules

| Rule                               | System behaviour                                          |
| ---------------------------------- | --------------------------------------------------------- |
| External test ordered              | Route to send-out workflow                                |
| Sample not collected               | Cannot dispatch                                           |
| Dispatch missing                   | Send-out remains pending                                  |
| External lab overdue               | Alert lab/reception/clinician                             |
| Result received as PDF             | Attach to result and optionally extract structured values |
| External result not reviewed       | Do not release until internal review, if policy requires  |
| External lab cost missing          | Warn margin/accounting                                    |
| External lab rejects sample        | Create recollection/refund/credit workflow                |
| Result from external lab corrected | Keep old result and issue corrected report                |

---

# 8. Required screens

## Screen 1: Lab dashboard

Cards:

```text
Orders waiting billing
Orders ready for collection
Samples collected
Samples rejected
Tests in process
Results pending verification
Critical results
External send-outs pending
External results overdue
Unbilled lab tests
Lab revenue today
```

---

## Screen 2: Test catalogue

Sections:

| Section          | Contents                                   |
| ---------------- | ------------------------------------------ |
| Identity         | Test name, code, category                  |
| Specimen         | Type, container, volume                    |
| Result template  | Numeric/coded/text/panel                   |
| Reference ranges | Age/sex/method-specific                    |
| Billing          | Price, tariff, tax, claim code             |
| Workflow         | In-house/external, TAT, verification       |
| Inventory        | Test kit, reagent, consumables             |
| Controls         | Requires fasting, consent, clinician order |
| Interoperability | LOINC code, FHIR mapping                   |
| Status           | Active/inactive                            |

---

## Screen 3: Lab order screen

Used by clinician or reception.

Fields:

| Field                         |
| ----------------------------- |
| Patient                       |
| Visit                         |
| Ordering clinician            |
| Diagnosis/clinical indication |
| Test(s)                       |
| Priority                      |
| Payer                         |
| Billing status                |
| Notes                         |
| Sample instructions           |

Actions:

```text
Order test
Send to billing
Cancel order
Print sample label
```

---

## Screen 4: Sample collection screen

Features:

| Feature                              |
| ------------------------------------ |
| Search by patient/order/queue number |
| Show paid/covered status             |
| Print sample barcode                 |
| Capture specimen type                |
| Capture collected by/date/time       |
| Capture sample condition             |
| Reject sample with reason            |
| Send to testing or send-out          |

---

## Screen 5: Result entry screen

Features:

| Feature                             |
| ----------------------------------- |
| Test-specific template              |
| Numeric result entry                |
| Unit and reference range            |
| Positive/negative dropdown          |
| Urinalysis semi-quantitative fields |
| CBC panel fields                    |
| Text comments                       |
| Attachment upload                   |
| Abnormal/critical flag              |
| Save draft                          |
| Submit for verification             |

---

## Screen 6: Result verification screen

Features:

| Feature                      |
| ---------------------------- |
| Pending verification queue   |
| Patient/order/sample context |
| Result values                |
| Reference ranges             |
| Critical flags               |
| Previous results             |
| Kit/reagent lot              |
| Approve/reject/correct       |
| Verification signature/PIN   |
| Release result               |

---

## Screen 7: Result print/share screen

Features:

| Feature                 |
| ----------------------- |
| Result preview          |
| Patient copy            |
| Clinician copy          |
| Claim copy              |
| Print PDF               |
| Send secure link        |
| Reprint reason          |
| Corrected report status |
| Print history           |

---

## Screen 8: External lab send-out screen

Sections:

| Section        | Contents                                    |
| -------------- | ------------------------------------------- |
| Send-out order | Patient, test, sample                       |
| External lab   | Partner lab and contact                     |
| Dispatch       | Courier, date/time, tracking                |
| Status         | Sent, received, processing, result received |
| Result         | Attachment/structured values                |
| Billing        | Patient charge, external cost               |
| Delay tracking | Overdue reason and follow-up                |
| Audit          | Chain of custody                            |

---

## Screen 9: Lab reports screen

Filters:

| Filter            |
| ----------------- |
| Date              |
| Branch            |
| Test              |
| Status            |
| Lab user          |
| Clinician         |
| Billing status    |
| Payer             |
| External lab      |
| Critical results  |
| Rejected samples  |
| Corrected results |

---

# 9. Workflows

## A. Clinician-ordered test

```text
1. Clinician orders test from EMR
2. Diagnosis/clinical indication is linked
3. Order appears in billing
4. Patient pays or payer cover is confirmed
5. Lab collects sample
6. Lab performs test
7. Result is entered
8. Result is verified
9. Result returns to clinician
10. Clinician reviews and updates plan
11. Result can be printed/shared
```

---

## B. Walk-in lab test

```text
1. Reception registers/selects patient
2. Reception selects test from catalogue
3. Billing confirms payment
4. Lab collects sample
5. Result is entered and verified
6. Patient receives result
7. If abnormal/critical, clinician review is recommended or required by policy
```

---

## C. Malaria RDT workflow

```text
1. Test ordered and paid/covered
2. Sample collected
3. RDT kit lot/expiry captured if configured
4. Result entered as positive/negative/invalid
5. Invalid result triggers repeat
6. Result verified
7. Clinician notified
8. Result appears in visit summary
```

---

## D. CBC panel workflow

```text
1. CBC ordered
2. EDTA sample collected
3. Result template opens CBC panel
4. Hb, WBC, platelet, RBC indices entered or imported
5. Abnormal values are flagged
6. Critical values trigger alert
7. Lab in-charge verifies result
8. Result is released to EMR/patient
```

---

## E. Urinalysis workflow

```text
1. Urinalysis ordered
2. Urine sample collected
3. Dipstick/microscopy fields entered
4. Semi-quantitative values captured: protein, glucose, ketones, blood, nitrite, leukocytes
5. Comments entered
6. Result verified and released
```

---

## F. External send-out workflow

```text
1. Clinician/reception orders external test
2. Patient pays or payer cover is confirmed
3. Sample is collected
4. Sample is packed and dispatched
5. External lab receipt is recorded
6. External result is received
7. Result PDF is uploaded or values entered
8. Internal lab user reviews/verifies
9. Result is released to clinician/patient
10. External cost and margin are recorded
```

---

## G. Sample rejection workflow

```text
1. Sample is found unsuitable
2. Lab user selects rejection reason
3. Order is marked sample rejected
4. Clinician/reception is notified
5. Recollection task is created
6. Billing rule decides refund/no refund/recollection free
7. Rejected sample appears in quality report
```

---

## H. Corrected result workflow

```text
1. Error is identified after result entry or release
2. Lab user requests correction
3. Reason is captured
4. Original result remains locked
5. Corrected result version is created
6. Lab in-charge verifies correction
7. Clinician and patient are notified where appropriate
8. Corrected report is printed/shared
9. Audit trail shows full history
```

---

# 10. Rules engine

## Test ordering

```text
RULE: Order lab test
IF test.status = active
AND branch.lab_service_enabled = true
AND test.available_at_branch = true
THEN allow order
ELSE block order
```

## Billing control

```text
RULE: Collect sample
IF lab_order.billing_status IN [paid, covered, credit_approved, waived]
OR lab_order.emergency_override = true
THEN allow sample collection
ELSE block collection
```

## Result entry

```text
RULE: Enter result
IF sample.status = collected
AND user.role IN [lab_technician, lab_technologist, lab_in_charge]
AND user.professional_licence_status = active
THEN allow result entry
ELSE block
```

## Verification

```text
RULE: Verify result
IF result.status = pending_verification
AND verifier.has_lab_verification_permission = true
AND verifier.professional_licence_status = active
THEN allow verification and release
ELSE block
```

## Critical result

```text
RULE: Critical result alert
IF result.value < test.critical_low
OR result.value > test.critical_high
OR result.coded_value IN configured_critical_values
THEN mark critical
AND alert ordering clinician
AND require notification action log
```

## External send-out

```text
RULE: Send external sample
IF test.performance_location = external
AND sample.status = collected
AND external_lab.status = active
AND billing_status IN [paid, covered, credit_approved]
THEN allow dispatch
ELSE block
```

## Result printing

```text
RULE: Print result
IF result.status = verified
THEN allow final printout
ELSE print draft/unverified copy only if user has permission
```

## Result correction

```text
RULE: Correct released result
IF result.status = released
THEN require correction_reason
AND create new version
AND require verification
AND notify clinician if already reviewed/released
```

---

# 11. Data model

## Main tables

### `lab_tests`

| Field                    |
| ------------------------ |
| id                       |
| test_code                |
| test_name                |
| short_name               |
| category                 |
| loinc_code               |
| specimen_type            |
| collection_container     |
| sample_volume            |
| method                   |
| result_type              |
| unit                     |
| default_reference_range  |
| turnaround_time_minutes  |
| performance_location     |
| default_external_lab_id  |
| price                    |
| tax_code_id              |
| claim_code               |
| requires_fasting         |
| requires_consent         |
| requires_clinician_order |
| requires_verification    |
| active_status            |
| created_at               |

### `lab_test_panels`

| Field             |
| ----------------- |
| id                |
| panel_test_id     |
| component_test_id |
| display_order     |
| required_flag     |

### `lab_reference_ranges`

| Field            |
| ---------------- |
| id               |
| lab_test_id      |
| sex              |
| min_age_days     |
| max_age_days     |
| pregnancy_status |
| method           |
| unit             |
| low_value        |
| high_value       |
| critical_low     |
| critical_high    |
| text_range       |
| active_status    |

### `lab_orders`

| Field               |
| ------------------- |
| id                  |
| order_number        |
| patient_id          |
| visit_id            |
| branch_id           |
| ordered_by          |
| order_source        |
| clinical_indication |
| diagnosis_id        |
| priority            |
| payer_type          |
| billing_status      |
| order_status        |
| created_at          |
| cancelled_at        |
| cancellation_reason |

### `lab_order_lines`

| Field                |
| -------------------- |
| id                   |
| lab_order_id         |
| lab_test_id          |
| performance_location |
| external_lab_id      |
| price                |
| billing_line_id      |
| status               |
| sample_required      |
| result_status        |
| created_at           |

### `lab_samples`

| Field             |
| ----------------- |
| id                |
| sample_number     |
| barcode           |
| lab_order_id      |
| lab_order_line_id |
| patient_id        |
| visit_id          |
| specimen_type     |
| container         |
| collected_by      |
| collected_at      |
| received_by       |
| received_at       |
| sample_condition  |
| sample_status     |
| rejection_reason  |
| storage_condition |
| notes             |

### `lab_results`

| Field                    |
| ------------------------ |
| id                       |
| result_number            |
| lab_order_line_id        |
| sample_id                |
| patient_id               |
| visit_id                 |
| result_type              |
| result_value_numeric     |
| result_value_text        |
| result_value_code        |
| unit                     |
| reference_range_text     |
| abnormal_flag            |
| critical_flag            |
| interpretation           |
| method                   |
| reagent_lot              |
| reagent_expiry           |
| entered_by               |
| entered_at               |
| status                   |
| verified_by              |
| verified_at              |
| released_at              |
| clinician_reviewed_by    |
| clinician_reviewed_at    |
| result_version           |
| corrected_from_result_id |

### `lab_result_components`

| Field             |
| ----------------- |
| id                |
| lab_result_id     |
| component_test_id |
| component_name    |
| value_numeric     |
| value_text        |
| value_code        |
| unit              |
| reference_range   |
| abnormal_flag     |
| critical_flag     |
| display_order     |

### `external_labs`

| Field                    |
| ------------------------ |
| id                       |
| lab_name                 |
| contact_person           |
| phone                    |
| email                    |
| address                  |
| licence_number           |
| accreditation_details    |
| contract_status          |
| payment_terms            |
| default_turnaround_hours |
| result_delivery_method   |
| status                   |

### `external_lab_sendouts`

| Field                     |
| ------------------------- |
| id                        |
| sendout_number            |
| lab_order_line_id         |
| sample_id                 |
| external_lab_id           |
| dispatch_datetime         |
| dispatched_by             |
| courier_name              |
| tracking_reference        |
| received_confirmation     |
| received_by_external_lab  |
| expected_result_datetime  |
| external_reference_number |
| external_cost             |
| patient_charge            |
| status                    |
| delay_reason              |
| result_received_at        |
| reviewed_by               |
| reviewed_at               |

### `lab_result_documents`

| Field         |
| ------------- |
| id            |
| lab_result_id |
| document_type |
| file_url      |
| file_hash     |
| uploaded_by   |
| uploaded_at   |
| status        |

### `lab_quality_events`

| Field        |
| ------------ |
| id           |
| event_type   |
| lab_order_id |
| sample_id    |
| result_id    |
| description  |
| severity     |
| action_taken |
| reported_by  |
| reviewed_by  |
| created_at   |
| closed_at    |
| status       |

### `lab_audit_logs`

| Field          |
| -------------- |
| id             |
| entity_type    |
| entity_id      |
| patient_id     |
| visit_id       |
| action         |
| old_value_json |
| new_value_json |
| reason         |
| performed_by   |
| branch_id      |
| device_id      |
| created_at     |

---

# 12. API design

## Test catalogue endpoints

| Endpoint                                | Purpose             |
| --------------------------------------- | ------------------- |
| `POST /lab/tests`                       | Create test         |
| `GET /lab/tests/search`                 | Search catalogue    |
| `PATCH /lab/tests/{id}`                 | Update test         |
| `POST /lab/tests/{id}/reference-ranges` | Add reference range |
| `POST /lab/tests/{id}/activate`         | Activate test       |
| `POST /lab/tests/{id}/deactivate`       | Deactivate test     |

## Order endpoints

| Endpoint                                | Purpose           |
| --------------------------------------- | ----------------- |
| `POST /lab/orders`                      | Create lab order  |
| `POST /lab/orders/{id}/lines`           | Add test          |
| `POST /lab/orders/{id}/send-to-billing` | Link to billing   |
| `POST /lab/orders/{id}/cancel`          | Cancel order      |
| `GET /lab/orders/search`                | Search orders     |
| `GET /lab/orders/pending`               | Pending lab queue |

## Sample endpoints

| Endpoint                         | Purpose               |
| -------------------------------- | --------------------- |
| `POST /lab/samples`              | Create/collect sample |
| `POST /lab/samples/{id}/receive` | Mark received by lab  |
| `POST /lab/samples/{id}/reject`  | Reject sample         |
| `POST /lab/samples/{id}/barcode` | Generate barcode      |
| `GET /lab/samples/search`        | Search samples        |

## Result endpoints

| Endpoint                                     | Purpose               |
| -------------------------------------------- | --------------------- |
| `POST /lab/results`                          | Enter result          |
| `POST /lab/results/{id}/submit-verification` | Send for verification |
| `POST /lab/results/{id}/verify`              | Verify result         |
| `POST /lab/results/{id}/release`             | Release result        |
| `POST /lab/results/{id}/correct`             | Correct result        |
| `POST /lab/results/{id}/review`              | Clinician review      |
| `POST /lab/results/{id}/print`               | Print result          |
| `POST /lab/results/{id}/share`               | Share result securely |

## External send-out endpoints

| Endpoint                                  | Purpose                      |
| ----------------------------------------- | ---------------------------- |
| `POST /lab/external-labs`                 | Add partner lab              |
| `POST /lab/sendouts`                      | Create send-out              |
| `POST /lab/sendouts/{id}/dispatch`        | Dispatch sample              |
| `POST /lab/sendouts/{id}/confirm-receipt` | External lab received        |
| `POST /lab/sendouts/{id}/result`          | Upload/enter external result |
| `POST /lab/sendouts/{id}/delay`           | Record delay                 |
| `GET /lab/sendouts/overdue`               | Overdue send-outs            |

## Reporting endpoints

| Endpoint                             | Purpose                 |
| ------------------------------------ | ----------------------- |
| `GET /lab/reports/daily`             | Daily lab report        |
| `GET /lab/reports/pending-results`   | Pending results         |
| `GET /lab/reports/unbilled-tests`    | Unbilled tests          |
| `GET /lab/reports/rejected-samples`  | Sample rejection report |
| `GET /lab/reports/critical-results`  | Critical result report  |
| `GET /lab/reports/external-sendouts` | Send-out report         |

---

# 13. Integration points

| Integration             | Purpose                                                 |
| ----------------------- | ------------------------------------------------------- |
| Organisation/licensing  | Facility/lab/professional permission checks             |
| EMR                     | Orders, diagnosis, results, clinician review            |
| POS/billing             | Test billing, payment, eTIMS, refunds                   |
| Claims                  | Result evidence, tariffs, authorization                 |
| Inventory               | Kits, reagents, consumables, batch/expiry               |
| Notifications           | Critical results, ready results, delayed send-outs      |
| Document storage        | PDF results, external reports, attachments              |
| Audit/security          | Access, correction, print, export logs                  |
| FHIR API                | ServiceRequest, Specimen, Observation, DiagnosticReport |
| LOINC mapping           | Standard lab test/result identifiers                    |
| External lab portal/API | Future partner-lab integration                          |

---

# 14. Permissions

| Permission               |       Reception | Clinician |   Lab tech | Lab in-charge | Billing | Manager | Auditor |
| ------------------------ | --------------: | --------: | ---------: | ------------: | ------: | ------: | ------: |
| Order test               |         Limited |       Yes |    Limited |           Yes | Limited |     Yes |    View |
| Bill test                |              No |        No |         No |            No |     Yes |     Yes |    View |
| Collect sample           |      No/limited |        No |        Yes |           Yes |      No |     Yes |    View |
| Reject sample            |              No |        No |        Yes |           Yes |      No |     Yes |    View |
| Enter result             |              No |        No |        Yes |           Yes |      No |      No |    View |
| Verify result            |              No |        No | No/limited |           Yes |      No |      No |    View |
| Release result           |              No |        No |    Limited |           Yes |      No |     Yes |    View |
| Correct result           |              No |        No |    Request |           Yes |      No |     Yes |    View |
| Print patient result     | Yes if released |       Yes |        Yes |           Yes |      No |     Yes |    View |
| Share result             |         Limited |       Yes |    Limited |           Yes |      No |     Yes |    View |
| Configure test catalogue |              No |   Limited |         No |           Yes |      No |     Yes |    View |
| Manage external labs     |              No |        No |         No |           Yes |      No |     Yes |    View |
| Export lab reports       |              No |   Limited |    Limited |           Yes |     Yes |     Yes |     Yes |
| View audit logs          |              No |        No |         No |       Limited |      No |     Yes |     Yes |

---

# 15. Reports

## Operational reports

| Report                            | Purpose                          |
| --------------------------------- | -------------------------------- |
| Daily lab orders                  | All tests ordered                |
| Lab revenue report                | Revenue by test, payer, branch   |
| Pending sample collection         | Ordered/paid tests not collected |
| Pending results                   | Collected tests not resulted     |
| Pending verification              | Results awaiting approval        |
| Critical results                  | Urgent clinician follow-up       |
| Rejected samples                  | Quality improvement              |
| Corrected results                 | Audit and quality                |
| Unbilled tests                    | Revenue leakage                  |
| Refunded/cancelled tests          | Billing control                  |
| External send-outs                | Outsourced test tracking         |
| Overdue external results          | Follow-up                        |
| Turnaround time report            | Efficiency                       |
| Test volume by clinician          | Utilization                      |
| Test volume by diagnosis          | Clinical analytics               |
| Reagent/kit consumption           | Inventory planning               |
| Abnormal result report            | Clinical review                  |
| Results not reviewed by clinician | Continuity gap                   |

## Dashboard cards

```text
Tests ordered today
Tests paid/covered
Samples collected
Samples rejected
Results pending entry
Results pending verification
Critical results
External send-outs pending
External results overdue
Unbilled tests
Lab revenue
Average turnaround time
```

---

# 16. Quality and safety controls

Even a Lab-lite module needs basic quality controls.

| Control                      | Requirement                           |
| ---------------------------- | ------------------------------------- |
| Sample ID/barcode            | Prevent patient/sample mix-up         |
| Required billing status      | Prevent unbilled tests                |
| Required sample status       | Prevent result without collection     |
| Required verification        | Prevent unreviewed release            |
| Result correction versioning | Prevent silent result tampering       |
| Critical result alerts       | Protect patient safety                |
| Rejected sample reasons      | Improve collection quality            |
| Kit/reagent batch capture    | Traceability                          |
| Reference ranges             | Help interpretation                   |
| QC event logging             | Record errors, invalid tests, repeats |
| Access logs                  | Privacy and accountability            |
| Print/share logs             | Control disclosure                    |

---

# 17. Privacy and security

Lab results are health data and can be sensitive. The module should follow the same privacy posture as the EMR.

| Control                | Requirement                                                         |
| ---------------------- | ------------------------------------------------------------------- |
| Role-based access      | Reception sees limited results; clinicians/lab see more             |
| Sensitive test flag    | HIV, pregnancy, STI, mental-health-related or other sensitive tests |
| Result sharing consent | Required for WhatsApp/SMS/email                                     |
| Secure links           | Better than sending full sensitive result in plain SMS              |
| Reprint reason         | Required for result reprint                                         |
| Audit every view       | Especially sensitive results                                        |
| Correction audit       | Old/new values and approver                                         |
| Data encryption        | At rest and in transit                                              |
| Device timeout         | Shared lab/reception devices                                        |
| Break-glass access     | Emergency access with reason                                        |
| Patient copy control   | Avoid accidental release to wrong person                            |

---

# 18. Edge cases

| Edge case                              | Correct handling                                                        |
| -------------------------------------- | ----------------------------------------------------------------------- |
| Test ordered but not paid              | Remains awaiting billing; sample blocked unless override                |
| Patient pays but sample not collected  | Appears in pending collection report                                    |
| Sample collected but patient leaves    | Continue result workflow; notify according to policy                    |
| Wrong test ordered                     | Cancel and credit note if billed                                        |
| Wrong patient selected                 | Correction/incident workflow                                            |
| Sample clotted/insufficient            | Reject sample and request recollection                                  |
| Result entered for wrong sample        | Correction and incident workflow                                        |
| Critical result                        | Alert clinician and log notification                                    |
| External lab delays result             | Overdue send-out alert                                                  |
| External lab rejects sample            | Recollection/refund workflow                                            |
| Kit/reagent expired                    | Block result entry/test performance if inventory linked                 |
| Lab staff licence inactive             | Block result entry/verification                                         |
| Result printer fails                   | Save result; allow later print/release                                  |
| Result shared with wrong contact       | Incident/breach workflow                                                |
| Duplicate test order                   | Warn clinician/reception                                                |
| Package includes lab test              | Billing link should mark included, not unpaid                           |
| Insurer denies lab test                | Convert to patient bill or cancel/refund based on policy                |
| Internet outage                        | Allow local collection/result entry if offline mode enabled; sync later |
| Result corrected after clinician acted | Notify clinician and mark corrected report                              |

---

# 19. MVP versus later versions

## MVP

Build these first:

| Feature                        | Reason                                |
| ------------------------------ | ------------------------------------- |
| Test catalogue                 | Foundation                            |
| Lab order from EMR/reception   | Core workflow                         |
| Billing link                   | No unbilled tests                     |
| Sample collection status       | Workflow control                      |
| Basic result entry             | Numeric, text, positive/negative      |
| Reference ranges               | Clinical usefulness                   |
| Verification/release           | Quality and accountability            |
| Result printout/PDF            | Patient and clinician copy            |
| External lab send-out tracking | Real small-clinic need                |
| Audit logs                     | Compliance                            |
| Result-to-EMR link             | Continuity                            |
| Basic reports                  | Pending, completed, unbilled, revenue |
| Sample rejection               | Quality control                       |
| Critical result flag           | Patient safety                        |

## Version 2

Add:

| Feature                               | Reason                |
| ------------------------------------- | --------------------- |
| Barcode labels                        | Reduce sample mix-ups |
| Panel templates                       | CBC, urinalysis, LFTs |
| LOINC mapping                         | Interoperability      |
| Kit/reagent lot capture               | Traceability          |
| Inventory consumption                 | Stock accuracy        |
| Critical-result notification workflow | Safety                |
| Corrected-result workflow             | Quality               |
| External lab price/cost tracking      | Margin                |
| TAT analytics                         | Efficiency            |
| QC logs                               | Quality improvement   |
| Secure patient result links           | Privacy               |

## Version 3

Add:

| Feature                                 | Reason                       |
| --------------------------------------- | ---------------------------- |
| Analyser integration                    | Automation                   |
| HL7/FHIR external lab API               | Partner integration          |
| Advanced QC statistics                  | Lab quality maturity         |
| National health data dictionary mapping | Digital Health Act readiness |
| Automated claims attachments            | Reduce rejections            |
| AI abnormal-result triage               | Safety support               |
| External lab portal                     | Send/receive electronically  |
| SMS/WhatsApp result readiness           | Patient convenience          |
| Multi-branch lab routing                | Chains and hub labs          |
| Full LIS upgrade path                   | Larger laboratories          |

---

# 20. Acceptance criteria

The Lab-lite Module is ready when it passes these tests:

| Test                       | Expected result                                                               |
| -------------------------- | ----------------------------------------------------------------------------- |
| Create test catalogue item | Test has code, specimen, result type, price, status                           |
| Order test from EMR        | Order links to patient, visit, clinician, diagnosis                           |
| Order test from reception  | Walk-in order creates billing requirement                                     |
| Billing block              | Sample cannot be collected if unpaid/uncovered unless override                |
| Collect sample             | Sample ID/barcode and collection details recorded                             |
| Reject sample              | Rejection reason captured and recollection task created                       |
| Enter numeric result       | Value, unit, reference range, abnormal flag saved                             |
| Enter text/coded result    | Positive/negative/text result saved                                           |
| Verify result              | Authorized lab user releases result                                           |
| Print result               | Verified result prints with patient, test, values, reference ranges, verifier |
| Critical result            | Clinician alert and notification log created                                  |
| Correct result             | Old result retained and corrected version issued                              |
| External send-out          | Dispatch, external lab, status, result attachment tracked                     |
| Result returns to EMR      | Clinician sees result in patient visit                                        |
| Claim support              | Result links to bill, diagnosis, clinician, visit, payer                      |
| Audit                      | Order, collection, result entry, verification, correction, print all logged   |
| Report                     | Pending, unbilled, rejected, critical, external, and completed tests visible  |

---

# 21. Final product behaviour

The Lab-lite Module should behave like this:

| Situation                   | Correct behaviour                                    |
| --------------------------- | ---------------------------------------------------- |
| Clinician orders test       | Order appears in lab and billing                     |
| Patient has not paid        | Collection/testing blocked or override logged        |
| Sample is collected         | Sample ID, collector, date/time, specimen recorded   |
| Sample is unsuitable        | Rejected with reason and recollection task           |
| Result is entered           | Value, unit, reference range, abnormal flag captured |
| Result is abnormal/critical | Clinician alerted                                    |
| Result is ready             | Lab in-charge verifies before release                |
| Patient needs copy          | Result printed/shared securely                       |
| Test is outsourced          | Send-out status tracked until result returns         |
| External result arrives     | PDF/value attached and reviewed                      |
| Claim is needed             | Result links to order, bill, diagnosis, and visit    |
| Audit is needed             | Full chain visible from order to release             |

The key design principle is:

**No lab result should exist without a patient, order, sample status, billing status, responsible lab user, verification status, and audit trail.**
